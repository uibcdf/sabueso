"""Preserve actual clean SDK227 disease observations before any saved reader."""
from contextlib import ExitStack
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import importlib.metadata as metadata
import importlib.util
import json
from pathlib import Path
import subprocess
from unittest.mock import patch
from urllib.parse import unquote, urlparse

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[2]
EXPECTED = json.loads((BASE/'expected-producer.json').read_text())
HELPER = BASE.parent/'b5-root-exact-live-original-1/legacy_capture_helpers.py'
spec = importlib.util.spec_from_file_location('disease_observation_helpers', HELPER)
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
Store, view_record, access_record = helper.Store, helper.view_record, helper.access_record


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def git(*arguments):
    return subprocess.check_output(['git', '-C', str(ROOT), *arguments], text=True).strip()


def source_state():
    import sabueso, sabueso._version
    from sabueso.core.card_disease_association_access import descriptor
    require(git('rev-parse', 'HEAD') == EXPECTED['head'] and not git('status', '--porcelain=v1', '--untracked-files=all'), 'Exact clean committed producer required')
    require({sabueso.__version__, sabueso._version.__version__, metadata.version('sabueso')} == {EXPECTED['version']}, 'Producer labels disagree')
    direct = json.loads(metadata.distribution('sabueso').read_text('direct_url.json'))
    require(direct['dir_info']['editable'] and Path(unquote(urlparse(direct['url']).path)).resolve() == ROOT, 'Wrong editable origin')
    require(Path(sabueso.__file__).resolve() == ROOT/'sabueso/__init__.py', 'Wrong import')
    require(descriptor()['save'] is False, 'Capture must precede saved admission')
    for name in ('card_disease_association_history_v1.py', 'card_exploration_disease_association.py'):
        require(not (ROOT/'sabueso/core'/name).exists(), 'Independent disease reader already exists')
    names = set(git('ls-files', '--', 'sabueso', 'tests', 'conftest.py', 'pyproject.toml', '.github/workflows').splitlines()) | {'sabueso/_version.py'}
    return {name: sha(ROOT/name) for name in sorted(names)}


class Attempts(dict):
    def __init__(self):
        super().__init__(network=0, source_acquisitions=0)
        self.persist()

    def persist(self):
        (BASE/'attempts.json').write_text(json.dumps(self, indent=2)+'\n')

    def __setitem__(self, key, value):
        super().__setitem__(key, value)
        self.persist()


def prepare(module):
    """Public fixture inputs and explicit synthetic controls, never pilot data."""
    from sabueso.core.card import Card
    from sabueso.core.relationship_store import make_relationship
    from sabueso.core.source_assertion_store import make_source_assertion
    from sabueso.mappings.medgen import map_concepts
    from sabueso.mappings.mondo import map_equivalences

    public = module.originals.__wrapped__()
    cases = {}

    def source_card(name):
        return Card.from_dict(deepcopy(public[name]))

    def protein():
        return Card(meta={'entity_type': 'protein', 'card_id': 'sabueso:protein:uniprot:SYNTHETIC'})

    def add(name, disease, related, description=None):
        cases[name] = {'focal': disease.to_dict(), 'related': [c.to_dict() for c in related], 'synthetic_control': description}

    add('public-protein', source_card('disease'), [source_card('protein')])
    add('public-molecule', source_card('chagas'), [source_card('molecule')])
    add('ontology-only', source_card('disease'), [])
    for defect in ('missing_equivalence', 'misbound_equivalence', 'conflicting_mapping', 'foreign_subject'):
        disease, peer = source_card('disease'), protein()
        module.add_statement(peer, 'omim:615512', subject='uniprot:FOREIGN' if defect == 'foreign_subject' else None)
        data = disease.to_dict()
        field = data['sections']['identifiers']['equivalent_ids']
        if defect == 'missing_equivalence':
            data['source_assertion_store'] = [r for r in data['source_assertion_store'] if r['id'] not in field['source_assertion_ids']]
        elif defect == 'misbound_equivalence':
            for row in data['source_assertion_store']:
                if row['id'] in field['source_assertion_ids']:
                    row['subject_ref'] = 'mondo:MONDO:FOREIGN'
        elif defect == 'conflicting_mapping':
            mapped = map_equivalences({'OMIM:615512': {'mondo': 'MONDO:OTHER', 'version': 'synthetic', 'retrieved_at': 'synthetic fixture'}}, 'SYNTHETIC')
            for row in mapped['source_assertions']:
                peer.source_assertion_store.add(row)
            for row in mapped['relationships']:
                peer.relationship_store.add(row)
        add('identity-'+defect, Card.from_dict(data), [peer], 'Synthetic '+defect+' control copied from the public owning regression construction.')
    for defect in ('missing', 'wrong_subject'):
        peer = protein()
        _, source = module.add_statement(peer, 'mondo:MONDO:0014221', missing=defect == 'missing')
        data = peer.to_dict()
        if defect == 'wrong_subject':
            next(r for r in data['source_assertion_store'] if r['id'] == source['id'])['subject_ref'] = 'synthetic:foreign'
        add('support-'+defect, source_card('disease'), [Card.from_dict(data)], 'Synthetic association support '+defect+'; preserve partial membership.')
    for state in ('complete', 'missing', 'misbound', 'conflicting', 'unfinished'):
        peer = protein()
        module.add_statement(peer, 'medgen:C1860808')
        mapped = map_concepts({'C1860808': '349893'}, 'synthetic fixture', 'synthetic')
        for row in mapped['source_assertions']:
            if state == 'misbound':
                row['asserted_value']['uid'] = '999'
            if state != 'missing':
                peer.source_assertion_store.add(row)
        for row in mapped['relationships']:
            peer.relationship_store.add(row)
        if state in ('conflicting', 'unfinished'):
            extra = map_concepts({'C1860808': '999'}, 'synthetic fixture', 'synthetic')
            if state == 'conflicting':
                terminal = map_equivalences({'MEDGEN:999': {'mondo': 'MONDO:OTHER', 'version': 'synthetic', 'retrieved_at': 'synthetic fixture'}}, 'SYNTHETIC')
                for key in ('source_assertions', 'relationships'):
                    extra[key].extend(terminal[key])
            for row in extra['source_assertions']:
                peer.source_assertion_store.add(row)
            for row in extra['relationships']:
                peer.relationship_store.add(row)
        add('medgen-'+state, source_card('disease'), [peer], 'Synthetic MedGen concept/UID path '+state+'; no live lookup or scientific claim.')
    peer = protein()
    module.add_statement(peer, 'mondo:MONDO:0014221')
    revision = peer.to_dict()
    revision['quality']['synthetic_revision'] = 'second explicit synthetic input'
    add('input-revisions', source_card('disease'), [peer, peer, Card.from_dict(revision)], 'Synthetic repeated input occurrence and distinct supplied revision; do not merge revisions or invent observations.')
    peer = protein()
    condition = {'name': 'Explicit synthetic repeated condition', 'xrefs': ['OMIM:615512']}
    variant = {'accession': 'synthetic-variant', 'conditions': [condition, deepcopy(condition)]}
    source = make_source_assertion('annotations.clinical_variants', variant, 'ClinVar', 'synthetic-variant', 'synthetic fixture', subject_ref='uniprot:SYNTHETIC')
    peer.source_assertion_store.add(source)
    peer.sections.setdefault('annotations', {})['clinical_variants'] = {'value': [variant], 'source_assertion_ids': [source['id']]}
    add('equal-conditions', source_card('disease'), [peer], 'Synthetic equal ClinVar condition occurrences at separate original list locations.')
    for direction in ('outgoing', 'incoming'):
        disease = source_card('disease')
        subject, obj = ('mondo:MONDO:0014221', 'mondo:MONDO:0001444') if direction == 'outgoing' else ('mondo:MONDO:0001444', 'mondo:MONDO:0014221')
        source = make_source_assertion('relationships.associated_with', {'subject': subject, 'object': obj}, 'Synthetic association', 'two-disease-control', 'synthetic fixture', subject_ref=subject)
        disease.source_assertion_store.add(source)
        disease.relationship_store.add(make_relationship(subject, 'associated_with', obj, qualifiers={'source': 'Synthetic association'}, source_assertion_ids=[source['id']]))
        add('focal-'+direction, disease, [source_card('chagas')], 'Synthetic directed association between two distinct disease endpoints.')
    peer = protein()
    module.add_statement(peer, 'mondo:MONDO:0014221', channel=False)
    add('unknown-channel', source_card('disease'), [peer], 'Synthetic boolean channel shape; retain raw False and an unrecognized scalar cell.')
    data = source_card('disease').to_dict()
    field = data['sections']['identifiers']['equivalent_ids']
    field['value'].append('MEDGEN:C3661900')
    for row in data['source_assertion_store']:
        if row['id'] in field['source_assertion_ids']:
            row['asserted_value'] = deepcopy(field['value'])
    peer = protein()
    module.add_statement(peer, 'MEDGEN:C3661900')
    add('placeholder', Card.from_dict(data), [peer], 'Synthetic placeholder mention, explicitly not a positive disease association.')
    data = source_card('disease').to_dict()
    data['sections']['identifiers']['mondo'] = False
    add('incoherent-anchor', Card.from_dict(data), [source_card('protein')], 'Synthetic incoherent primary disease field; preserve unavailable status.')
    return public, cases


def main():
    import sabueso
    from sabueso.core.card import Card
    from sabueso.core import diseases
    from sabueso.core.card_disease_association_selection_v1 import COLUMNS
    from sabueso.core.card_exploration_storage import _FLAGS
    from sabueso.tools.db.clinicaltrials import FixtureClinicalTrialsClient, OnlineClinicalTrialsClient
    from sabueso.tools.db.unichem import FixtureUniChemClient, OnlineUniChemClient

    before = source_state()
    output = BASE/__import__('sys').argv[1]
    require(not output.exists(), 'Never overwrite an original')
    module_path = ROOT/'tests/core/test_card_disease_association_exploration_offline.py'
    spec = importlib.util.spec_from_file_location('disease_public_original_inputs', module_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    with ExitStack() as stack:
        helper.guards(stack, {'network': 0})
        public, inputs = prepare(module)
    requested = __import__('sys').argv[2:]
    if requested:
        inputs = {key: inputs[key] for key in requested}
    store = Store(output)
    store.copy(Path(__file__), 'capture-script.py')
    store.copy(HELPER, 'observation-helpers.py')
    store.copy(module_path, 'input-test-module.py')
    store.copy(BASE/'expected-producer.json', 'producer.json')
    store.copy(ROOT/'LICENSE', 'LICENSE')
    for name in ('NOTICE.md', 'mondo/mondo.obo', 'frozen_cards/schema_0.3.10__P60174.json', 'chembl/molecules.json', 'chembl/indications.json', 'clinicaltrials/studies.json'):
        store.copy(ROOT/'temp_data'/name, 'fixtures/'+name)
    (output/'NOTICE.md').write_text('# Disease association original — source and rights\n\nPublic fixture inputs retain the source/date/licence declarations in fixtures/NOTICE.md. MONDO, UniProt, DISEASES, Open Targets, Orphanet, ClinVar, ChEMBL and ClinicalTrials.gov annotations retain their original source assertions and terms; derived observations do not relicense them. Existing frozen HsTIM and Chagas/benznidazole fixtures are public. Authored code and synthetic controls follow the repository MIT LICENSE. Each synthetic case is explicitly labelled in inputs.json and its case record; none is a scientific observation. No private or pilot material is included.\n\nThis is a finite genuine LIVE observational original from clean SDK227, not an admitted saved exploration file, scientific validation or researcher acceptance. Preparation uses offline fixture clients with network forbidden. Observation forbids network/source acquisition and cached science rereads. Preserve these bytes before implementing an independent reader. Owner: Sabueso #148/#90/#112. Review trigger: independent receiving and block closeout.\n')
    store.index(output/'NOTICE.md')
    store.save('source-before.json', before)
    store.save('public-inputs.json', public)
    store.save('inputs.json', inputs)
    attempts, cases = Attempts(), {}

    def forbidden_science(*args, **kwargs):
        raise RuntimeError('Cached observation must not reread current science')

    def forbidden_acquisition(*args, **kwargs):
        attempts['source_acquisitions'] += 1
        raise RuntimeError('Source acquisition forbidden during observation')

    with ExitStack() as stack:
        helper.guards(stack, attempts, acquisitions=True)
        for client in (FixtureClinicalTrialsClient, OnlineClinicalTrialsClient, FixtureUniChemClient, OnlineUniChemClient):
            stack.enter_context(patch.object(client, '__init__', forbidden_acquisition))
        for name in ('disease_targets', 'disease_drugs'):
            stack.enter_context(patch.object(sabueso, name, forbidden_acquisition))
        stack.enter_context(patch.object(Card, 'diseases', forbidden_science))
        for name, data in inputs.items():
            print('Capturing '+name, flush=True)
            focal = Card.from_dict(deepcopy(data['focal']))
            related = [Card.from_dict(deepcopy(row)) for row in data['related']]
            cards = [focal, *related]
            original_cards = [card.to_dict() for card in cards]
            oracles = []
            for card in cards:
                nature = card.meta.get('entity_type')
                native = diseases._card_statements(card) if nature == 'protein' else card.clinical() if nature == 'small_molecule' else None
                oracles.append({'knowledge_state': card.knowledge_state(), 'native_payload': native})
            explorer = focal.explore(related_cards=related)
            named, queries = {}, []

            def remember(label, view):
                require(label not in named, 'Duplicate named observation')
                named[label] = view
                return view

            root = remember('root', explorer.view('associations'))
            with patch.object(Card, 'clinical', forbidden_science), patch.object(Card, 'knowledge_state', forbidden_science), patch.object(diseases, '_card_statements', forbidden_science):
                question = remember('question', explorer.answer('retained_associations'))
                remember('topics', explorer.topics())
                remember('questions', explorer.questions())
                remember('overview', explorer.overview())
                remember('empty', question.filter('kind', equals='no_such_association'))
                remember('null-source', question.filter('source', equals=None))
                remember('ordered', question.sort('source', descending=True))
                for kind in ('association_context', 'association_statement', 'indication_statement', 'uniprot_disease_xref', 'variant_condition'):
                    remember(kind, question.filter('kind', equals=kind))
                remember('selected-uniprot', question.filter('source', equals='UniProt'))
                remember('selected-statements', question.filter('kind', equals='association_statement'))
                # Observe original and filtered/order origins, including same view handles.
                for origin_name in ('question', 'selected-uniprot', 'selected-statements', 'ordered'):
                    parent = named[origin_name]
                    for index, item in enumerate(parent.items()):
                        prefix = f'{origin_name}:item-{index}'
                        detail = remember(prefix+':open', item.open())
                        explanation = remember(prefix+':explain', item.explain())
                        links = remember(prefix+':related', item.related())
                        require(detail.back() is parent and explanation.back() is parent and links.back() is parent, 'Exact initiating origin lost')
                        for position, link in enumerate(links.items()):
                            if link._entry.value.get('candidates'):
                                opened = remember(prefix+f':link-{position}', link.open())
                                require(opened.back() is links and opened.request == parent.request, 'Cross-capture source/back question lost')
                                candidate = link._entry.value['candidates'][0]
                                require(opened.explorer.access._focal_key == candidate['capture'], 'Cross-capture focal mismatch')
                                overview = remember(prefix+f':link-{position}:overview', opened.explorer.overview())
                                require(overview.back() is links, 'Destination explorer initiating origin lost')
                refs = [item.item_ref for item in question.items()]
                specs = [('default', {}), ('all-fields', {'fields': list(COLUMNS)}), ('no-fields', {'fields': []}),
                         ('empty-membership', {'item_refs': []}), ('reverse-membership', {'item_refs': refs[:2][::-1], 'fields': ['source', 'predicate']}),
                         ('null-source', {'where': {'source': None}}), ('absent-source', {'where': {'source': 'synthetic absent'}}),
                         ('ordered', {'order_by': {'column': 'source', 'descending': True}}),
                         ('ordered-ascending', {'order_by': {'column': 'source', 'descending': False}})]
                specs += [(kind, {'where': {'kind': kind}}) for kind in ('association_context', 'association_statement', 'indication_statement', 'uniprot_disease_xref', 'variant_condition')]
                for label, request in specs:
                    selection = explorer.access.select('associations', **request)
                    pages, cursor, seen = [], None, set()
                    while True:
                        page = selection.page(limit=4, max_bytes=65536, cursor=cursor)
                        require(page['page']['blocked'] is None, 'Incomplete captured machine page')
                        pages.append(store.put(page))
                        cursor = page['page']['next_cursor']
                        if cursor is None:
                            break
                        require(cursor not in seen, 'Repeated cursor')
                        seen.add(cursor)
                    queries.append({'label': label, 'request': request, 'selection_ref': selection.selection_ref, 'count': selection.count, 'pages': pages})
                # Object identity and focal access are explicit; equal handles never deduplicate nodes.
                views, identities, accesses, access_ids = [], {}, [], {}

                def node(view):
                    if view is None:
                        return None
                    if id(view) not in identities:
                        identities[id(view)] = 'V'+str(len(views))
                        views.append(view)
                    return identities[id(view)]

                def aid(access):
                    if id(access) not in access_ids:
                        access_ids[id(access)] = 'A'+str(len(accesses))
                        accesses.append(access)
                    return access_ids[id(access)]

                root_access = aid(explorer.access)
                for observed in [*named.values(), *explorer._session['views'].values()]:
                    node(observed)
                for view in views:
                    node(view._origin)
                    node(view.explorer._origin)
                records = []
                for view in views:
                    records.append({'node': node(view), 'access_node': aid(view.explorer.access), 'selection_access_node': aid(view._selection._access),
                                    'origin_node': node(view._origin), 'explorer_origin_node': node(view.explorer._origin),
                                    'observation_ref': store.put(view_record(view, store)), 'flags': {key: getattr(view, key) for key in _FLAGS}})
                # Packaging-only factoring of shared containers. Each actual access
                # keeps its own node, focal key, selections, tokens and cursors.
                # Never infer scientific equality from content-addressed bytes.
                first = explorer.access
                full = access_record(first, store)
                shared = {'inputs': '_inputs', 'captures': '_captures', 'objects': '_objects',
                          'locations': '_locations', 'metadata_refs': '_metadata_refs', 'native_cache': '_scientific_cache'}
                common = {key: store.put(full[key]) for key in shared}
                access_records = {}
                for access in accesses:
                    require(all(getattr(access, attr) is getattr(first, attr) for attr in shared.values()), 'Unexpected independent container; preserve it explicitly before continuing')
                    fields = dict(common)
                    fields.update({
                        'cursors': store.put(access._cursors),
                        'tokens': store.put([{'selection_ref': key[0], 'offset': key[1], 'token': value} for key, value in access._tokens.items()]),
                        'scientific_items': store.put({key: {'result_ref': value[0].result_ref, 'entry_key': value[1]} for key, value in access._scientific_items.items()}),
                        'selections': store.put({key: helper.selection_record(value, store) for key, value in access._selections.items()}),
                    })
                    access_records[aid(access)] = {'focal': access._focal_key, 'nonce': access._nonce, 'fields': fields}
                case = {'input': store.put(data), 'synthetic_control': data['synthetic_control'], 'native_oracles': store.put(oracles),
                        'root_access_node': root_access, 'named_views': {label: node(view) for label, view in named.items()},
                        'views': records, 'queries': queries, 'accesses': access_records,
                        'session_operations': {kind: {key: node(view) for key, view in explorer._session[kind].items()} for kind in ('explanations', 'links')}}
                cases[name] = store.save('cases/'+name+'.json', case)
            require([card.to_dict() for card in cards] == original_cards, 'Input Card mutated')
    after = source_state()
    require(before == after and not any(attempts.values()), 'Source changed or forbidden attempt recorded')
    store.save('source-after.json', after)
    manifest = {'format': 'disease_association_live_original@1', 'genuine_live_original': True, 'capture_complete': True,
                'producer_head': EXPECTED['head'], 'producer_version': EXPECTED['version'], 'captured_utc': datetime.now(timezone.utc).isoformat(),
                'cases': cases, 'files': dict(store.files), 'source_stable': True, 'attempts': dict(attempts),
                'scope': 'Finite complete retained LIVE human/machine/source/navigation observations, including each actual view and focal access instance. Public fixtures and explicitly labelled synthetic controls. No saved reader, scientific/human admission, current-source acquisition or release.'}
    store.save('manifest.json', manifest)
    print(json.dumps({'state': 'CAPTURE_COMPLETE', 'cases': len(cases), 'files': len(store.files), 'producer': EXPECTED, 'source_stable': True, 'attempts': dict(attempts)}, indent=2))


if __name__ == '__main__':
    main()
