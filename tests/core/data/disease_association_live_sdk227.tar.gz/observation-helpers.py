"""Prepare public inputs, or explicitly capture a clean SDK205 LIVE original.

Preparation is not an original. Capture is local pre-reader evidence, not an
admitted saved format. Never run --capture without the coordinator's launch.
"""
import argparse
import hashlib
import importlib.metadata as metadata
import importlib.util
import json
import platform
import shutil
import socket
import subprocess
import sys
from contextlib import ExitStack
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import patch
from urllib.parse import unquote, urlparse

BASE = Path(__file__).resolve().parent
ROOT = next(p for p in BASE.parents if (p / 'pyproject.toml').is_file())
TOPIC = 'activity_context'
FIXTURES = ('NOTICE.md', 'P52270.json', 'chembl/CHEMBL5834.json', 'chembl/molecules.json', 'pdb_ccd/BTS.json', 'rcsb/1SUX.json')
ENCODER = json.JSONEncoder(ensure_ascii=False, allow_nan=False, sort_keys=True, separators=(',', ':'))


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args], text=True).strip()


def wire(value):
    if value is None or isinstance(value, (str, bool, int, float)):
        return value
    if isinstance(value, dict):
        require(all(isinstance(key, str) for key in value), 'Non-JSON object key')
        return {key: wire(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [wire(item) for item in value]
    import pyunitwizard as puw
    require(puw.is_quantity(value), 'Undeclared non-JSON capture value')
    unit = puw.convert(str(puw.get_unit(value)), to_form='record', to_type='unit')
    number = puw.get_value(value, to_unit=unit)
    return {'value': number.tolist() if hasattr(number, 'tolist') else number, 'unit': unit}


class Store:
    """Keep complete values once; refs are packaging references, not scientific nodes."""
    def __init__(self, output, resume=False):
        self.output, self.files = output, {}
        if resume:
            require(output.is_dir() and not (output / 'manifest.json').exists(), 'Only an incomplete original can resume')
            for path in sorted(output.rglob('*')):
                require(not path.is_symlink(), 'Original contains a symlink')
                if path.is_file():
                    self.index(path)
        else:
            output.mkdir(parents=True, exist_ok=False)

    def index(self, path):
        name = path.relative_to(self.output).as_posix()
        self.files[name] = {'bytes': path.stat().st_size, 'sha256': sha(path)}
        return {'path': name, **self.files[name]}

    def save(self, name, value):
        path = self.output / name
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open('x', encoding='utf-8') as stream:
            for chunk in ENCODER.iterencode(wire(value)):
                stream.write(chunk)
            stream.write('\n')
        return self.index(path)

    def put(self, value):
        value, digest = wire(value), hashlib.sha256()
        for chunk in ENCODER.iterencode(value):
            digest.update(chunk.encode('utf-8'))
        name = 'values/' + digest.hexdigest() + '.json'
        return self.files[name] | {'path': name} if name in self.files else self.save(name, value)

    def copy(self, source, name):
        path = self.output / name
        path.parent.mkdir(parents=True, exist_ok=True)
        require(not path.exists(), 'Refusing existing member')
        shutil.copyfile(source, path)
        return self.index(path)


def source_state(head, version):
    import sabueso
    import sabueso._version as generated
    require(git('rev-parse', 'HEAD') == head, 'Capture needs the explicitly authorized HEAD')
    require(not git('status', '--porcelain=v1', '--untracked-files=all'), 'Producer must be clean')
    tag, distance, revision = git('describe', '--tags', '--long', '--abbrev=7').rsplit('-', 2)
    expected = tag.removeprefix('v') + '+' + distance + '.' + revision
    require(distance == '205' and version == expected, 'Capture requires actual clean SDK205')
    require({sabueso.__version__, generated.__version__, metadata.version('sabueso')} == {version},
            'Runtime, installed metadata, generated version and HEAD must agree')
    require(Path(sabueso.__file__).resolve() == ROOT / 'sabueso/__init__.py', 'Wrong SDK import')
    direct = json.loads(metadata.distribution('sabueso').read_text('direct_url.json'))
    require(direct.get('dir_info', {}).get('editable') is True and
            Path(unquote(urlparse(direct['url']).path)).resolve() == ROOT, 'Wrong editable origin')
    names = git('ls-files', '--', 'sabueso', 'tests', 'conftest.py', 'pyproject.toml', '.github/workflows').splitlines()
    return {name: sha(ROOT / name) for name in sorted(set(names) | {'sabueso/_version.py'})}


def guards(stack, attempts, acquisitions=False):
    def forbidden(kind):
        def reject(*args, **kwargs):
            attempts[kind] += 1
            raise RuntimeError('Acquisition/network forbidden during capture')
        return reject
    for owner, names in ((socket, ('create_connection', 'getaddrinfo', 'gethostbyname')),
                         (socket.socket, ('connect', 'connect_ex', 'sendto', 'sendmsg'))):
        for name in names:
            if hasattr(owner, name):
                stack.enter_context(patch.object(owner, name, forbidden('network')))
    if acquisitions:
        import sabueso
        from sabueso.resolver import FixtureRCSBClient, OnlineRCSBClient
        modules = [(importlib.import_module('sabueso.tools.db.' + name), suffix)
                   for name, suffix in (('uniprot', 'UniProt'), ('chembl', 'ChEMBL'),
                                        ('europepmc', 'EuropePMC'), ('mondo', 'MONDO'), ('pdb_ccd', 'CCD'))]
        clients = [FixtureRCSBClient, OnlineRCSBClient]
        clients += [getattr(module, prefix + suffix + 'Client')
                    for module, suffix in modules for prefix in ('Fixture', 'Online')]
        for client in clients:
            stack.enter_context(patch.object(client, '__init__', forbidden('source_acquisitions')))
        for name in ('resolve', 'refresh_card', 'resolve_protein_card', 'knowledge_packet'):
            stack.enter_context(patch.object(sabueso, name, forbidden('source_acquisitions')))


def selection_record(selection, store):
    return {'result_ref': selection.result_ref, 'selection_ref': selection.selection_ref,
        'scientific_result_ref': selection._scientific.result_ref if selection._scientific else None,
        'context_location': selection._context_location, 'slice': selection._slice,
        'outcome_override': selection._outcome_override,
        'request': {'operation': selection._operation, 'target': selection._target, 'fields': list(selection._fields)},
        'entries': [{'key': e.key, 'location': e.location, 'ordinal': e.ordinal, 'value_ref': store.put(e.value)}
                    for e in selection._entries]}


HEAD = 'ddc1fc83725d10c2cc5fe569341ae1b761dddc8d'
VERSION = '0.14.0+205.gddc1fc8'
FIELD = 'relationships.has_bioactivity.measurement.normalized'


def load_test_module():
    path = ROOT / 'tests/core/test_card_molecule_activity_exploration_offline.py'
    spec = importlib.util.spec_from_file_location('molecule_original_inputs', path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module, path


def prepare(output):
    from copy import deepcopy
    from sabueso.core.card import Card
    from sabueso.core.relationship_store import make_relationship
    from sabueso.core.source_assertion_store import make_source_assertion
    before = source_state(HEAD, VERSION)
    module, path = load_test_module()
    attempts = {'network': 0, 'source_acquisitions': 0}
    with ExitStack() as stack:
        guards(stack, attempts)
        public = module.public_originals.__wrapped__()
    store, cases = Store(output), {}
    base = public['cards']
    def card(name):
        return Card.from_dict(deepcopy(base[name]))
    def add(name, focal=None, related=None, options=None, synthetic=None):
        focal = card('bts') if focal is None else focal
        related = [card('target')] if related is None else related
        cases[name] = {'focal': store.put(focal.to_dict()),
            'related': [store.put(c.to_dict()) for c in related],
            'options': options or {}, 'synthetic_control': synthetic}
    add('bts')
    add('benz', card('benz'))
    add('full-molecule-deck', related=[card('target'), card('benz')])
    add('duplicate-targets', related=[card('target'), card('target')])
    add('duplicate-molecules', related=[card('target'), card('bts')])
    add('missing-context', related=[])
    add('nonprotein-context', related=[card('benz')])
    add('unsupported-context', related=[Card(meta={'entity_type': 'disease', 'card_id': 'sabueso:disease:mondo:MONDO:0001444'})], synthetic='Minimal disease context without assertions; unsupported target nature control.')
    add('wrong-focal-nature', card('target'), [card('bts')], synthetic='Actual public protein supplied as focal object to a molecule-only interpretation.')
    for name in ('unqueried', 'failed', 'empty'):
        add(name, related=[card(name)], synthetic='Successful empty acquisition is explicitly synthetic.' if name == 'empty' else None)
    raw = deepcopy(base['bts'])
    raw['relationship_store'] = [r for r in raw['relationship_store'] if r['predicate'] != 'same_as']
    add('missing-identity', Card.from_dict(raw), synthetic='Remove explicit identity edges; retain original identifiers and names.')
    raw = deepcopy(base['bts']); raw['source_assertion_store'] = []
    add('missing-identity-support', Card.from_dict(raw), synthetic='Retain identity edges but remove their source assertions.')
    molecule = card('bts')
    ref, anchor = 'chembl:CHEMBL999999999', molecule.id.split(':', 2)[2]
    value = {'record_ref': ref, 'anchor': anchor, 'synthetic_control': [False, 0, 0.0, None],
        'opaque_source_metadata': {'format': 'source-owned@999', 'rule': 'source-owned@7', 'adapter': 'source-owned@9', 'version': 0, 'context': False}}
    assertion = make_source_assertion('relationships.same_as', value, 'Synthetic identity control', ref, 'synthetic fixture', subject_ref=ref)
    molecule.source_assertion_store.add(assertion)
    molecule.relationship_store.add(make_relationship(ref, 'same_as', anchor, value, [assertion['id']]))
    add('unmatched-alias-opaque', molecule, options={'molecule_ref': ref}, synthetic='Explicit unmatched synthetic alias; opaque values are source-owned literals, not codecs.')
    contradictory = card('benz'); module.synthetic_alias(contradictory, module.BTS)
    add('conflicting-anchors', related=[card('target'), contradictory], synthetic='Attach BTS source alias to a different synthetic chemical anchor.')
    molecule = card('bts'); module.synthetic_alias(molecule, module.BENZ)
    add('multiple-aliases', molecule, synthetic='Explicit synthetic identity join of two actual public source aliases; no real chemical equivalence claim.')
    raw = deepcopy(base['target']); raw['meta']['synthetic_snapshot_control'] = 'distinct supplied snapshot, unchanged measurements'
    add('two-target-snapshots', related=[card('target'), Card.from_dict(raw)], synthetic='Same Card ID, distinct supplied snapshot.')
    add('mixed-source-states', related=[card(n) for n in ('target', 'unqueried', 'failed', 'empty')], synthetic='Mixed known/unqueried/failed/synthetic successful-empty captures.')
    raw = deepcopy(base['target'])
    next(r for r in raw['relationship_store'] if r['predicate'] == 'has_bioactivity')['subject_ref'] = 'uniprot:P60174'
    add('foreign-target-identity', related=[Card.from_dict(raw)], synthetic='One source-record subject deliberately contradicts the supplied target identity.')
    raw = deepcopy(base['bts']); raw['sections']['identifiers']['inchikey']['value'] = 'SYNTHETIC-INCOHERENT-ANCHOR'
    add('incoherent-molecule-anchor', Card.from_dict(raw), synthetic='Identifier field deliberately contradicts the molecule Card anchor.')
    add('include-indirect', options={'include_indirect': True})
    add('optin-policies', options={'measurement_rule': 'measurement_identity@2', 'target_scope_rule': 'bioactivity_target_scope@2'})
    add('original-classification', options={'classification_rule': 'bioactivity_class@3'})
    add('explicit-physical-thresholds', options={'thresholds': {'active_max': {'value': 20, 'unit': 'micromolar'}, 'weak_max': {'value': 200, 'unit': 'micromolar'}, 'single_point_min': {'value': 75, 'unit': 'percent'}}})
    for rule in ('measurement_identity@1', 'measurement_identity@2'):
        for joined in (False, True):
            molecule, target = card('bts'), card('target')
            _, copied = module.synthetic_cross_alias_copy(target)
            if joined:
                module.synthetic_alias(molecule, copied['object_ref'])
            add('copy-' + rule.rsplit('@', 1)[1] + ('-joined' if joined else '-unjoined'), molecule, [target], {'measurement_rule': rule},
                'Full public 493 plus one declared synthetic source-copy alias; explicit identity join is ' + str(joined) + '.')
    for name in FIXTURES:
        store.copy(ROOT / 'temp_data' / name, 'raw_inputs/temp_data/' + name)
    store.copy(path, 'input-test-module.py')
    store.save('base-public-inputs.json', public)
    require(source_state(HEAD, VERSION) == before and not any(attempts.values()), 'Input preparation drift or network attempt')
    store.save('input-manifest.json', {'preparation_complete': True, 'genuine_live_original': False,
        'producer_head': HEAD, 'producer_version': VERSION, 'cases': cases,
        'base_card_names': sorted(base), 'source_fixture_paths': list(FIXTURES), 'files': dict(store.files),
        'attempts': attempts, 'owner': '#148/#112', 'review_trigger': 'Clean SDK205 complete LIVE original capture; then independent-reader review',
        'scope': 'Complete public target and molecule inputs, declared synthetic scope controls, and independent native public oracles. Preparation is not an original.'})
    print(json.dumps({'preparation_complete': True, 'cases': len(cases), 'output': str(output), 'manifest_sha256': sha(output / 'input-manifest.json')}), flush=True)


def view_record(view, store):
    from sabueso.core.card_exploration_storage import _cell_record
    from pyunitwizard import QuantityRecord
    import pyunitwizard as puw
    rows = []
    for item in view.items():
        cells = {}
        for column, cell in item.cells.items():
            value = cell.value
            record = {'encoding': 'json', 'value': wire(value), 'state': cell.state, 'reason': cell.reason}
            if value is not None and not isinstance(value, (str, bool, int, float, dict, list, tuple)):
                if view._record_panel == TOPIC and column == 'measurement':
                    node = view._selection._scientific.value(item._entry.key, column)
                    require(isinstance(node, dict) and node['unit'] in ('nanomolar', 'percent') and puw.is_quantity(value), 'Undeclared molecule quantity cell')
                    record = {'encoding': 'quantity_record', 'value': QuantityRecord.from_quantity(value, field=FIELD, unit=node['unit']).to_dict(),
                        'field': FIELD, 'unit': node['unit'], 'state': cell.state, 'reason': cell.reason}
                else:
                    record = _cell_record(item, column, cell)
                    require(record['encoding'] == 'quantity_record' and record.get('field') and record.get('unit'), 'No declared quantity codec')
                    record.pop('support', None)
            cells[column] = {**record, 'support_ref': store.put(cell.support)}
        rows.append({'item_ref': item.item_ref, 'label': item.label, 'kind': item.kind,
            'payload_location': item.payload_location, 'support_ref': store.put(item.support), 'cells': cells})
    return {'view_ref': view.view_ref, 'result_ref': view.result_ref, 'title': view.title,
        'presentation': view.presentation, 'at_root': view.at_root, 'record_panel': view._record_panel,
        'focal': view.explorer.access._focal_key, 'explorer_context': view.explorer.context,
        'display_request': view._display_request, 'selection': selection_record(view._selection, store),
        'request': view.request, 'context': view.context, 'outcome': view.outcome, 'schema': view.schema,
        'back_view_ref': view.back().view_ref if not view.at_root else None,
        'origin_view_ref': view._origin.view_ref if view._origin is not None else None,
        'native_payload_ref': store.put(view.native_payload), 'items': rows,
        'text': str(view), 'html': view._repr_html_()}


def access_record(access, store):
    natives = []
    for key, value in access._scientific_cache.items():
        if isinstance(key, tuple) and len(key) >= 2 and key[1] == 'native':
            natives.append({'key': list(key), 'payload_ref': store.put(value)})
    return {'focal': access._focal_key, 'nonce': access._nonce, 'inputs': access._inputs,
        'captures': {k: {'pin': c.pin, 'snapshot': c.snapshot, 'data_ref': store.put(c.data)} for k, c in access._captures.items()},
        'objects': {k: store.put(v) for k, v in access._objects.items()}, 'locations': access._locations,
        'metadata_refs': sorted(access._metadata_refs), 'cursors': access._cursors,
        'tokens': [{'selection_ref': k[0], 'offset': k[1], 'token': v} for k, v in access._tokens.items()],
        'scientific_items': {k: {'result_ref': v[0].result_ref, 'entry_key': v[1]} for k, v in access._scientific_items.items()},
        'selections': {k: selection_record(v, store) for k, v in access._selections.items()}, 'native_cache': natives}


def capture(args, output):
    from sabueso.core.card import Card
    from sabueso.core.card_molecule_activity_access import descriptor
    from sabueso.core.errors import ArgumentError, StorageError
    before, helper_hash = source_state(HEAD, VERSION), sha(Path(__file__))
    require(descriptor()['save'] is False, 'Capture must precede new saved admission')
    require(sha(args.inputs / 'input-manifest.json') == args.input_manifest_sha256, 'Prepared input manifest changed')
    manifest = json.loads((args.inputs / 'input-manifest.json').read_text())
    require(manifest['preparation_complete'] and not manifest['genuine_live_original'] and manifest['producer_head'] == HEAD, 'Wrong prepared inputs')
    for name, value in manifest['files'].items():
        path = args.inputs / name
        require(path.resolve().is_relative_to(args.inputs) and not path.is_symlink() and sha(path) == value['sha256'] and path.stat().st_size == value['bytes'], 'Unsafe or changed prepared member')
    store, cases = Store(output, resume=args.resume), {}
    prior_files, resumed_cases = dict(store.files), []
    if args.resume:
        resource = json.loads((BASE / 'capture2-resource.json').read_text())
        require(output == BASE / 'original2' and resource['exit_code'] == 1 and resource['stop_reason'] is None, 'Unexpected original/resumption source')
        require('Unexpected source/identity state: nonprotein-context' in (BASE / 'capture2.log').read_text(), 'Unexpected stopped capture')
        require(sha(output / 'input-preparation-manifest.json') == args.input_manifest_sha256, 'Original preparation differs')
        for name in manifest['files']:
            require(store.files['inputs/' + name] == manifest['files'][name], 'Prior copied input bytes differ')
        for path in sorted((output / 'cases').glob('*.json')):
            name = path.stem
            recorded = json.loads(path.read_text())
            require(name in manifest['cases'] and ENCODER.encode(recorded['inputs']) == ENCODER.encode(manifest['cases'][name]), 'Prior case input differs')
            cases[name] = {'path': path.relative_to(output).as_posix(), **store.files[path.relative_to(output).as_posix()]}
            resumed_cases.append(name)
        require(len(cases) == 21 and 'nonprotein-context' not in cases, 'Wrong completed prefix')
        store.save('resume-prior-members.json', prior_files)
        store.copy(Path(__file__), 'capture-resume-script.py')
        store.copy(BASE / 'capture2-resource.json', 'capture-initial-resource.json')
        store.copy(BASE / 'capture2.log', 'capture-initial.log')
    else:
        store.copy(Path(__file__), 'capture-script.py')
        store.copy(args.inputs / 'input-manifest.json', 'input-preparation-manifest.json')
        for name in manifest['files']:
            store.copy(args.inputs / name, 'inputs/' + name)
    store.save('source-resume-before.json' if args.resume else 'source-capture-before.json', before)
    attempts = {'network': 0, 'source_acquisitions': 0}
    with ExitStack() as stack:
        guards(stack, attempts, acquisitions=True)
        for name, spec in manifest['cases'].items():
            if name in cases:
                continue
            def restore(ref):
                return Card.from_dict(json.loads((args.inputs / ref['path']).read_text()))
            molecule, related = restore(spec['focal']), [restore(ref) for ref in spec['related']]
            input_before = [c.to_dict() for c in [molecule, *related]]
            explorer = molecule.explore(related_cards=related)
            named, operations, queries, refusals, publication_oracles = {}, [], [], [], {}
            supplied_by_pin = {c.pinned_ref(): c for c in related}
            def remember(label, view):
                require(label not in named, 'Duplicate named original view')
                named[label] = view
                return view
            def query(label, **kwargs):
                selection = explorer.access.select(TOPIC, **kwargs)
                pages, cursor, seen = [], None, set()
                while True:
                    page = selection.page(limit=1, max_bytes=65536, cursor=cursor)
                    require(page['page']['blocked'] is None and len(ENCODER.encode(wire(page)).encode()) <= 65536, 'Default page cannot receive complete scoped frame')
                    pages.append(page)
                    cursor = page['page']['next_cursor']
                    if cursor is None:
                        break
                    require(cursor not in seen, 'Repeated cursor'); seen.add(cursor)
                require(sum(len(p['items']) for p in pages) == selection.count, 'Incomplete original pages')
                queries.append({'name': label, 'query': kwargs, 'selection': selection_record(selection, store), 'pages_ref': store.put(pages)})
                return selection
            root = remember('root', explorer.view(TOPIC, options=spec['options']))
            expected_status = {'missing-context': 'missing_prerequisite', 'nonprotein-context': 'unsupported',
                'unsupported-context': 'unsupported', 'wrong-focal-nature': 'not_applicable',
                'unqueried': 'not_queried', 'failed': 'unavailable', 'empty': 'empty',
                'missing-identity': 'missing_prerequisite', 'conflicting-anchors': 'missing_prerequisite',
                'foreign-target-identity': 'missing_prerequisite', 'incoherent-molecule-anchor': 'missing_prerequisite',
                'unmatched-alias-opaque': 'empty', 'missing-identity-support': 'partial'}.get(name)
            if expected_status is not None:
                require(root.outcome['status'] == expected_status, 'Unexpected source/identity state: ' + name)
            if name.startswith('copy-'):
                require(len(root.items()) == 1 and root.items()[0].cells['record_count'].value == (1 if name.endswith('-unjoined') else 2), 'Source-copy identity membership changed')
            if name == 'bts':
                import pyunitwizard as puw
                require(root.items()[0].cells['class'].value == 'weak' and puw.get_value(root.items()[0].cells['measurement'].value, to_unit='nanomolar') == 33000, 'Public BTS scalar changed')
            if name != 'wrong-focal-nature':
                question = remember('question', explorer.answer('measured_targets', options=spec['options']))
                require(root.result_ref == question.result_ref, 'Human question changed native result')
            remember('topics', explorer.topics()); remember('questions', explorer.questions())
            query('default', options=spec['options'])
            query('all-fields', options=spec['options'], fields=list(descriptor()['columns']))
            query('no-fields', options=spec['options'], fields=[])
            query('empty-membership', options=spec['options'], item_refs=[])
            query('null-measurement', options=spec['options'], where={'measurement': None})
            query('ordered-targets', options=spec['options'], order_by={'column': 'target_card_ref', 'descending': True})
            # Store every actual target/group/record branch; source/publication routes
            # are complete for the primary public and scope-control cohorts.
            deep = True
            for ti, target_item in enumerate(root.items()):
                pin = target_item.cells['target_card_ref'].value
                prefix = 'target/' + str(ti)
                filtered = remember(prefix + '/filtered-root', root.filter('target_card_ref', equals=pin))
                operations.append({'operation': 'filter', 'parent': 'root', 'column': 'target_card_ref', 'equals': pin, 'view': prefix + '/filtered-root'})
                if filtered.items():
                    filtered_groups = remember(prefix + '/filtered-groups', filtered.items()[0].open())
                    if filtered_groups.items():
                        filtered_records = remember(prefix + '/filtered-records', filtered_groups.items()[0].open())
                        if filtered_records.items():
                            filtered_links = remember(prefix + '/filtered-record-links', filtered_records.items()[0].related())
                            return_link = next(link for link in filtered_links.items() if link._entry.value.get('role') == 'molecule_root')
                            returned = remember(prefix + '/filtered-return', return_link.open())
                            require(returned.view_ref == filtered.view_ref and returned._display_request == filtered._display_request, 'Filtered origin lost on return')
                query(prefix + '/membership', options=spec['options'], item_refs=[target_item.item_ref])
                groups = remember(prefix + '/groups', target_item.open())
                group_options = groups._selection._scientific.options
                query(prefix + '/groups', options=group_options, fields=['molecule_ref', 'measurement_ref', 'record_count', 'class', 'measurement'])
                if not deep:
                    continue
                remember(prefix + '/explain', target_item.explain())
                levels = [(prefix, target_item)]
                for gi, group in enumerate(groups.items()):
                    gp = prefix + '/group/' + str(gi)
                    records = remember(gp + '/records', group.open())
                    levels.append((gp, group))
                    query(gp + '/records', options=records._selection._scientific.options)
                    for ri, record in enumerate(records.items()):
                        rp = gp + '/record/' + str(ri)
                        remember(rp + '/open', record.open()); remember(rp + '/explain', record.explain())
                        levels.append((rp, record))
                        options = dict(group_options, molecule_ref=record.cells['molecule_ref'].value,
                            measurement_ref=record.cells['relationship_id'].value)
                        remember(rp + '/exact-source-focus', explorer.view(TOPIC, options=options))
                        query(rp + '/exact-source-focus', options=options, fields=['molecule_ref', 'relationship_id', 'measurement', 'class'])
                for lp, item in levels:
                    links = remember(lp + '/links', item.related())
                    for li, link in enumerate(links.items()):
                        role = link._entry.value.get('role')
                        if role not in ('source', 'original_relationship', 'identity_context', 'assay_context', 'citation_context', 'publication_context', 'molecule_root', 'native_ligand_crossing', 'target_card'):
                            continue
                        opened = remember(lp + '/link/' + str(li) + '/' + role, link.open())
                        if role == 'publication_context':
                            payload = opened.native_payload
                            publication = payload.get('publication_ref') or payload.get('publication', {}).get('publication_ref')
                            key = pin + '|' + publication
                            if key not in publication_oracles:
                                publication_oracles[key] = wire(supplied_by_pin[pin].explain_literature(publication))
                            require(payload == publication_oracles[key], 'Publication differs from complete independent native explanation of exact supplied target')
                            if 'pubmed:20889239' in link.label and name in ('bts', 'benz', 'full-molecule-deck'):
                                require(len(payload['links']) == 459, 'Complete 459-link publication lost')
                            if 'pubmed:35189560' in link.label and name in ('bts', 'benz', 'full-molecule-deck'):
                                require(len(payload['links']) == 9, 'Complete nine-link publication lost')
                        if role == 'target_card' and lp == prefix and name in ('bts', 'benz'):
                            remember(lp + '/fresh-publications', opened.explorer.answer('publications'))
                            remember(lp + '/fresh-measured-molecules', opened.explorer.answer('measured_molecules'))
                if groups.items():
                    filtered_groups = remember(prefix + '/bts-groups', groups.filter('molecule_ref', equals='chembl:CHEMBL1161789'))
                    remember(prefix + '/ordered-bts-groups', filtered_groups.sort('measurement', unit='nanomolar'))
                    remember(prefix + '/null-measurement-groups', groups.filter('measurement', equals=None))
                    query(prefix + '/candidate-quantity', options=group_options,
                        where={'molecule_ref': 'chembl:CHEMBL1161789', 'measurement': {'value': 33, 'unit': 'micromolar'}},
                        order_by={'column': 'measurement', 'unit': 'nanomolar'})
            try:
                root.save(output / ('refused-' + name + '.json'))
            except StorageError as error:
                refusals.append({'operation': 'save', 'exception': type(error).__name__, 'message': str(error)})
            else:
                raise RuntimeError('New scientific profile saved before independent reader')
            require(not (output / ('refused-' + name + '.json')).exists(), 'Refused save wrote an artifact')
            human = {label: view_record(view, store) for label, view in named.items()}
            foci = {v.explorer.access._focal_key: v.explorer.access for v in named.values()}
            cases[name] = store.save('cases/' + name + '.json', {'inputs': spec,
                'human': human, 'machine': queries, 'operations': operations, 'refusals': refusals,
                'publication_oracles': {key: store.put(value) for key, value in publication_oracles.items()},
                'access_states': {key: access_record(access, store) for key, access in foci.items()}})
            require(input_before == [c.to_dict() for c in [molecule, *related]], 'Exploration mutated knowledge')
            print(json.dumps({'case_complete': name, 'human_views': len(human), 'queries': len(queries), 'members_so_far': len(store.files)}), flush=True)
    require(not any(attempts.values()) and sha(Path(__file__)) == helper_hash and source_state(HEAD, VERSION) == before, 'Acquisition or producer drift')
    for name, value in prior_files.items():
        require(store.files[name] == value and sha(output / name) == value['sha256'] and (output / name).stat().st_size == value['bytes'], 'Prior original member was changed')
    store.save('source-files.json', before)
    environment = {'python': sys.version, 'executable': sys.executable, 'platform': platform.platform(),
        'packages': {n: metadata.version(n) for n in ('sabueso', 'pyunitwizard', 'argdigest', 'smonitor', 'depdigest', 'ackredit', 'pytest', 'pytest-receptor')}}
    store.save('manifest.json', {'capture_complete': True, 'admitted_saved_format': False,
        'producer_head': HEAD, 'producer_version': VERSION, 'created_utc': datetime.now(timezone.utc).isoformat(),
        'environment': environment, 'attempts': attempts, 'cases': cases, 'files': dict(store.files),
        'resumption': {'resumed': args.resume, 'already_complete_cases': resumed_cases,
            'prior_members': len(prior_files), 'all_prior_member_bytes_unchanged': True,
            'cause': 'Initial helper expected missing_prerequisite for a distinct nonprotein context; actual unchanged producer returns unsupported. Previously completed cases are never regenerated.',
            'initial_terminal_resource': 'capture-initial-resource.json' if args.resume else None},
        'owner': '#148/#112', 'review_trigger': 'Independent molecule-activity original reader, transport and copied receiving',
        'kind': 'Genuine clean SDK205 complete LIVE pre-reader original; no successful save and no independent reader',
        'scope': 'All actual named human views, exact machine requests/pages, complete access objects/native wires/captured Cards and source locations. Source/publication navigation includes complete original nine/459-link contexts. Synthetic modifications are declared per input case. Auto-created transient views are not additional observed UI routes.',
        'packaging': 'Envelope refs {path,bytes,sha256} point to complete canonical JSON members. Content deduplication never shortens values, native wires, source inputs or publication contexts.'})
    print(json.dumps({'capture_complete': True, 'output': str(output), 'cases': len(cases), 'members': len(store.files)}), flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--prepare-inputs', action='store_true'); mode.add_argument('--capture', action='store_true')
    parser.add_argument('--resume', action='store_true')
    parser.add_argument('--inputs', type=Path); parser.add_argument('--input-manifest-sha256')
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args(); output = args.output.resolve()
    require(output.is_relative_to(BASE) and output != BASE and (not output.exists() or args.resume), 'Output must be a new owned evidence path or explicit incomplete resumption')
    if args.prepare_inputs:
        prepare(output)
    else:
        require(args.inputs is not None and args.input_manifest_sha256, 'Capture requires exact prepared inputs')
        args.inputs = args.inputs.resolve()
        require(args.inputs.is_relative_to(BASE) and args.inputs.is_dir() and not output.is_relative_to(args.inputs), 'Inputs must be separate owned immutable preparation')
        capture(args, output)


if __name__ == '__main__':
    main()


