"""Observe the genuine clean SDK234 producer before independent sequence reading."""
from contextlib import ExitStack
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import importlib.metadata as metadata
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
from unittest.mock import patch
from urllib.parse import unquote, urlparse

BASE=Path(__file__).resolve().parent
ROOT=BASE.parents[2]
EXPECTED=json.loads((BASE/'expected-producer.json').read_text())
spec=importlib.util.spec_from_file_location('sequence_original_observation',BASE/'observation_helpers.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)


def git(*args):
    return subprocess.check_output(['git','-C',str(ROOT),*args],text=True).strip()


def source_state():
    import sabueso,sabueso._version
    from sabueso.core.card_sequence_change_access import descriptor
    h.require(git('rev-parse','HEAD')==EXPECTED['head'] and not git('status','--porcelain=v1','--untracked-files=all'),'Exact clean committed producer required')
    h.require({sabueso.__version__,sabueso._version.__version__,metadata.version('sabueso')}=={EXPECTED['version']},'Producer labels differ')
    direct=json.loads(metadata.distribution('sabueso').read_text('direct_url.json'))
    h.require(direct['dir_info']['editable'] and Path(unquote(urlparse(direct['url']).path)).resolve()==ROOT,'Wrong editable origin')
    h.require(Path(sabueso.__file__).resolve()==ROOT/'sabueso/__init__.py' and not descriptor()['save'],'Capture must precede original save admission')
    for name in ('card_sequence_change_history_v1.py','card_exploration_sequence_change.py','_sequence_change_history_v1'):
        h.require(not (ROOT/'sabueso/core'/name).exists(),'Independent sequence-change reader already exists')
    names=set(git('ls-files','--','sabueso','tests','conftest.py','pyproject.toml','.github/workflows').splitlines())|{'sabueso/_version.py'}
    return {name:h.sha(ROOT/name) for name in sorted(names)}


class Attempts(dict):
    def __init__(self,name):
        self.path=BASE/(name+'-attempts.json')
        super().__init__(network=0,source_acquisitions=0)
        self.persist()
    def persist(self):self.path.write_text(json.dumps(self,indent=2)+'\n')
    def __setitem__(self,key,value):
        super().__setitem__(key,value);self.persist()


def prepare(module):
    from sabueso.core.card import Card
    cases={}
    def add(name,card,description,*,mode='both',order='human_first',related=(),follow=False):
        cases[name]={'focal':card.to_dict(),'related':[c.to_dict() for c in related],
                     'options':{},'synthetic_control':description,'route_mode':mode,
                     'route_order':order,'follow_ready_structural_questions':follow}
    add('public-human-first',module.public.__wrapped__(),None,follow=True)
    add('public-machine-first',module.public.__wrapped__(),None,order='machine_first')
    add('synthetic-mixed',module.synthetic(),'Labelled synthetic natural-variant/mutagenesis records at equal positions, with multiple alternatives.',follow=True)
    add('bare',module.synthetic([]),'Synthetic missing annotation fields; not evidence of biological absence.')
    raw=module.synthetic([]).to_dict()
    raw['sections'].setdefault('features_positional',{}).update(natural_variant={'value':[]},mutagenesis={'value':[]})
    add('retained-empty',Card.from_dict(raw),'Synthetic explicitly retained empty Card lists, without a source absence claim.')
    raw=deepcopy(raw);raw['sections']['features_positional']['natural_variant']['value']=['explicit malformed synthetic row']
    add('malformed-field',Card.from_dict(raw),'Synthetic malformed list member; preserve explicit field gap.')
    for label,changes in [('uncertain-start',{'modifier':'LESS_THAN'}),('unknown-start',{'modifier':'UNKNOWN'}),('missing-end',{'end':None}),('foreign-molecule',{'molecule':'P60174-2'})]:
        f=module.feature()
        if 'modifier' in changes:f['location']['start']['modifier']=changes['modifier']
        if 'end' in changes:f['location']['end']['value']=changes['end']
        if 'molecule' in changes:f['molecule']=changes['molecule']
        add(label,module.synthetic([f]),'Synthetic '+label+' source scope; no canonical/genomic correspondence invented.')
    first=module.feature();second=deepcopy(first);second['explicit_synthetic_source_context']='second original native context'
    add('multiple-native-contexts',module.synthetic([first,second]),'Synthetic two distinct native statements supporting one equal normalized Card value; retain both without unique feature correspondence.')
    raw=module.synthetic([module.feature()]).to_dict();field=raw['sections']['features_positional']['natural_variant'];field['value'].append(deepcopy(field['value'][0]))
    add('equal-card-occurrences',Card.from_dict(raw),'Synthetic repeated equal Card list values; distinct typed locations remain separate.')
    for label,missing,alternatives in [('stated-deletion',True,None),('stated-false',False,[]),('unstated-change',None,None)]:
        raw=module.synthetic([module.feature()]).to_dict();row=raw['sections']['features_positional']['natural_variant']['value'][0];row['substitution']={'original':'M'}
        if missing is not None:row['substitution']['missing']=missing
        if alternatives is not None:row['substitution']['alternatives']=alternatives
        add(label,Card.from_dict(raw),'Synthetic Card input substitution '+label+'; deliberately changed normalized value retains partial original support, never a new source claim.')
    for defect in ('missing','subject','field','normalized-value','conflict'):
        raw=module.synthetic([module.feature()]).to_dict();field=raw['sections']['features_positional']['natural_variant'];ref=field['source_assertion_ids'][0];source=next(s for s in raw['source_assertion_store'] if s['id']==ref)
        if defect=='missing':raw['source_assertion_store'].remove(source)
        elif defect=='subject':source['subject_ref']='uniprot:FOREIGN'
        elif defect=='field':source['field_path']='features_positional.mutagenesis'
        elif defect=='normalized-value':field['value'][0]['description']='synthetic changed normalized description'
        else:raw['quality'].setdefault('conflicts',[]).append({'field':'features_positional.natural_variant','values':['selected','synthetic conflicting context']})
        add('support-'+defect,Card.from_dict(raw),'Synthetic '+defect+' input/support context; unknown, contextual and conflicting records remain explicit.')
    for column,value in [('start',True),('start',2.0),('missing','false'),('alternatives',[1]),('substitution',['synthetic malformed container'])]:
        raw=module.synthetic([module.feature()]).to_dict();row=raw['sections']['features_positional']['natural_variant']['value'][0]
        target=row['location']['sequence'] if column=='start' else row if column=='substitution' else row['substitution'];target[column]=value
        suffix='bool' if type(value)is bool else 'float' if type(value)is float else column
        add('malformed-'+suffix,Card.from_dict(raw),'Synthetic malformed '+column+' input; retain literal source value and typed unrecognized cell state.')
    f=module.feature(description='<script>explicit synthetic text</script>')
    add('escaped-source',module.synthetic([f]),'Synthetic source markup; retain literal value and separately escaped human rendering.')
    f=module.feature(description='explicit synthetic long description '*1000)
    add('deferred-values',module.synthetic([f]),'Synthetic long label/description exercises atomic compact value/interpretation deferral.')
    f=module.feature();f['source_owned']={'format':'source-owned@99','adapter':'source-owned@9','rule':'source-owned@7','sabueso_version':'literal-source-label','context':False,'values':[False,0,0.0,None],'reference_lookalike':{'path':'values/source-owned.json','bytes':0,'sha256':'source-owned'}}
    add('opaque-source',module.synthetic([f]),'Synthetic opaque native source metadata; reference/format/version-looking values stay literal.')
    card=module.synthetic();revision=Card.from_dict(card.to_dict());revision.quality['explicit_synthetic_revision']='second supplied revision'
    add('input-revisions',card,'Synthetic repeated explicit input occurrences and a separate supplied revision; only the focal capture drives this projection.',related=[card,card,revision])
    add('human-only',module.synthetic(),'Synthetic human-topic-only observed history; no question or compact request was executed.',mode='human_only')
    add('machine-only',module.synthetic(),'Synthetic compact-only observed history; no human view or question was executed.',mode='machine_only',order='machine_first')
    return cases


def main():
    from sabueso.core.card import Card
    from sabueso.core import card_sequence_change_access as adapter
    from sabueso.core.card_sequence_change_selection_v1 import COLUMNS
    from sabueso.core.card_exploration_storage import _FLAGS
    before=source_state();output=BASE/sys.argv[1];h.require(not output.exists(),'Never overwrite an original')
    module_path=ROOT/'tests/core/test_card_sequence_changes_offline.py'
    spec=importlib.util.spec_from_file_location('sequence_original_inputs',module_path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    preparation=Attempts(output.name+'-preparation')
    with ExitStack() as stack:
        h.guards(stack,preparation,acquisitions=True);inputs=prepare(module)
    h.require(not any(preparation.values()),'Preparation attempted acquisition')
    if sys.argv[2:]:inputs={k:inputs[k] for k in sys.argv[2:]}
    store=h.Store(output)
    for source,target in [(Path(__file__),'capture-script.py'),(BASE/'observation_helpers.py','observation-helpers.py'),(module_path,'input-test-module.py'),(BASE/'expected-producer.json','producer.json'),(ROOT/'LICENSE','LICENSE')]:store.copy(source,target)
    for name in ('P60174.json','NOTICE.md'):store.copy(ROOT/'temp_data'/name,'fixtures/'+name)
    notice='''# Sequence-change genuine LIVE original — source and rights

Public HsTIM inputs retain the source/date/licence declarations in fixtures/NOTICE.md. UniProt data retains CC BY 4.0 attribution. The public fixture has eight natural-variant annotations and no mutagenesis annotation. Authored capture code and explicitly labelled synthetic controls follow the repository MIT LICENSE. No private or pilot material is included. Observations do not relicense source statements.

This finite genuine original comes from clean SDK234 before independent sequence-change saved reading. It is not an admitted saved exploration, source authentication, scientific or human acceptance. Network and source acquisition are forbidden during preparation and observation. The oracle records captured Card field occurrences directly, independently of adapter materialization. Each actual view, access, parent, source, input occurrence, executed typed request and page is retained. Human-only and compact-only histories remain different. Content references share bytes, never scientific identity. Original source-looking reference/version/format values stay literal. Owner: Sabueso #148/#112; review at independent receiving and B6 block closeout.
'''
    (output/'NOTICE.md').write_text(notice,encoding='utf-8');store.index(output/'NOTICE.md')
    store.save('source-before.json',before);store.save('inputs.json',inputs)
    attempts=Attempts(output.name);cases={}
    with ExitStack() as stack:
        h.guards(stack,attempts,acquisitions=True)
        for name,data in inputs.items():
            print('Capturing '+name,flush=True)
            focal=Card.from_dict(deepcopy(data['focal']));related=[Card.from_dict(deepcopy(v)) for v in data['related']];cards=[focal,*related];original_cards=[c.to_dict() for c in cards]
            explorer=focal.explore(related_cards=related);named={};queries=[];events=[]
            oracle_fields=deepcopy(data['focal'].get('sections',{}).get('features_positional',{}))
            oracle_items=[deepcopy(v) for kind in sorted(oracle_fields or {}) if kind in ('natural_variant','mutagenesis') for v in ((oracle_fields[kind].get('value') or []) if isinstance(oracle_fields[kind],dict) and isinstance(oracle_fields[kind].get('value'),list) else []) if isinstance(v,dict)]
            def remember(label,view):
                h.require(label not in named,'Duplicate named observation');named[label]=view;events.append({'operation':'human','label':label,'view':view});return view
            def machine(label,request,*,budget=65536):
                selection=explorer.access.select('sequence_changes',**request);events.append({'operation':'select','label':label,'selection_ref':selection.selection_ref,'request':deepcopy(request)})
                pages=[];cursor=None;seen=set()
                while True:
                    page=selection.page(limit=3,max_bytes=budget,cursor=cursor);h.require(page['page']['blocked'] is None,'Incomplete actual compact page');pages.append(store.put(page));cursor=page['page']['next_cursor']
                    if cursor is None:break
                    h.require(cursor not in seen,'Repeated original cursor');seen.add(cursor)
                queries.append({'label':label,'request':deepcopy(request),'page_options':{'limit':3,'max_bytes':budget},'selection_ref':selection.selection_ref,'count':selection.count,'pages':pages})
                return selection
            if data['route_order']=='machine_first':first=machine('first-executed-machine',{})
            else:first=remember('root',explorer.view('sequence_changes'))
            results=[r for r in explorer.access._scientific_cache.values() if hasattr(r,'wire') and r.wire['context']['adapter']=='sequence_change_exploration@1']
            h.require(len(results)==1,'One shared source projection expected');result=results[0]
            h.require(h.ENCODER.encode(result.native['items'])==h.ENCODER.encode(oracle_items),'Projection differs from direct captured field occurrences')
            with ExitStack() as cached:
                def forbidden_projection(*args,**kwargs):raise RuntimeError('Observed cached operations must not rematerialize the sequence projection')
                cached.enter_context(patch.object(adapter._AnnotationInputs,'__init__',forbidden_projection))
                if data['route_mode']!='machine_only':
                    if 'root' not in named:remember('root',explorer.view('sequence_changes'))
                    if data['route_mode']!='human_only':
                        question=remember('question',explorer.answer('sequence_changes'))
                        remember('topics',explorer.topics());remember('questions',explorer.questions());remember('overview',explorer.overview())
                        remember('ordered',question.sort('start',descending=True));remember('natural-only',question.filter('feature_type',equals='natural_variant'))
                        remember('mutagenesis-only',question.filter('feature_type',equals='mutagenesis'));remember('empty',question.filter('label',equals='explicit synthetic absent'))
                        remember('missing-flag',question.filter('missing',equals=None));remember('false-flag',question.filter('missing',equals=False));remember('true-flag',question.filter('missing',equals=True))
                    for parent_name in (['root'] if data['route_mode']=='human_only' else ['question','ordered']):
                        parent=named[parent_name]
                        for index,item in enumerate(parent.items()):
                            prefix=f'{parent_name}:item-{index}'
                            opened=remember(prefix+':open',item.open());explained=remember(prefix+':explain',item.explain());links=remember(prefix+':related',item.related())
                            h.require(opened.back() is parent and explained.back() is parent and links.back().back() is parent,'Actual sequence source origin lost')
                            for position,link in enumerate(links.items()):
                                declaration=link._entry.value
                                if declaration['role']=='question' and declaration['availability']=='available' and not data['follow_ready_structural_questions']:
                                    events.append({'operation':'unvisited_structural_question','view':links,'item_ref':link.item_ref});continue
                                destination=remember(prefix+f':link-{position}',link.open());h.require(destination.back() is links,'Original source/question back edge lost')
                                if declaration['role']!='question':h.require(destination.request==parent.request,'Inherited source question changed')
                                if declaration.get('candidates') and declaration['role']!='question':
                                    candidate=declaration['candidates'][0];h.require(destination._explorer.access._focal_key==candidate['capture'],'Source focal mismatch')
                                    for child_index,child in enumerate(list(destination.items())[:3]):
                                        child_view=remember(prefix+f':link-{position}:child-{child_index}',child.open());h.require(child_view.back() is destination,'Literal child source origin lost')
                if data['route_mode']!='human_only':
                    refs=[adapter.item_ref(result,e) for e in result.entries]
                    requests=[('default',{}),('all-fields',{'fields':list(COLUMNS)}),('no-fields',{'fields':[]}),('empty-membership',{'item_refs':[]}),('reverse-membership',{'item_refs':refs[:2][::-1]}),('natural-only',{'where':{'feature_type':'natural_variant'}}),('mutagenesis-only',{'where':{'feature_type':'mutagenesis'}}),('null-start',{'where':{'start':None}}),('null-missing',{'where':{'missing':None}}),('false-missing',{'where':{'missing':False}}),('true-missing',{'where':{'missing':True}}),('alternatives',{'where':{'alternatives':['A','G']}}),('ordered',{'order_by':{'column':'start','descending':True}}),('ascending',{'order_by':{'column':'start','descending':False}}),('partial-support',{'where':{'support_state':'partial'}}),('absent-label',{'where':{'label':'explicit synthetic absent'}})]
                    for label,request in requests:machine(label,request)
                    if name=='deferred-values':machine('atomic-deferred',{'fields':['description','alternatives']},budget=8000)
                views=[];ids={};accesses=[];access_ids={}
                def node(view):
                    if view is None:return None
                    if id(view) not in ids:ids[id(view)]='V'+str(len(views));views.append(view)
                    return ids[id(view)]
                def aid(access):
                    if id(access) not in access_ids:access_ids[id(access)]='A'+str(len(accesses));accesses.append(access)
                    return access_ids[id(access)]
                root_access=aid(explorer.access)
                for view in [*named.values(),*explorer._session['views'].values()]:node(view)
                records=[]
                for view in views:
                    h.require(len(views)<30000,'Unexpected unbounded observation graph')
                    records.append({'node':node(view),'access_node':aid(view._explorer.access),'selection_access_node':aid(view._selection._access),'origin_node':node(view._origin),'explorer_origin_node':node(view._explorer._origin),'observation_ref':store.put(h.view_record(view,store)),'flags':{k:getattr(view,k) for k in _FLAGS},'runtime_state_refs':{k:store.put(getattr(view,k)) for k in ('_native_override','_component_navigation','_workload')}})
                    for actual in explorer._session['views'].values():node(actual)
                first_access=explorer.access;full=h.access_record(first_access,store)
                shared={'inputs':'_inputs','captures':'_captures','objects':'_objects','locations':'_locations','metadata_refs':'_metadata_refs','native_cache':'_scientific_cache','scientific_cache':'_scientific_cache'}
                common={key:store.put(full[key]) for key in shared};access_records={}
                for access in accesses:
                    h.require(all(getattr(access,attribute) is getattr(first_access,attribute) for attribute in shared.values()),'Unexpected independent access containers')
                    fields=dict(common);fields.update(cursors=store.put(access._cursors),tokens=store.put([{'selection_ref':k[0],'offset':k[1],'token':v} for k,v in access._tokens.items()]),scientific_items=store.put({k:{'result_ref':v[0].result_ref,'entry_key':v[1]} for k,v in access._scientific_items.items()}),selections=store.put({k:h.selection_record(v,store) for k,v in access._selections.items()}))
                    access_records[aid(access)]={'focal':access._focal_key,'nonce':access._nonce,'fields':fields}
                case={'input':store.put(data),'options':{},'synthetic_control':data['synthetic_control'],'route_mode':data['route_mode'],'route_order':data['route_order'],'source_oracle':store.put({'field_inputs':oracle_fields,'items':oracle_items}),'projection_result_ref':result.result_ref,'root_access_node':root_access,'named_views':{label:node(view) for label,view in named.items()},'views':records,'queries':queries,'accesses':access_records,'api_order':[{k:v for k,v in e.items() if k!='view'}|({'view_node':node(e['view'])} if 'view'in e else {}) for e in events],'session_operations':{kind:{k:node(v) for k,v in explorer._session[kind].items()} for kind in ('explanations','links')}}
                cases[name]=store.save('cases/'+name+'.json',case)
            h.require([c.to_dict() for c in cards]==original_cards,'Input Card mutated')
    after=source_state();h.require(before==after and not any(attempts.values()),'Source changed or forbidden attempt recorded');store.save('source-after.json',after)
    manifest={'format':'sequence_change_live_original@1','genuine_live_original':True,'capture_complete':True,'producer_head':EXPECTED['head'],'producer_version':EXPECTED['version'],'captured_utc':datetime.now(timezone.utc).isoformat(),'cases':cases,'files':dict(store.files),'source_stable':True,'preparation_attempts':dict(preparation),'attempts':dict(attempts),'scope':'Finite complete actual LIVE source/cell/request/page/parent/access/navigation observations. Public HsTIM plus labelled synthetic controls; human-only and machine-only histories remain distinct. Direct Card field oracle is independent of projection materialization. No source acquisition, saved-reader admission, scientific truth or human acceptance.'}
    store.save('manifest.json',manifest)
    print(json.dumps({'state':'CAPTURE_COMPLETE','cases':len(cases),'files':len(store.files),'producer':EXPECTED,'source_stable':True,'attempts':dict(attempts)},indent=2))


if __name__=='__main__':main()
