"""Observe the clean SDK243 knowledge producer before independent saved reading."""
from contextlib import ExitStack
from copy import deepcopy
from datetime import datetime, timezone
import importlib.metadata as metadata
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
from unittest.mock import patch
from urllib.parse import unquote, urlparse

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[2]
EXPECTED = json.loads((BASE/'expected-producer.json').read_text())
spec = importlib.util.spec_from_file_location('knowledge_original_observation', BASE/'observation_helpers.py')
h = importlib.util.module_from_spec(spec); spec.loader.exec_module(h)
spec = importlib.util.spec_from_file_location('knowledge_original_prepare', BASE/'prepare_inputs.py')
preparer = importlib.util.module_from_spec(spec); spec.loader.exec_module(preparer)


def git(*args):
    return subprocess.check_output(['git','-C',str(ROOT),*args], text=True).strip()


def source_state():
    import sabueso, sabueso._version
    h.require(git('rev-parse','HEAD') == EXPECTED['head'] and not git('status','--porcelain=v1','--untracked-files=all'), 'Exact clean committed producer required')
    h.require({sabueso.__version__,sabueso._version.__version__,metadata.version('sabueso')} == {EXPECTED['version']}, 'Producer labels differ')
    direct=json.loads(metadata.distribution('sabueso').read_text('direct_url.json'))
    h.require(direct['dir_info']['editable'] and Path(unquote(urlparse(direct['url']).path)).resolve() == ROOT, 'Wrong editable origin')
    h.require(Path(sabueso.__file__).resolve() == ROOT/'sabueso/__init__.py', 'Wrong implementation origin')
    for name in ('card_knowledge_comparison_history_v1.py','card_exploration_knowledge_comparison.py','_knowledge_comparison_history_v1'):
        h.require(not (ROOT/'sabueso/core'/name).exists(), 'Independent comparison reader already exists')
    names=set(git('ls-files','--','sabueso','tests','conftest.py','pyproject.toml','.github/workflows').splitlines())|{'sabueso/_version.py'}
    return {name:h.sha(ROOT/name) for name in sorted(names)}


class Attempts(dict):
    def __init__(self,name):
        self.path=BASE/(name+'-attempts.json')
        super().__init__(network=0,source_acquisitions=0,card_reconstruction=0,assertion_creation=0)
        self.persist()
    def persist(self):self.path.write_text(json.dumps(self,indent=2)+'\n')
    def __setitem__(self,key,value):
        super().__setitem__(key,value);self.persist()


def main():
    from sabueso.core.card import Card
    from sabueso.core import card_knowledge_comparison_access as adapter
    from sabueso.core import card_knowledge_diff_v2 as native
    from sabueso.core import source_assertion_store
    from sabueso.core.card_protein_context_selection_v1 import COLUMNS
    from sabueso.core.card_exploration_storage import _FLAGS
    before=source_state();output=BASE/sys.argv[1];h.require(not output.exists(),'Never overwrite an original')
    module_path=ROOT/'tests/core/test_card_knowledge_diff_v2_offline.py'
    spec=importlib.util.spec_from_file_location('knowledge_original_inputs',module_path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    preparation=Attempts(output.name+'-preparation')
    prepared=BASE/'prepared-inputs.json'
    with ExitStack() as stack:
        h.guards(stack,preparation,acquisitions=True)
        inputs=json.loads(prepared.read_text()) if prepared.exists() else preparer.prepare(module)
    h.require(not any(preparation.values()),'Preparation attempted acquisition')
    all_inputs=deepcopy(inputs)
    if sys.argv[2:]:inputs={k:inputs[k] for k in sys.argv[2:]}
    store=h.Store(output)
    for source,target in [(Path(__file__),'capture-script.py'),(BASE/'prepare_inputs.py','prepare-inputs.py'),(BASE/'observation_helpers.py','observation-helpers.py'),(module_path,'input-test-module.py'),(BASE/'expected-producer.json','producer.json'),(ROOT/'LICENSE','LICENSE')]:
        store.copy(source,target)
    for name in ('P52270.json','P60174.json','NOTICE.md'):
        store.copy(ROOT/'temp_data'/name,'fixtures/'+name)
    notice='''# Knowledge-comparison genuine LIVE original — source and rights

Existing frozen UniProt public inputs retain source/date/licence declarations in fixtures/NOTICE.md. Authored instrumentation and explicitly labelled synthetic controls follow the repository MIT LICENSE. Observations do not relicense source statements. No private or pilot content is included.

This finite genuine original is captured from clean SDK243 before independent knowledge-comparison saved reading. Complete actual views, distinct access instances, support and actual parent/input graphs and finite executed compact requests/pages are retained. Synthetic values and caller maps are representational controls, not validated scientific correspondence. Human-only and machine-only histories remain distinct. Source-owned packaging/version lookalikes remain ordinary literal values. Capture and verification do not establish scientific authentication, researcher acceptance or saved-reader admission. Owner Sabueso #148/#193/#112; retain through independent receiving and B6 closeout.
'''
    (output/'NOTICE.md').write_text(notice);store.index(output/'NOTICE.md');store.save('source-before.json',before);store.save('inputs.json',all_inputs)
    attempts=Attempts(output.name);cases={}
    with ExitStack() as stack:
        h.guards(stack,attempts,acquisitions=True)
        for name,data in inputs.items():
            print('Capturing '+name,flush=True)
            focal=Card.from_dict(deepcopy(data['focal']));related=[Card.from_dict(deepcopy(v)) for v in data['related']];cards=[focal,*related];original_cards=[c.to_dict() for c in cards]
            mapping=data['residue_map']
            expected_native=focal.compare_knowledge(cards[data['other_index']],residue_map=None if mapping is None else dict(mapping),comparison_rule='card_knowledge_diff@2')
            explorer=focal.explore(related_cards=related);named={};queries=[];events=[];topic=data['topic'];question='knowledge_differences'
            options={'mode':'knowledge','other_ref':explorer.context['inputs'][data['other_index']],'residue_map':deepcopy(mapping)}
            def remember(label,view):
                h.require(label not in named,'Duplicate named observation');named[label]=view;events.append({'operation':'human','label':label,'view':view});return view
            def machine(label,request,*,budget=65536):
                selection=explorer.access.select(topic,options=options,**request);events.append({'operation':'select','label':label,'selection_ref':selection.selection_ref,'request':deepcopy(request)})
                pages=[];cursor=None;seen=set()
                while True:
                    page=selection.page(limit=3,max_bytes=budget,cursor=cursor);h.require(page['page']['blocked'] is None,'Incomplete actual compact page');pages.append(store.put(page));cursor=page['page']['next_cursor']
                    if cursor is None:break
                    h.require(cursor not in seen,'Repeated original cursor');seen.add(cursor)
                queries.append({'label':label,'topic':topic,'options':deepcopy(options),'request':deepcopy(request),'page_options':{'limit':3,'max_bytes':budget},'selection_ref':selection.selection_ref,'count':selection.count,'pages':pages})
                return selection
            calls=[]
            actual_compare=native.compare
            def observed_compare(*args,**kwargs):
                calls.append(1);return actual_compare(*args,**kwargs)
            def forbidden(kind):
                def reject(*args,**kwargs):
                    attempts[kind]+=1;raise RuntimeError('Forbidden construction during inert observation')
                return reject
            with ExitStack() as observation:
                observation.enter_context(patch.object(native,'compare',observed_compare))
                for attribute in ('__init__','from_dict','compare_knowledge'):
                    observation.enter_context(patch.object(Card,attribute,forbidden('card_reconstruction')))
                observation.enter_context(patch.object(source_assertion_store,'make_source_assertion',forbidden('assertion_creation')))
                if data['route_order']=='machine_first':first=machine('first-executed-machine',{})
                else:first=remember('root',explorer.answer(question,options=options))
                results=[r for r in explorer.access._scientific_cache.values() if hasattr(r,'wire') and r.wire['context']['adapter']==adapter.ADAPTER]
                h.require(len(results)==1,'One first shared projection expected');result=results[0]
                h.require(h.ENCODER.encode(result.native)==h.ENCODER.encode(expected_native),'Projection differs from explicit direct Card native oracle')
                oracle={'native':expected_native,'input_cards':original_cards,'supplied_occurrences':deepcopy(explorer.context['inputs'][1:])}
                if data['route_mode']!='machine_only':
                    if 'root' not in named:remember('root',explorer.answer(question,options=options))
                    if data['route_mode']!='human_only':
                        answer=remember('question',explorer.answer(question,options=options));remember('topics',explorer.topics());remember('questions',explorer.questions());remember('overview',explorer.overview())
                        remember('ordered',answer.sort('label',descending=True));remember('fields',answer.filter('kind',equals='knowledge_field'));remember('empty',answer.filter('label',equals='explicit synthetic absent'))
                        remember('null-identical',answer.filter('identical',equals=None));remember('false-identical',answer.filter('identical',equals=False));remember('true-identical',answer.filter('identical',equals=True))
                    for parent_name in (['root'] if data['route_mode']=='human_only' else ['question','ordered']):
                        parent=named[parent_name]
                        for index,item in enumerate(parent.items()):
                            prefix=f'{parent_name}:item-{index}';opened=remember(prefix+':open',item.open());explained=remember(prefix+':explain',item.explain());links=remember(prefix+':related',item.related())
                            h.require(opened.back() is parent and explained.back() is parent and links.back() is parent,'Actual context origin lost')
                            for position,link in enumerate(links.items()):
                                destination=remember(prefix+f':link-{position}',link.open());h.require(destination.back() is links,'Original source back edge lost')
                                h.require(destination.request==parent.request,'Inherited source question changed')
                                declaration=link._entry.value
                                if declaration.get('candidates') and destination.explorer is not None:
                                    if len(declaration['candidates'])==1:h.require(destination._explorer.access._focal_key==declaration['candidates'][0]['capture'],'Source focal mismatch')
                                    if not destination._route_catalog and not destination._question_catalog:
                                        for child_index,child in enumerate(list(destination.items())[:2]):
                                            child_view=remember(prefix+f':link-{position}:child-{child_index}',child.open());h.require(child_view.back() is destination,'Literal child source origin lost')
                if data['route_mode']!='human_only':
                    refs=[adapter.item_ref(result,e) for e in result.entries]
                    requests=[('default',{}),('all-fields',{'fields':list(COLUMNS)}),('no-fields',{'fields':[]}),('empty-membership',{'item_refs':[]}),('reverse-membership',{'item_refs':refs[:2][::-1]}),('fields',{'where':{'kind':'knowledge_field'}}),('maps',{'where':{'kind':'supplied_residue_map'}}),('null-count',{'where':{'difference_count':None}}),('null-identical',{'where':{'identical':None}}),('false-identical',{'where':{'identical':False}}),('true-identical',{'where':{'identical':True}}),('zero-count',{'where':{'difference_count':0}}),('ordered',{'order_by':{'column':'label','descending':True}}),('ascending',{'order_by':{'column':'difference_count','descending':False}}),('partial-support',{'where':{'support_state':'partial'}}),('absent-label',{'where':{'label':'explicit synthetic absent'}})]
                    for label,request in requests:machine(label,request)
                    if name=='deferred-values':machine('atomic-deferred',{'fields':['label','object_ref']},budget=16000)
                h.require(len(calls)==1,'Human and compact routes must share one native execution')
                views=[];ids={};accesses=[];access_ids={}
                def node(view):
                    if view is None:return None
                    if id(view) not in ids:ids[id(view)]='V'+str(len(views));views.append(view)
                    return ids[id(view)]
                def aid(access):
                    if id(access) not in access_ids:access_ids[id(access)]='A'+str(len(accesses));accesses.append(access)
                    return access_ids[id(access)]
                root_access=aid(explorer.access)
                for view in [*named.values(),*explorer._session['views'].values()]:node(view)
                records=[]
                for view in views:
                    h.require(len(views)<30000,'Unexpected unbounded observation graph')
                    records.append({'node':node(view),'access_node':aid(view._explorer.access),'selection_access_node':aid(view._selection._access),'origin_node':node(view._origin),'explorer_origin_node':node(view._explorer._origin),'observation_ref':store.put(h.view_record(view,store)),'flags':{k:getattr(view,k) for k in _FLAGS},'runtime_state_refs':{k:store.put(getattr(view,k)) for k in ('_native_override','_component_navigation','_workload')}})
                    for actual in explorer._session['views'].values():node(actual)
                first_access=explorer.access;full=h.access_record(first_access,store)
                shared={'inputs':'_inputs','captures':'_captures','objects':'_objects','locations':'_locations','metadata_refs':'_metadata_refs','native_cache':'_scientific_cache','scientific_cache':'_scientific_cache'}
                common={key:store.put(full[key]) for key in shared};access_records={}
                for access in accesses:
                    h.require(all(getattr(access,attribute) is getattr(first_access,attribute) for attribute in shared.values()),'Unexpected independent access containers')
                    fields=dict(common);fields.update(cursors=store.put(access._cursors),tokens=store.put([{'selection_ref':k[0],'offset':k[1],'token':v} for k,v in access._tokens.items()]),scientific_items=store.put({k:{'result_ref':v[0].result_ref,'entry_key':v[1]} for k,v in access._scientific_items.items()}),selections=store.put({k:h.selection_record(v,store) for k,v in access._selections.items()}))
                    access_records[aid(access)]={'focal':access._focal_key,'nonce':access._nonce,'fields':fields}
                case={'input':store.put(data),'topic':topic,'options':deepcopy(options),'question':question,'synthetic_control':data['synthetic_control'],'route_mode':data['route_mode'],'route_order':data['route_order'],'source_oracle':store.put(oracle),'projection_result_ref':result.result_ref,'root_access_node':root_access,'named_views':{label:node(view) for label,view in named.items()},'views':records,'queries':queries,'accesses':access_records,'api_order':[{k:v for k,v in e.items() if k!='view'}|({'view_node':node(e['view'])} if 'view'in e else {}) for e in events],'native_comparison_calls':len(calls),'session_operations':{kind:{k:node(v) for k,v in explorer._session[kind].items()} for kind in ('explanations','links')}}
                cases[name]=store.save('cases/'+name+'.json',case)

            h.require([c.to_dict() for c in cards]==original_cards,'Input Card mutated')
    after=source_state();h.require(before==after and not any(attempts.values()),'Source changed or forbidden attempt recorded');store.save('source-after.json',after)
    manifest={'format':'knowledge_comparison_live_original@1','genuine_live_original':True,'capture_complete':True,'producer_head':EXPECTED['head'],'producer_version':EXPECTED['version'],'captured_utc':datetime.now(timezone.utc).isoformat(),'cases':cases,'files':dict(store.files),'source_stable':True,'prepared_inputs_sha256':h.sha(prepared) if prepared.exists() else None,'preparation_attempts':dict(preparation),'attempts':dict(attempts),'scope':'Finite complete actual LIVE source/cell/request/page/parent/access/navigation observations. Public UniProt inputs and labelled synthetic representational controls. Human-only and machine-only histories remain distinct. Explicit direct Card native oracle; one shared native execution during observation. No acquisition, Card reconstruction or SourceAssertion creation during observation. No saved-reader admission, scientific truth or human acceptance.'}
    store.save('manifest.json',manifest)
    print(json.dumps({'state':'CAPTURE_COMPLETE','cases':len(cases),'files':len(store.files),'producer':EXPECTED,'source_stable':True,'attempts':dict(attempts)},indent=2))

if __name__=='__main__':main()
