"""Finite public and labelled synthetic controls; never patch scientific rules."""
from copy import deepcopy
import json


def prepare(module):
    from sabueso.core.card import Card
    from sabueso.core.relationship_store import make_relationship
    from sabueso.core.source_assertion_store import make_source_assertion

    cases = {}

    def add(name, left, right, description, *, pairs=None, route='both',
            order='human_first', extra=(), other_index=1):
        cases[name] = {'focal': left.to_dict(),
            'related': [right.to_dict(), *[c.to_dict() for c in extra]],
            'residue_map': deepcopy(pairs), 'other_index': other_index,
            'topic': 'comparative_context', 'synthetic_control': description,
            'route_mode': route, 'route_order': order}

    def pair():
        return module.card(), module.card('RIGHT')

    public = [module.build_card_from_mapping(
        module.map_protein(json.loads((module.DATA / (identifier+'.json')).read_text()),
                           'frozen public response'),
        meta={'entity_type': 'protein'},
        card_id='sabueso:protein:uniprot:'+identifier)
        for identifier in ('P52270', 'P60174')]
    add('public-unmapped-human-first', *public, None)
    add('public-unmapped-machine-first', *public, None, order='machine_first')
    add('public-supplied-map', *public, None,
        pairs=[[12,12],[14,14],[96,96],[168,166]])
    for name, a, b in [('zero-false',0,False), ('one-float',1,1.0),
                       ('nested-types',{'x':[0,0.0,None]}, {'x':[False,0,None]})]:
        left,right=pair()
        module.stated(left,'annotations.taxon_id',a)
        module.stated(right,'annotations.taxon_id',b)
        add(name,left,right,'Synthetic typed stored representations, not real-source taxonomy or prevalence.')
    left,right=pair()
    for card,value in ((left,3.5),(right,4.5)):
        module.stated(card,'sequence.molecular_weight',value)
    add('quantity-units',left,right,'Synthetic original mass values retain the schema-declared dalton unit.')
    left,right=pair()
    module.stated(left,'annotations.function',['uninterpreted source wording'])
    module.stated(right,'annotations.function',['different original text'])
    add('free-text',left,right,'Synthetic retained free text is not semantically classified.')
    for name,pairs in [('no-map',None),('empty-map',[]),('complete-map',[[1,2],[2,3]]),('partial-map',[[1,2]])]:
        left,right=module.card(sequence='MA'),module.card('RIGHT',sequence='AMA')
        module.stated(left,module.PATH,[module.annotation(position=1),module.annotation(position=2)])
        module.stated(right,module.PATH,[module.annotation('RIGHT',2),module.annotation('RIGHT',3)])
        add(name,left,right,'Synthetic explicit correspondence; no alignment or biological correspondence validation.',pairs=pairs)
    for reverse in (False,True):
        left,right=pair()
        candidates=[module.annotation('RIGHT'),module.annotation('RIGHT',description='another literal source statement')]
        if reverse:candidates.reverse()
        module.stated(left,module.PATH,[module.annotation()])
        module.stated(right,module.PATH,candidates)
        add('ambiguous-'+('reverse' if reverse else 'forward'),left,right,
            'Synthetic duplicate comparison identities retain every candidate and original index.',pairs=[[1,1]])
    left,right=pair()
    module.stated(left,module.PATH,[module.annotation(),module.annotation()])
    module.stated(right,module.PATH,[module.annotation('RIGHT')])
    add('repeated-occurrences',left,right,'Synthetic identical-looking original occurrences stay separate.',pairs=[[1,1]])
    for defect in ('foreign-axis','unstated-axis','uncertain-boundary','wrong-indexing','huge-span'):
        left,right=pair();item=module.annotation();axis=item['location']['sequence']
        if defect=='foreign-axis':axis['sequence_id']='UniProt:FOREIGN'
        elif defect=='unstated-axis':axis.pop('sequence_id')
        elif defect=='uncertain-boundary':axis['start_modifier']='LESS_THAN'
        elif defect=='wrong-indexing':axis['indexing']='0-based'
        else:axis['end']=10**9
        module.stated(left,module.PATH,[item]);module.stated(right,module.PATH,[module.annotation('RIGHT')])
        add(defect,left,right,'Synthetic unavailable or unsupported positional scope; no inferred transfer.',pairs=[[1,1]])
    left,right=pair();a,b=module.annotation(),module.annotation('RIGHT')
    a['location']['structure']={'id':'pdb:SYNTHETIC_LEFT','chain':'A'}
    b['location']['structure']={'id':'pdb:SYNTHETIC_RIGHT','chain':'B'}
    module.stated(left,module.PATH,[a]);module.stated(right,module.PATH,[b])
    add('structure-legs',left,right,'Synthetic supplied sequence mapping preserves other original location metadata.',pairs=[[1,1]])
    for defect in ('missing-source','wrong-subject','wrong-field','wrong-value','uncited-alternative','conflict'):
        left,right=pair();record=module.stated(left,'annotations.taxon_id',0)
        module.stated(right,'annotations.taxon_id',0)
        if defect=='missing-source':left.get('annotations.taxon_id')['source_assertion_ids'].append('SA_missing')
        elif defect=='wrong-subject':left.source_assertion_store.store[record['id']]['subject_ref']='uniprot:FOREIGN'
        elif defect=='wrong-field':left.source_assertion_store.store[record['id']]['field_path']='annotations.another'
        elif defect=='wrong-value':left.source_assertion_store.store[record['id']]['asserted_value']=False
        elif defect=='uncited-alternative':
            left.get('annotations.taxon_id')['source_assertion_ids']=[]
            left.source_assertion_store.add(make_source_assertion('annotations.taxon_id',False,'synthetic alternative','record','time',subject_ref='uniprot:LEFT'))
        else:left.quality['conflicts']=[{'field':'annotations.taxon_id','reason':'synthetic literal disagreement','values':[False,0,0.0]}]
        add(defect,left,right,'Synthetic original support binding or alternative remains explicit; no claim authentication.')
    left,right=pair()
    for path,source in (('annotations.a · b','c'),('annotations.a','b · c')):
        record=make_source_assertion(path,'original',source,'synthetic public','time',subject_ref='uniprot:LEFT')
        left.source_assertion_store.add(record);left.set(path,'original',[record['id']])
    add('same-rendered-state-labels',left,right,'Synthetic distinct area/source scopes render equal labels but retain distinct native paths.')
    left,right=pair();record=module.stated(left,'annotations.relationship_context',{'literal':'source statement'})
    for target in ('uniprot:SYNTHETIC_ONE','uniprot:SYNTHETIC_TWO'):
        left.relationship_store.add(make_relationship('uniprot:LEFT','interacts_with',target,
            {'channel':'physical','original':False,'experiments':0},[record['id']]))
    record=module.stated(right,'annotations.relationship_context',{'literal':'other statement'})
    right.relationship_store.add(make_relationship('uniprot:RIGHT','interacts_with','uniprot:SYNTHETIC_ONE',
        {'channel':'functional','original':0,'experiments':False},[record['id']]))
    add('relationship-direction-channels',left,right,'Synthetic full direction, channels, typed qualifiers and exact source records stay literal.')
    left,right=pair();module.stated(left,'annotations.synthetic_record',
        {'path':'values/source-owned.json','sha256':'literal source digest','bytes':0,
         'format':'source-owned@99','adapter':'source-owned@7','rule':'source-owned@5',
         'sabueso_version':'literal-source-label','values':[False,0,0.0,None]})
    add('opaque-source-lookalikes',left,right,'Synthetic source-owned packaging/version lookalikes are ordinary literal values.')
    left,right=pair();module.stated(left,'annotations.'+('synthetic <script>literal</script> '*50),'original')
    add('bounded-escaped-label',left,right,'Synthetic long scope label stays bounded and HTML escaped.')
    left,right=pair();module.stated(left,'annotations.synthetic_record',{'notes':'original synthetic source text '*3000,'values':[False,0,0.0]})
    add('deferred-values',left,right,'Synthetic long original value/support exercises bounded atomic compact deferral.')
    left,right=pair();revision=Card.from_dict(right.to_dict());revision.quality['synthetic_revision']='second'
    add('first-exact-revision',left,right,'Synthetic exact chosen capture, two revisions sharing a source identifier.',extra=[revision])
    add('second-exact-revision',left,right,'Synthetic second exact chosen capture; no implicit identifier matching.',extra=[revision],other_index=2)
    add('repeated-inputs',left,right,'Synthetic repeated exact input occurrence is retained in the original input list.',extra=[right,revision])
    left,right=pair();module.stated(left,'annotations.taxon_id',0);module.stated(right,'annotations.taxon_id',False)
    add('human-only',left,right,'Synthetic human-only observed comparison; no compact requests.',route='human_only')
    add('machine-only',left,right,'Synthetic compact-only observed comparison; no human views.',route='machine_only',order='machine_first')
    return cases
