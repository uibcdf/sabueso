"""Capture genuine clean clinical LIVE observations before an independent reader."""
from contextlib import ExitStack
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import importlib.metadata as metadata
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
from unittest.mock import patch
from urllib.parse import unquote, urlparse

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[2]
EXPECTED = json.loads((BASE/'expected-producer.json').read_text())
HELPER = BASE.parent/'b5-root-exact-live-original-1/legacy_capture_helpers.py'
spec = importlib.util.spec_from_file_location('clinical_observation_helpers', HELPER)
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
Store, view_record, access_record = helper.Store, helper.view_record, helper.access_record

def require(condition, message):
    if not condition:
        raise RuntimeError(message)

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def git(*arguments):
    return subprocess.check_output(['git','-C',str(ROOT),*arguments],text=True).strip()

def source_state():
    import sabueso, sabueso._version
    from sabueso.core.card_clinical_access import descriptor
    require(git('rev-parse','HEAD') == EXPECTED['head'] and not git('status','--porcelain=v1','--untracked-files=all'), 'Producer must be the exact clean committed source')
    require({sabueso.__version__, sabueso._version.__version__, metadata.version('sabueso')} == {EXPECTED['version']}, 'Incoherent producer version metadata')
    direct = json.loads(metadata.distribution('sabueso').read_text('direct_url.json'))
    require(direct['dir_info']['editable'] and Path(unquote(urlparse(direct['url']).path)).resolve() == ROOT, 'Wrong editable installation')
    require(Path(sabueso.__file__).resolve() == ROOT/'sabueso/__init__.py', 'Wrong import path')
    require(descriptor()['save'] is False, 'Capture must precede clinical saved admission')
    for name in ('card_clinical_history_v1.py','card_exploration_clinical.py'):
        require(not (ROOT/'sabueso/core'/name).exists(), 'Independent clinical reader already exists')
    names = set(git('ls-files','--','sabueso','tests','conftest.py','pyproject.toml','.github/workflows').splitlines()) | {'sabueso/_version.py'}
    return {name:sha(ROOT/name) for name in sorted(names)}

class Attempts(dict):
    def __init__(self):
        super().__init__(network=0, source_acquisitions=0)
        self.persist()
    def persist(self):
        (BASE/'attempts.json').write_text(json.dumps(self,indent=2)+'\n')
    def __setitem__(self,key,value):
        super().__setitem__(key,value)
        self.persist()

def main():
    import sabueso
    from sabueso.core.card import Card
    from sabueso.core.card_clinical_access import COLUMNS
    from sabueso.core.card_exploration_storage import _FLAGS
    from sabueso.tools.db.clinicaltrials import FixtureClinicalTrialsClient, OnlineClinicalTrialsClient
    from sabueso.tools.db.unichem import FixtureUniChemClient, OnlineUniChemClient
    before = source_state()
    require(not (BASE/'original1').exists(), 'Never overwrite an original')
    module_path = ROOT/'tests/core/test_card_clinical_exploration_offline.py'
    spec = importlib.util.spec_from_file_location('clinical_public_original_inputs', module_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    # Input preparation uses declared public fixture clients with network forbidden.
    public = module.originals.__wrapped__()
    controls = {name:None for name in public}
    public['unknown-ledger'] = deepcopy(public['bare'])
    public['unknown-ledger']['quality'].pop('enrichments')
    controls['unknown-ledger'] = 'Synthetic missing enrichment ledger; original public source bytes stay fixed.'
    public['misbound-registry'] = deepcopy(public['trials'])
    source = next(row for row in public['misbound-registry']['source_assertion_store'] if row['source']['name']=='ClinicalTrials.gov')
    source['subject_ref'] = 'nct:NCT00000000'
    controls['misbound-registry'] = 'Synthetic registry-subject misbinding; preserve the mismatch rather than treating it as source support.'
    store = Store(BASE/'original1')
    store.copy(Path(__file__),'capture-script.py')
    store.copy(HELPER,'observation-helpers.py')
    store.copy(module_path,'input-test-module.py')
    for name in ('NOTICE.md','chembl/molecules.json','chembl/indications.json','clinicaltrials/studies.json'):
        store.copy(ROOT/'temp_data'/name,'fixtures/'+name)
    store.save('source-before.json',before)
    store.save('inputs.json',public)
    attempts, cases = Attempts(), {}
    def forbidden_science(*a,**k):
        raise RuntimeError('A materialized clinical request must not reread current science')
    def forbidden_acquisition(*a,**k):
        attempts['source_acquisitions'] += 1
        raise RuntimeError('Acquisition forbidden during original observation')
    with ExitStack() as stack:
        helper.guards(stack,attempts,acquisitions=True)
        for client in (FixtureClinicalTrialsClient,OnlineClinicalTrialsClient,FixtureUniChemClient,OnlineUniChemClient):
            stack.enter_context(patch.object(client,'__init__',forbidden_acquisition))
        for name, data in public.items():
            card = Card.from_dict(data)
            original_data = card.to_dict()
            native_oracle = card.clinical()
            explorer = card.explore()
            named, queries = {}, []
            def remember(label,view):
                require(label not in named,'Duplicate observation name')
                named[label]=view
                return view
            root = remember('root',explorer.view('clinical'))
            require(root.native_payload == native_oracle,'Changed native clinical interpretation')
            with patch.object(Card,'clinical',forbidden_science), patch.object(Card,'knowledge_state',forbidden_science):
                question = remember('question',explorer.answer('clinical_context'))
                remember('topics',explorer.topics())
                remember('questions',explorer.questions())
                remember('float-phase',question.filter('chembl_max_phase',equals=4.0))
                remember('integer-phase',question.filter('chembl_max_phase',equals=4))
                remember('empty',question.filter('kind',equals='no_such_clinical_unit'))
                remember('ordered',question.sort('chembl_max_phase',descending=True))
                for kind in ('clinical_molecule_phase','clinical_indication','clinical_trial_citation','clinical_registry_record'):
                    remember(kind,question.filter('kind',equals=kind))
                for index,item in enumerate(question.items()):
                    detail = remember(f'item-{index}:open',item.open())
                    explanation = remember(f'item-{index}:explain',item.explain())
                    links = remember(f'item-{index}:related',item.related())
                    require(detail.back() is question and explanation.back() is question and links.back() is question,'Lost exact initiating view')
                    for position,link in enumerate(links.items()):
                        opened = remember(f'item-{index}:link-{position}',link.open())
                        require(opened.back() is links and opened.request == question.request,'Lost original source/back question')
                specs = [('default',{}),('all-fields',{'fields':list(COLUMNS)}),('no-fields',{'fields':[]}),
                         ('float-phase',{'where':{'chembl_max_phase':4.0}}),('integer-phase',{'where':{'chembl_max_phase':4}}),
                         ('empty-membership',{'item_refs':[]}),('ordered',{'order_by':{'column':'chembl_max_phase','descending':True}})]
                for label,request in specs:
                    selection = explorer.access.select('clinical',**request)
                    pages,cursor,seen = [],None,set()
                    while True:
                        page = selection.page(limit=4,max_bytes=65536,cursor=cursor)
                        require(page['page']['blocked'] is None,'A complete captured page was blocked')
                        pages.append(store.put(page))
                        cursor = page['page']['next_cursor']
                        if cursor is None:
                            break
                        require(cursor not in seen,'Repeated cursor')
                        seen.add(cursor)
                    queries.append({'label':label,'request':request,'selection_ref':selection.selection_ref,'count':selection.count,'pages':pages})
                # Preserve actual object instances, including equal view handles.
                views, identities = [], {}
                def node(view):
                    if view is None:
                        return None
                    if id(view) not in identities:
                        identities[id(view)] = 'V'+str(len(views))
                        views.append(view)
                    return identities[id(view)]
                for observed in [*named.values(),*explorer._session['views'].values()]:
                    node(observed)
                for view in views:
                    node(view._origin)
                    node(view.explorer._origin)
                records=[]
                for view in views:
                    records.append({'node':node(view),'origin_node':node(view._origin),'explorer_origin_node':node(view.explorer._origin),
                                    'observation':view_record(view,store),'flags':{key:getattr(view,key) for key in _FLAGS}})
                access = access_record(explorer.access,store)
                case = {'input':store.put(data),'synthetic_control':controls[name],'native_oracle':store.put(native_oracle),
                        'named_views':{label:node(view) for label,view in named.items()},'views':records,'queries':queries,'access':access,
                        'session_operations':{kind:{key:node(view) for key,view in explorer._session[kind].items()} for kind in ('explanations','links')}}
                cases[name]=store.save('cases/'+name+'.json',case)
            require(card.to_dict()==original_data,'Original Card mutated during capture')
    after = source_state()
    require(before==after and not any(attempts.values()),'Source changed or acquisition attempted')
    store.save('source-after.json',after)
    manifest={'format':'clinical_live_original@1','genuine_live_original':True,'capture_complete':True,'producer_head':EXPECTED['head'],
              'producer_version':EXPECTED['version'],'captured_utc':datetime.now(timezone.utc).isoformat(),'cases':cases,
              'files':dict(store.files),'source_stable':True,'attempts':dict(attempts),
              'scope':'Complete retained LIVE human/machine/source observations before independent clinical saved reading; public fixture cases and explicitly labelled synthetic uncertainty controls. Not an admitted saved file or installed/human acceptance.'}
    store.save('manifest.json',manifest)
    print(json.dumps({'state':'CAPTURE_COMPLETE','cases':len(cases),'files':len(store.files),'producer':EXPECTED,'source_stable':True,'attempts':dict(attempts)},indent=2))

if __name__=='__main__':
    main()
