"""Capture clean SDK202 Bio/literature scalar originals before a new predicate.

This helper requires the coordinator's explicit launch against a clean detached
producer. Synthetic source declarations are controls, not provider claims. No
save/read admission or independent verifier is executed. Existing originals stay
immutable.
"""

import argparse
import hashlib
import importlib.metadata as metadata
import importlib.util
import json
import platform
import shutil
import socket
import subprocess
import sys
from contextlib import ExitStack
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import patch
from urllib.parse import unquote, urlparse

BASE = Path(__file__).resolve().parent
ROOT = None  # Explicit clean source root supplied only by the coordinator.
TOPIC = "literature"
FIXTURES = (
    "NOTICE.md",
    "P52270.json",
    "P60174.json",
    "chembl/CHEMBL5834.json",
    "chembl/molecules.json",
    "europepmc/P60174.json",
    "europepmc/annotations/PMC_PMC12400196.json",
    "europepmc/annotations/MED_18562316.json",
    "mondo/mondo.obo",
)
CASES = {
    "tctim",
    "bare",
    "located",
    "empty",
    "molecule",
    "disease",
    "failed",
    "mixed",
    "search",
}
ENCODER = json.JSONEncoder(
    ensure_ascii=False, allow_nan=False, sort_keys=True, separators=(",", ":")
)


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def git(*args):
    return subprocess.check_output(["git", "-C", str(ROOT), *args], text=True).strip()


def wire(value):
    if value is None or isinstance(value, (str, bool, int, float)):
        return value
    if isinstance(value, dict):
        require(all(isinstance(key, str) for key in value), "Non-JSON object key")
        return {key: wire(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [wire(item) for item in value]
    import pyunitwizard as puw

    require(puw.is_quantity(value), "Undeclared non-JSON capture value")
    unit = puw.convert(str(puw.get_unit(value)), to_form="record", to_type="unit")
    number = puw.get_value(value, to_unit=unit)
    return {
        "value": number.tolist() if hasattr(number, "tolist") else number,
        "unit": unit,
    }


class Store:
    """Keep complete values once; refs are packaging references, not scientific nodes."""

    def __init__(self, output):
        self.output, self.files = output, {}
        output.mkdir(parents=True, exist_ok=False)

    def index(self, path):
        name = path.relative_to(self.output).as_posix()
        self.files[name] = {"bytes": path.stat().st_size, "sha256": sha(path)}
        return {"path": name, **self.files[name]}

    def save(self, name, value):
        path = self.output / name
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("x", encoding="utf-8") as stream:
            for chunk in ENCODER.iterencode(wire(value)):
                stream.write(chunk)
            stream.write("\n")
        return self.index(path)

    def put(self, value):
        value, digest = wire(value), hashlib.sha256()
        for chunk in ENCODER.iterencode(value):
            digest.update(chunk.encode("utf-8"))
        name = "values/" + digest.hexdigest() + ".json"
        return (
            self.files[name] | {"path": name}
            if name in self.files
            else self.save(name, value)
        )

    def copy(self, source, name):
        path = self.output / name
        path.parent.mkdir(parents=True, exist_ok=True)
        require(not path.exists(), "Refusing existing member")
        shutil.copyfile(source, path)
        return self.index(path)


def source_state(head, version):
    import sabueso
    import sabueso._version as generated

    require(
        git("rev-parse", "HEAD") == head, "Capture needs the explicitly authorized HEAD"
    )
    require(
        not git("status", "--porcelain=v1", "--untracked-files=all"),
        "Producer must be clean",
    )
    tag, distance, revision = git("describe", "--tags", "--long", "--abbrev=7").rsplit(
        "-", 2
    )
    expected = tag.removeprefix("v") + "+" + distance + "." + revision
    require(
        distance == "202" and version == expected,
        "Capture requires actual clean SDK202",
    )
    require(
        {sabueso.__version__, generated.__version__, metadata.version("sabueso")}
        == {version},
        "Runtime, installed metadata, generated version and HEAD must agree",
    )
    require(
        Path(sabueso.__file__).resolve() == ROOT / "sabueso/__init__.py",
        "Wrong SDK import",
    )
    direct = json.loads(metadata.distribution("sabueso").read_text("direct_url.json"))
    require(
        direct.get("dir_info", {}).get("editable") is True
        and Path(unquote(urlparse(direct["url"]).path)).resolve() == ROOT,
        "Wrong editable origin",
    )
    names = git(
        "ls-files",
        "--",
        "sabueso",
        "tests",
        "conftest.py",
        "pyproject.toml",
        ".github/workflows",
    ).splitlines()
    return {
        name: sha(ROOT / name) for name in sorted(set(names) | {"sabueso/_version.py"})
    }


def guards(stack, attempts, acquisitions=False):
    def forbidden(kind):
        def reject(*args, **kwargs):
            attempts[kind] += 1
            raise RuntimeError("Acquisition/network forbidden during capture")

        return reject

    for owner, names in (
        (socket, ("create_connection", "getaddrinfo", "gethostbyname")),
        (socket.socket, ("connect", "connect_ex", "sendto", "sendmsg")),
    ):
        for name in names:
            if hasattr(owner, name):
                stack.enter_context(patch.object(owner, name, forbidden("network")))
    if acquisitions:
        import sabueso
        from sabueso.resolver import FixtureRCSBClient, OnlineRCSBClient

        modules = [
            (importlib.import_module("sabueso.tools.db." + name), suffix)
            for name, suffix in (
                ("uniprot", "UniProt"),
                ("chembl", "ChEMBL"),
                ("europepmc", "EuropePMC"),
                ("mondo", "MONDO"),
            )
        ]
        clients = [FixtureRCSBClient, OnlineRCSBClient]
        clients += [
            getattr(module, prefix + suffix + "Client")
            for module, suffix in modules
            for prefix in ("Fixture", "Online")
        ]
        for client in clients:
            stack.enter_context(
                patch.object(client, "__init__", forbidden("source_acquisitions"))
            )
        for name in (
            "resolve",
            "refresh_card",
            "resolve_protein_card",
            "knowledge_packet",
        ):
            stack.enter_context(
                patch.object(sabueso, name, forbidden("source_acquisitions"))
            )


def selection_record(selection, store):
    return {
        "result_ref": selection.result_ref,
        "selection_ref": selection.selection_ref,
        "scientific_result_ref": selection._scientific.result_ref
        if selection._scientific
        else None,
        "context_location": selection._context_location,
        "slice": selection._slice,
        "outcome_override": selection._outcome_override,
        "request": {
            "operation": selection._operation,
            "target": selection._target,
            "fields": list(selection._fields),
        },
        "entries": [
            {
                "key": e.key,
                "location": e.location,
                "ordinal": e.ordinal,
                "value_ref": store.put(e.value),
            }
            for e in selection._entries
        ],
    }


def view_record(view, store):
    from sabueso.core.card_exploration_storage import _cell_record

    rows = []
    for item in view.items():
        cells = {}
        for column, cell in item.cells.items():
            value = cell.value
            if value is None or isinstance(
                value, (str, bool, int, float, dict, list, tuple)
            ):
                record = {
                    "encoding": "json",
                    "value": wire(value),
                    "state": cell.state,
                    "reason": cell.reason,
                }
            else:
                record = _cell_record(item, column, cell)
                require(
                    record["encoding"] == "quantity_record"
                    and isinstance(record.get("field"), str)
                    and bool(record["field"])
                    and isinstance(record.get("unit"), str)
                    and bool(record["unit"]),
                    "Quantity has no declared cell codec",
                )
                record.pop("support", None)
            cells[column] = {**record, "support_ref": store.put(cell.support)}
        rows.append(
            {
                "item_ref": item.item_ref,
                "label": item.label,
                "kind": item.kind,
                "payload_location": item.payload_location,
                "support_ref": store.put(item.support),
                "cells": cells,
            }
        )
    return {
        "view_ref": view.view_ref,
        "result_ref": view.result_ref,
        "title": view.title,
        "presentation": view.presentation,
        "at_root": view.at_root,
        "display_request": view._display_request,
        "selection": selection_record(view._selection, store),
        "request": view.request,
        "context": view.context,
        "outcome": view.outcome,
        "schema": view.schema,
        "back_view_ref": view.back().view_ref if not view.at_root else None,
        "native_payload_ref": store.put(view.native_payload),
        "items": rows,
        "text": str(view),
        "html": view._repr_html_(),
    }


def capture(args):
    from copy import deepcopy

    import sabueso
    import sabueso._version as generated
    from sabueso.core.card import Card
    from sabueso.core.card_literature_access import descriptor
    from sabueso.core.source_assertion_store import make_source_assertion

    helper_hash = sha(Path(__file__))
    before = source_state(args.expected_head, args.expected_version)
    require(
        descriptor()["save"] is False,
        "Use the original pre-literature-reader LIVE producer",
    )
    require(
        not (ROOT / "sabueso/core/card_literature_history_v1.py").exists(),
        "Capture must precede the new independent literature reader",
    )
    original = args.input_original.resolve()
    manifest_path = original / "manifest.json"
    require(
        sha(manifest_path) == args.expected_input_manifest_sha256,
        "The explicitly named original manifest changed",
    )
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    require(
        manifest["capture_complete"]
        and not manifest["admitted_saved_format"]
        and manifest["producer_head"] == args.expected_head
        and manifest["producer_version"] == args.expected_version,
        "The base is not the original clean SDK202 public capture",
    )
    for name, record in manifest["files"].items():
        member = original / name
        require(
            member.resolve().is_relative_to(original)
            and member.stat().st_size == record["bytes"]
            and sha(member) == record["sha256"],
            "Original member changed: " + name,
        )
    case_ref = manifest["cases"]["tctim"]
    original_case = json.loads(
        (original / case_ref["path"]).read_text(encoding="utf-8")
    )
    original_access = original_case["access_state"]
    original_focal = original_access["focal"]
    original_capture = original_access["captures"][original_focal]
    input_ref = original_capture["data_ref"]
    original_data = json.loads(
        (original / input_ref["path"]).read_text(encoding="utf-8")
    )
    activity = next(
        row
        for row in original_data["relationship_store"]
        if row["predicate"] == "has_bioactivity"
        and (row.get("qualifiers", {}).get("document") or {}).get("pubmed")
    )
    publication_ref = "pubmed:" + activity["qualifiers"]["document"]["pubmed"]
    attempts = {"network": 0, "source_acquisitions": 0}
    store = Store(args.output)
    store.copy(__file__, "capture-script.py")
    store.copy(manifest_path, "input-original-manifest.json")
    store.copy(original / input_ref["path"], "inputs/original-tctim-card.json")
    for name in (
        "NOTICE.md",
        "P52270.json",
        "chembl/CHEMBL5834.json",
        "chembl/molecules.json",
    ):
        store.copy(
            original / "inputs/raw_inputs/temp_data" / name,
            "inputs/raw_inputs/temp_data/" + name,
        )
    cases = {}
    scalar_cases = (
        ("false", False),
        ("integer_zero", 0),
        ("float_zero", 0.0),
        ("null", None),
    )
    with ExitStack() as stack:
        guards(stack, attempts, acquisitions=True)
        for name, scalar in scalar_cases:
            card = Card.from_dict(deepcopy(original_data))
            original_activity_count = len(card.relationships("has_bioactivity"))
            card.relationship_store = type(card.relationship_store)(
                [
                    row
                    for row in card.relationships()
                    if row["predicate"] != "has_bioactivity"
                    or row["id"] == activity["id"]
                ]
            )
            asserted_value = {
                "value": scalar,
                "sabueso_version": "opaque source-owned scalar-control label",
                "context": False,
                "native_payload": None,
            }
            assertion = make_source_assertion(
                "annotations.function",
                deepcopy(asserted_value),
                "UniProt",
                "P52270",
                "2026-11-07",
                subject_ref="uniprot:P52270",
            )
            assertion["source_metadata"] = {
                "eco": [
                    {
                        "source": "PubMed",
                        "id": publication_ref.split(":", 1)[1],
                        "code": "ECO:0000269",
                    }
                ],
                "synthetic_control": {
                    "name": name,
                    "owner": "#148/#108",
                    "scope": "Synthetic scalar projection on a public accession; never a provider claim",
                    "preserved_type": type(scalar).__name__,
                },
                "sabueso_version": "source-owned metadata label must remain literal",
            }
            card.source_assertion_store.add(assertion)
            raw = card.to_dict()
            input_pin = card.pinned_ref()
            declaration = {
                "scope": "Explicit synthetic mutation, not an original provider statement",
                "original_input_pin": original_focal,
                "original_input_ref": input_ref,
                "original_activity_count": original_activity_count,
                "retained_activity_relationship_id": activity["id"],
                "removed_activity_count": original_activity_count - 1,
                "all_non_activity_relationships_retained": True,
                "synthetic_assertion": deepcopy(assertion),
                "scalar_type": type(scalar).__name__,
                "scalar": scalar,
                "input_pin": input_pin,
                "publication_ref": publication_ref,
            }
            named = {}
            explorer = card.explore()
            named["bioactivity_question"] = explorer.answer("measured_molecules")
            molecule = next(iter(named["bioactivity_question"].items()))
            named["bioactivity_groups"] = molecule.open()
            group = next(iter(named["bioactivity_groups"].items()))
            named["bioactivity_records"] = group.open()
            record = next(iter(named["bioactivity_records"].items()))
            named["bioactivity_record_detail"] = record.open()
            named["bioactivity_record_explanation"] = record.explain()
            named["bioactivity_molecule_related"] = molecule.related()
            for index, link in enumerate(named["bioactivity_molecule_related"].items()):
                named["bioactivity_context_" + str(index)] = named[
                    "bioactivity_molecule_related"
                ].follow(link.item_ref)
            publication_link = next(
                item
                for item in named["bioactivity_molecule_related"].items()
                if item.cells["role"].value == "publication_context"
            )
            named["bioactivity_publication"] = named[
                "bioactivity_molecule_related"
            ].follow(publication_link.item_ref)
            wrapper = explorer.access._resolve(
                named["bioactivity_publication"]._selection._target["location"]
            )[0]
            summary = next(
                row
                for row in wrapper["original_summary"]["supports"]
                if row["source_assertion_id"] == assertion["id"]
            )
            require(
                type(summary["value"]) is type(scalar) and summary["value"] == scalar,
                "The producer failed to retain the original typed scalar",
            )
            named["literature_question"] = explorer.answer("publications")
            named["literature_focus"] = explorer.view(
                "literature", options={"publication_ref": publication_ref}
            )
            publication = next(iter(named["literature_focus"].items()))
            named["literature_explanation"] = publication.explain()
            named["literature_related"] = publication.related()
            source_link = next(
                item
                for item in named["literature_related"].items()
                if item.cells["role"].value == "source"
                and item.cells["target_ref"].value == assertion["id"]
            )
            named["literature_synthetic_source"] = named["literature_related"].follow(
                source_link.item_ref
            )
            machine = []
            for topic, options in (
                ("bioactivities", None),
                (
                    "bioactivities",
                    {"molecule_ref": molecule.cells["molecule_ref"].value},
                ),
                (
                    "bioactivities",
                    {
                        "molecule_ref": molecule.cells["molecule_ref"].value,
                        "measurement_ref": group.cells["measurement_ref"].value,
                    },
                ),
                ("literature", None),
                ("literature", {"publication_ref": publication_ref}),
            ):
                selection = explorer.access.select(topic, options=options)
                machine.append(
                    {
                        "topic": topic,
                        "options": options,
                        "selection": selection_record(selection, store),
                        "page_ref": store.put(selection.page()),
                    }
                )
            access = explorer.access
            human = {key: view_record(view, store) for key, view in named.items()}
            native_literature = card.literature()
            access_state = {
                "focal": access._focal_key,
                "inputs": access._inputs,
                "captures": {
                    key: {
                        "pin": c.pin,
                        "snapshot": c.snapshot,
                        "data_ref": store.put(c.data),
                    }
                    for key, c in access._captures.items()
                },
                "objects": {
                    key: store.put(value) for key, value in access._objects.items()
                },
                "locations": access._locations,
                "metadata_refs": sorted(access._metadata_refs),
                "scientific_items": {
                    key: {"result_ref": value[0].result_ref, "entry_key": value[1]}
                    for key, value in access._scientific_items.items()
                },
                "selections": {
                    key: selection_record(value, store)
                    for key, value in access._selections.items()
                },
            }
            cases[name] = store.save(
                "cases/" + name + ".json",
                {
                    "declaration": declaration,
                    "input_card_ref": store.put(raw),
                    "human": human,
                    "machine": machine,
                    "access_state": access_state,
                    "native": {
                        "literature_ref": store.put(native_literature),
                        "publication_explanations": {
                            pub["publication_ref"]: store.put(
                                card.explain_literature(pub["publication_ref"])
                            )
                            for pub in native_literature["publications"]
                        },
                        "bioactivities_ref": store.put(card.bioactivities()),
                        "molecule_explanation_ref": store.put(
                            card.explain_bioactivity(
                                molecule.cells["molecule_ref"].value
                            )
                        ),
                        "measurement_explanation_ref": store.put(
                            card.explain_measurement(
                                group.cells["measurement_ref"].value
                            )
                        ),
                        "bioactivity_publication_wrapper_ref": store.put(wrapper),
                    },
                },
            )
            require(
                card.to_dict() == raw and card.pinned_ref() == input_pin,
                "Exploration mutated synthetic input knowledge",
            )
    require(
        not any(attempts.values())
        and sha(Path(__file__)) == helper_hash
        and source_state(args.expected_head, args.expected_version) == before,
        "Acquisition, helper or producer drift during capture",
    )
    store.save("source-files.json", before)
    store.save(
        "manifest.json",
        {
            "capture_complete": True,
            "admitted_saved_format": False,
            "kind": "Genuine clean SDK202 LIVE Bio/literature scalar originals; no saving or independent verifier",
            "owner": "#148/#108",
            "review_trigger": "Versioned Bio202 predicate review and independent original receiving",
            "producer_head": args.expected_head,
            "producer_version": args.expected_version,
            "source_root": str(ROOT),
            "created_utc": datetime.now(timezone.utc).isoformat(),
            "environment": {
                "python": sys.version,
                "executable": sys.executable,
                "platform": platform.platform(),
                "sabueso_import": str(Path(sabueso.__file__).resolve()),
                "runtime_version": sabueso.__version__,
                "generated_version": generated.__version__,
                "distribution_version": metadata.version("sabueso"),
                "distribution_metadata_path": str(
                    metadata.distribution("sabueso")._path
                ),
                "editable_direct_url": json.loads(
                    metadata.distribution("sabueso").read_text("direct_url.json")
                ),
                "packages": {
                    name: metadata.version(name)
                    for name in (
                        "sabueso",
                        "pyunitwizard",
                        "argdigest",
                        "smonitor",
                        "depdigest",
                        "ackredit",
                        "pytest",
                        "pytest-receptor",
                    )
                },
            },
            "input_original_manifest_sha256": args.expected_input_manifest_sha256,
            "source_producer": {
                "head": git("rev-parse", "HEAD"),
                "describe": git("describe", "--tags", "--long", "--abbrev=7"),
                "status": git("status", "--porcelain=v1", "--untracked-files=all"),
                "capture_script_sha256": helper_hash,
            },
            "attempts": attempts,
            "cases": cases,
            "files": dict(store.files),
            "synthetic_scope": "Only the four explicitly declared source assertions and reduction to one original source activity are synthetic; they establish no provider or biological claim",
            "packaging": "Lossless capture-envelope JSON references only; full native and wire values retained unchanged",
        },
    )
    print(
        json.dumps(
            {
                "capture_complete": True,
                "output": str(args.output),
                "members": len(store.files),
            }
        )
    )


def main():
    global ROOT
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--capture", action="store_true", required=True)
    parser.add_argument("--source-root", required=True, type=Path)
    parser.add_argument("--input-original", required=True, type=Path)
    parser.add_argument("--expected-input-manifest-sha256", required=True)
    parser.add_argument("--expected-head", required=True)
    parser.add_argument("--expected-version", required=True)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    ROOT = args.source_root.resolve()
    args.output = args.output.resolve()
    require(
        args.capture and ROOT.is_dir() and (ROOT / "pyproject.toml").is_file(),
        "Explicit capture launch requires the clean source checkout",
    )
    require(
        args.output.is_relative_to(BASE)
        and args.output != BASE
        and not args.output.exists(),
        "Output must be a new owned evidence subdirectory",
    )
    require(
        not args.output.is_relative_to(args.input_original.resolve())
        and not args.input_original.resolve().is_relative_to(args.output),
        "Original input and new output cannot overlap",
    )
    capture(args)


if __name__ == "__main__":
    main()
