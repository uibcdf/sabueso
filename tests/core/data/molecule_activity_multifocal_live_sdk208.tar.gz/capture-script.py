"""Capture genuine corrected SDK208 multi-focal routes before full saved admission.

This supplement follows the private predicate kernel. It neither replaces nor
regenerates the SDK205 original and is not an admitted saved format.
"""
import argparse
from contextlib import ExitStack
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import importlib.metadata as metadata
import json
from pathlib import Path
import platform
import subprocess
import sys
from unittest.mock import patch
from urllib.parse import unquote, urlparse

from legacy_capture_helpers import Store, access_record, guards, selection_record, view_record, wire

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[2]
HEAD = "142618d305d7d0c732f3ebdbf2d49ee6a9bbb65c"
VERSION = "0.14.0+208.g142618d"
PARENT = ROOT / "tests/core/data/molecule_activity_live_sdk205.tar.gz"
PARENT_SHA = "61a5556a3d9cc75485a321c707341f2233954606b14c2e917bd5cd627b3d123f"
OLD = BASE.parent / "b5-molecule-original-preparation-1/original2"
INPUT = "inputs/base-public-inputs.json"
TOPIC = "activity_context"
ENCODER = json.JSONEncoder(ensure_ascii=False, allow_nan=False, sort_keys=True, separators=(",", ":"))

def require(condition, message):
    if not condition:
        raise RuntimeError(message)

def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()

def git(*args):
    return subprocess.check_output(["git", "-C", str(ROOT), *args], text=True).strip()

def source_state():
    import sabueso
    import sabueso._version as generated
    from sabueso.core.card_molecule_activity_access import descriptor
    require(git("rev-parse", "HEAD") == HEAD and not git("status", "--porcelain=v1", "--untracked-files=all"), "Wrong or dirty producer")
    require({sabueso.__version__, generated.__version__, metadata.version("sabueso")} == {VERSION}, "Runtime/distribution/generated mismatch")
    require(Path(sabueso.__file__).resolve() == ROOT / "sabueso/__init__.py", "Wrong import")
    direct = json.loads(metadata.distribution("sabueso").read_text("direct_url.json"))
    require(direct.get("dir_info", {}).get("editable") is True and Path(unquote(urlparse(direct["url"]).path)).resolve() == ROOT, "Wrong editable checkout")
    require(descriptor()["save"] is False and not (ROOT / "sabueso/core/card_exploration_molecule_activity.py").exists(), "Capture must precede full new saved admission")
    paths = set(git("ls-files", "--", "sabueso", "tests", "conftest.py", "pyproject.toml", ".github/workflows").splitlines()) | {"sabueso/_version.py"}
    return {name: sha(ROOT / name) for name in sorted(paths)}

class Attempts(dict):
    """Persist telemetry even if a forbidden call aborts the original."""
    def __init__(self):
        super().__init__(network=0, source_acquisitions=0)
        self.persist()

    def persist(self):
        (BASE / "attempts.json").write_text(json.dumps(self, indent=2) + "\n")

    def __setitem__(self, key, value):
        super().__setitem__(key, value)
        self.persist()

def role(view, name):
    return next(item for item in view.items() if item._entry.value.get("role") == name)

def main():
    from sabueso.core.card import Card
    from sabueso.core.deck import Deck
    from sabueso.core.errors import StorageError
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--capture", action="store_true", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    output = args.output.resolve()
    require(output == BASE / "original1" and not output.exists(), "Require fresh owned original1")
    before, helper_hash = source_state(), sha(Path(__file__))
    require(sha(PARENT) == PARENT_SHA, "Existing SDK205 capsule changed")
    old_manifest = json.loads((OLD / "manifest.json").read_text())
    original_input = old_manifest["files"][INPUT]
    require(sha(OLD / INPUT) == original_input["sha256"] and (OLD / INPUT).stat().st_size == original_input["bytes"], "Original public input differs")
    helpers = BASE / "legacy_capture_helpers.py"
    require(sha(helpers) == old_manifest["files"]["capture-resume-script.py"]["sha256"], "Original observation helper differs")
    store = Store(output)
    store.copy(Path(__file__), "capture-script.py")
    store.copy(helpers, "observation-helpers.py")
    store.copy(OLD / "manifest.json", "parent-original-manifest.json")
    store.copy(OLD / INPUT, INPUT)
    store.save("source-before.json", before)
    public = json.loads((OLD / INPUT).read_text())
    require(sum(row["predicate"] == "has_bioactivity" for row in public["cards"]["target"]["relationship_store"]) == 493, "Reduced target input")
    cases, attempts = {}, Attempts()
    with ExitStack() as stack:
        guards(stack, attempts, acquisitions=True)
        for name, first_name, second_name in (
            ("bts-to-benz", "bts", "benz"),
            ("benz-to-bts", "benz", "bts"),
            ("bts-to-same-id-snapshot", "bts", "bts-snapshot"),
        ):
            first, target = (Card.from_dict(deepcopy(public["cards"][n])) for n in (first_name, "target"))
            synthetic = None
            if second_name == "bts-snapshot":
                raw = first.to_dict()
                raw["meta"]["synthetic_snapshot_control"] = "Distinct molecule snapshot; unchanged source relationships."
                second = Card.from_dict(raw)
                require(second.id == first.id and second.pinned_ref() != first.pinned_ref(), "Snapshot control lost exact distinction")
                synthetic = "Only meta.synthetic_snapshot_control differs; no source assertion or chemical-equivalence claim is added."
            else:
                second = Card.from_dict(deepcopy(public["cards"][second_name]))
            inputs = [c.to_dict() for c in (first, target, second)]
            oracles = {c.pinned_ref(): wire(target.explain_ligand(c.id, Deck([first, second]))) for c in (first, second)}
            publication_oracles = {ref: wire(target.explain_literature(ref)) for ref in ("pubmed:35189560", "pubmed:20889239")}
            named, operations, queries, calls = {}, [], [], []
            def remember(label, view):
                require(label not in named, "Repeated original view name")
                named[label] = view
                return view
            def query(label, explorer, **kwargs):
                selection = explorer.access.select(TOPIC, **kwargs)
                pages, cursor, seen = [], None, set()
                while True:
                    page = selection.page(limit=1, max_bytes=65536, cursor=cursor)
                    require(page["page"]["blocked"] is None and len(ENCODER.encode(wire(page)).encode()) <= 65536, "Incomplete bounded page")
                    pages.append(page)
                    cursor = page["page"]["next_cursor"]
                    if cursor is None:
                        break
                    require(cursor not in seen, "Repeated page cursor")
                    seen.add(cursor)
                require(sum(len(page["items"]) for page in pages) == selection.count, "Incomplete machine request")
                queries.append({"name": label, "focal": explorer.access._focal_key, "query": kwargs,
                                "selection": selection_record(selection, store), "pages_ref": store.put(pages)})
            original_bioactivities = Card.bioactivities
            def counted(card, *args, **kwargs):
                calls.append(card.id)
                return original_bioactivities(card, *args, **kwargs)
            with patch.object(Card, "bioactivities", counted):
                explorer = first.explore(related_cards=[target, second])
                first_root = remember("first/root", explorer.answer("measured_targets"))
                first_links = remember("first/links", first_root.items()[0].related())
                first_native = remember("first/native", role(first_links, "native_ligand_crossing").open())
                protein = remember("target/destination", role(first_links, "target_card").open())
                activity = remember("target/measured-molecules", protein.explorer.answer("measured_molecules"))
                alias = "chembl:CHEMBL110" if second_name == "benz" else "chembl:CHEMBL1161789"
                molecule = next(i for i in activity.items() if i.cells["molecule_ref"].value == alias)
                molecule_links = remember("target/second-molecule-links", molecule.related())
                relationship = remember("target/original-relationship", role(molecule_links, "original_relationship").open())
                reference = next(i for i in relationship.items() if i._entry.key == "object_ref")
                destinations = remember("target/declared-object-destinations", reference.related())
                candidate = next(i for i in destinations.items() if any(c["capture"] == second.pinned_ref() for c in i._entry.value.get("candidates", [])))
                destination = candidate.open()
                if destination.explorer.context["card_ref"] != second.pinned_ref():
                    remember("second/ambiguous-candidates", destination)
                    require(destination.outcome["status"] == "ambiguous", "Wrong explicit-candidate state")
                    destination = next(i for i in destination.items() if any(c["capture"] == second.pinned_ref() for c in i._entry.value.get("candidates", []))).open()
                remember("second/destination", destination)
                require(destination.explorer.context["card_ref"] == second.pinned_ref(), "Wrong selected focal capture")
                second_root = remember("second/root", destination.explorer.answer("measured_targets"))
                second_links = remember("second/links", second_root.items()[0].related())
                second_native = remember("second/native", role(second_links, "native_ligand_crossing").open())
                crossings = {}
                for prefix, card, root, links, native in (
                    ("first", first, first_root, first_links, first_native),
                    ("second", second, second_root, second_links, second_native),
                ):
                    require(wire(native.native_payload) == oracles[card.pinned_ref()], "Crossing differs from complete standalone native oracle")
                    access = native.explorer.access
                    _, location = access._resolve(native._selection._target["location"])
                    wrapper = access._objects[location["result_ref"]]
                    require(wrapper["molecule_card_ref"] == card.pinned_ref() and wrapper["target_card_ref"] == target.pinned_ref(), "Wrong wrapper owner capture")
                    require(native.explorer.context["card_ref"] == card.pinned_ref(), "Crossing lost focal context")
                    crossings[prefix] = {"focal": access._focal_key, "molecule_pin": card.pinned_ref(),
                                         "target_pin": target.pinned_ref(), "wrapper_ref": store.put(wrapper),
                                         "oracle_ref": store.put(oracles[card.pinned_ref()]), "payload_location": location}
                    repeated = remember(prefix + "/native-repeat", role(links, "native_ligand_crossing").open())
                    returned = remember(prefix + "/native-back", native.back())
                    require(repeated.native_payload == native.native_payload and returned.view_ref == links.view_ref, "Repeat/back changed crossing")
                    query(prefix + "/default", root.explorer)
                    query(prefix + "/projection", root.explorer, fields=["target_card_ref", "measurement", "class"])
                    query(prefix + "/exact-membership", root.explorer, item_refs=[root.items()[0].item_ref])
                    query(prefix + "/empty-membership", root.explorer, item_refs=[])
                    groups = remember(prefix + "/groups", root.items()[0].open())
                    for gi, group in enumerate(groups.items()):
                        records = remember(prefix + f"/group/{gi}/records", group.open())
                        for ri, item in enumerate(records.items()):
                            rprefix = prefix + f"/group/{gi}/record/{ri}"
                            remember(rprefix + "/open", item.open())
                            remember(rprefix + "/explain", item.explain())
                            record_links = remember(rprefix + "/links", item.related())
                            for li, link in enumerate(record_links.items()):
                                if link._entry.value.get("role") in {"source", "original_relationship", "identity_context", "assay_context", "citation_context", "publication_context", "molecule_root"}:
                                    opened = remember(rprefix + f"/link/{li}/" + link._entry.value["role"], link.open())
                                    if link._entry.value["role"] == "molecule_root":
                                        require(opened.view_ref == root.view_ref, "Exact molecule root return changed")
                publications = remember("target/publications", protein.explorer.answer("publications"))
                for ref, size in (("pubmed:35189560", 9), ("pubmed:20889239", 459)):
                    item = next(i for i in publications.items() if i.cells["publication_ref"].value == ref)
                    opened = remember("target/publication/" + ref, item.open())
                    require(wire(opened.native_payload) == publication_oracles[ref] and len(opened.native_payload["links"]) == size, "Full original publication context differs")
                require(calls == [target.id], "Crossing repeated target activity evaluation")
            refusals = []
            try:
                first_root.save(output / ("refused-" + name + ".json"))
            except StorageError as error:
                refusals.append({"operation": "save", "exception": type(error).__name__, "message": str(error)})
            else:
                raise RuntimeError("New saved profile admitted before original capture")
            require(not (output / ("refused-" + name + ".json")).exists(), "Refused save wrote a file")
            human = {label: view_record(view, store) for label, view in named.items()}
            foci = {view.explorer.access._focal_key: view.explorer.access for view in named.values()}
            cache = [{"key": wire(k), "payload_ref": store.put(v[0]), "location": v[1]}
                     for k, v in explorer.access._scientific_cache.items()
                     if isinstance(k, tuple) and len(k) > 1 and k[1] == "native_crossing"]
            require(len(cache) == 2 and {row["key"][2] for row in cache} == {crossings[n]["focal"] for n in crossings}, "Cache entries do not bind both exact focal captures")
            require(inputs == [c.to_dict() for c in (first, target, second)], "Exploration mutated supplied knowledge")
            cases[name] = store.save("cases/" + name + ".json", {
                "inputs": {"first": store.put(inputs[0]), "target": store.put(inputs[1]), "second": store.put(inputs[2]),
                           "ordered_pins": [c.pinned_ref() for c in (first, target, second)], "synthetic_control": synthetic},
                "human": human, "machine": queries, "operations": operations, "refusals": refusals,
                "crossings": crossings, "native_crossing_cache": cache,
                "publication_oracles": {ref: store.put(value) for ref, value in publication_oracles.items()},
                "access_states": {focal: access_record(access, store) for focal, access in foci.items()},
                "target_bioactivity_calls": calls,
            })
            print(json.dumps({"case_complete": name, "human_views": len(human), "machine_requests": len(queries), "members": len(store.files)}), flush=True)
    require(not any(attempts.values()) and sha(Path(__file__)) == helper_hash and source_state() == before and sha(PARENT) == PARENT_SHA, "Capture drift or forbidden attempt")
    store.save("source-after.json", before)
    store.save("attempts.json", dict(attempts))
    store.save("manifest.json", {
        "kind": "Genuine clean corrected SDK208 multi-focal supplemental LIVE observations",
        "capture_complete": True, "admitted_saved_format": False,
        "sequencing": "After independent private predicate kernel; before full new saved admission/restoration. Original SDK205 capture is unchanged.",
        "producer_head": HEAD, "producer_version": VERSION, "created_utc": datetime.now(timezone.utc).isoformat(),
        "environment": {"python": sys.version, "executable": sys.executable, "platform": platform.platform(),
                        "packages": {n: metadata.version(n) for n in ("sabueso", "pyunitwizard", "argdigest", "smonitor", "depdigest", "ackredit")}},
        "parent_original": {"path": str(PARENT.relative_to(ROOT)), "sha256": PARENT_SHA,
                            "input_member": INPUT, "input_member_sha256": original_input["sha256"]},
        "attempts": dict(attempts), "cases": cases, "files": dict(store.files),
        "owner": "uibcdf/sabueso#148/#112", "review_trigger": "Independent saved-format admission and full original/supplement transport/copied receiving",
        "scope": "Three complete named public cross-focal journeys, original source/support/back routes, full 493-record inputs and 9/459-link publication contexts, exact supplied pins and all native crossing wrappers/oracles. No private inputs or source acquisition.",
        "packaging": "Envelope refs {path,bytes,sha256} bind complete canonical JSON members; sharing never shortens retained values or merges scientific identity.",
    })
    print(json.dumps({"capture_complete": True, "cases": len(cases), "members": len(store.files)}), flush=True)

if __name__ == "__main__":
    main()
