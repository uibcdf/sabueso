"""Capture actual clean SDK230 LIVE observations before independent saved reading."""
from contextlib import ExitStack
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import importlib.metadata as metadata
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
from unittest.mock import patch
from urllib.parse import unquote, urlparse

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[2]
EXPECTED = json.loads((BASE/'expected-producer.json').read_text())
HELPER = BASE/'observation_helpers.py'
spec = importlib.util.spec_from_file_location('variant_original_observation_helpers', HELPER)
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
Store, require, sha = helper.Store, helper.require, helper.sha


def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args], text=True).strip()


def source_state():
    import sabueso, sabueso._version
    from sabueso.core.card_variant_access import descriptor
    require(git('rev-parse', 'HEAD') == EXPECTED['head'] and not git('status', '--porcelain=v1', '--untracked-files=all'), 'Exact clean committed producer required')
    require({sabueso.__version__, sabueso._version.__version__, metadata.version('sabueso')} == {EXPECTED['version']}, 'Producer labels disagree')
    direct = json.loads(metadata.distribution('sabueso').read_text('direct_url.json'))
    require(direct['dir_info']['editable'] and Path(unquote(urlparse(direct['url']).path)).resolve() == ROOT, 'Wrong editable origin')
    require(Path(sabueso.__file__).resolve() == ROOT/'sabueso/__init__.py', 'Wrong import')
    require(descriptor()['save'] is False, 'Capture must precede independent save admission')
    for name in ('card_variant_history_v1.py', 'card_exploration_variant.py', '_variant_history_v1'):
        require(not (ROOT/'sabueso/core'/name).exists(), 'Independent variant reader already exists')
    names = set(git('ls-files', '--', 'sabueso', 'tests', 'conftest.py', 'pyproject.toml', '.github/workflows').splitlines()) | {'sabueso/_version.py'}
    return {name:sha(ROOT/name) for name in sorted(names)}


class Attempts(dict):
    def __init__(self, name):
        self.path = BASE/(name+'-attempts.json')
        super().__init__(network=0, source_acquisitions=0)
        self.persist()

    def persist(self):
        self.path.write_text(json.dumps(self,indent=2)+'\n')

    def __setitem__(self, key, value):
        super().__setitem__(key, value)
        self.persist()


def prepare(module):
    from sabueso.core.card import Card
    from sabueso.core.tissue_usage import EXONS, ISOFORMS, REGIONS, VARIANTS

    public = module.originals.__wrapped__()
    cases = {}
    def add(name, card, mode, description=None, *, threshold=0.1, related=(), route_order='human_first'):
        cases[name] = {'focal':card.to_dict(), 'related':[c.to_dict() for c in related], 'options':{'mode':mode,'threshold':threshold}, 'synthetic_control':description, 'route_order':route_order}
    for mode in ('variants','isoforms'):
        add('public-'+mode, Card.from_dict(deepcopy(public)), mode)
        add('synthetic-'+mode, module.synthetic(), mode, 'Labelled synthetic exact input scope with zero liver and unknown brain pext, independent protein position and explicit CDS/transcripts.')
        empty = Card(meta={'card_id':'sabueso:protein:uniprot:P60174','entity_type':'protein'})
        add('bare-'+mode, empty, mode, 'Synthetic minimal protein without requested native input fields; no external absence inference.')
        for defect in ('foreign_assembly','foreign_chromosome','missing_assembly','conflicting_tissue'):
            card = module.synthetic()
            rows = deepcopy(card.get(REGIONS)['value'])
            if defect == 'foreign_assembly': rows[0]['assembly']='GRCh37'
            elif defect == 'foreign_chromosome': rows[0]['chromosome']='1'
            elif defect == 'missing_assembly': rows[0].pop('assembly')
            else: rows.append({**deepcopy(rows[0]),'tissues':[{'tissue':'liver','value':0.8}]})
            module.put(card,REGIONS,rows)
            add(mode+'-'+defect,card,mode,'Synthetic '+defect+' pext scope control; source values and unknown/conflicting denominators remain literal.')
        for defect in ('subject','field','missing'):
            card = module.synthetic()
            ref=card.get(VARIANTS if mode=='variants' else ISOFORMS)['source_assertion_ids'][0]
            if defect=='missing': card.source_assertion_store.store.pop(ref)
            else: card.source_assertion_store.get(ref)['subject_ref' if defect=='subject' else 'field_path']='foreign'
            add(mode+'-support-'+defect,card,mode,'Synthetic native input assertion '+defect+'; preserve partial support and unavailable source destinations.')
    for defect in ('missing_cds','foreign_transcript','foreign_version'):
        card=module.synthetic();exons=deepcopy(card.get(EXONS)['value'])
        if defect=='missing_cds':exons=exons[:1]
        elif defect=='foreign_transcript':exons[1]['transcript']='FOREIGN'
        else:exons[1]['transcript_version']='999'
        module.put(card,EXONS,exons)
        add('isoforms-'+defect,card,'isoforms','Synthetic rejected/missing CDS or transcript-version input; own/variable base completeness stays explicit.')
    for mode,path in [('variants',VARIANTS),('isoforms',ISOFORMS)]:
        card=module.synthetic();values=deepcopy(card.get(path)['value']);module.put(card,path,[*values,deepcopy(values[0])])
        add(mode+'-equal-occurrences',card,mode,'Synthetic identical native source occurrences at different original list positions; never merge actual rows.')
    card=module.synthetic()
    card.quality['conflicts']=[{'field':VARIANTS,'values':['selected','alternative'],'source_assertion_ids':card.get(VARIANTS)['source_assertion_ids']}]
    card.quality['alternatives']=[{'field':VARIANTS,'value':'retained alternative','source_assertion_ids':[]}]
    add('source-conflict',card,'variants','Synthetic field conflict and unselected alternative; selected native science remains unchanged.')
    for label,value in [('opaque-source',{'format':'source-owned@999','rule':'source-owned@7','adapter':'source-owned@9','version':0,'context':False,'values':[False,0,0.0,None]}),('escaped-source','<script>alert(1)</script>')]:
        card=module.synthetic();rows=deepcopy(card.get(VARIANTS)['value'])
        if label=='opaque-source':rows[0]['source_payload']=value
        else:rows[0]['variant_id']='12-15-A-'+value
        module.put(card,VARIANTS,rows);add(label,card,'variants','Synthetic opaque/source text; keep source-owned fields unchanged and escaped rendering separate.')
    card=module.synthetic();rows=deepcopy(card.get(VARIANTS)['value']);rows[0]['variant_id']='12-15-A-'+'G'*20000;module.put(card,VARIANTS,rows)
    add('deferred-values',card,'variants','Synthetic long identifier exercises atomic machine value/interpretation deferral; no biological assertion.')
    for label,threshold in [('integer-first',1),('float-first',1.0)]:
        add('threshold-'+label,module.synthetic(),'variants','Synthetic alternate creation order of integer and float cutoff operands; retain typed effective requests.',threshold=threshold)
    card=module.synthetic();revision=Card.from_dict(card.to_dict());revision.quality['synthetic_revision']='second explicit input revision'
    add('input-revisions',card,'variants','Synthetic repeated explicit input occurrence and separately supplied revision; focal result uses the actual focal capture.',related=[card,card,revision])
    add('machine-first',module.synthetic(),'variants','Synthetic machine-first actual API execution followed by human/source observation; ordering is recorded without inventing a human-only or machine-only history.',route_order='machine_first')
    return public,cases


def main():
    import sabueso
    from sabueso.core.card import Card
    from sabueso.core import comparative_explanation,scoped_tissue_usage
    from sabueso.core.card_variant_selection_v1 import COLUMNS
    from sabueso.core.card_exploration_storage import _FLAGS
    from sabueso.tools.db.gnomad import FixtureGnomADClient,OnlineGnomADClient
    from sabueso.tools.db.gtex import FixtureGTExClient,OnlineGTExClient

    before=source_state();output=BASE/sys.argv[1];require(not output.exists(),'Never overwrite an original')
    module_path=ROOT/'tests/core/test_card_variant_exploration_offline.py'
    spec=importlib.util.spec_from_file_location('variant_original_public_inputs',module_path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    preparation_attempts=Attempts(output.name+'-preparation')
    with ExitStack() as stack:
        helper.guards(stack,preparation_attempts)
        public,inputs=prepare(module)
    require(not any(preparation_attempts.values()),'Input preparation attempted networking')
    if sys.argv[2:]:inputs={k:inputs[k] for k in sys.argv[2:]}
    store=Store(output)
    for source,target in [(Path(__file__),'capture-script.py'),(HELPER,'observation-helpers.py'),(module_path,'input-test-module.py'),(BASE/'expected-producer.json','producer.json'),(ROOT/'LICENSE','LICENSE')]:store.copy(source,target)
    fixtures=['NOTICE.md','P60174.json',*[str(p.relative_to(ROOT/'temp_data')) for p in sorted((ROOT/'temp_data/gnomad').glob('*.json'))],*[str(p.relative_to(ROOT/'temp_data')) for p in sorted((ROOT/'temp_data/gtex').glob('*.json'))]]
    for name in fixtures:store.copy(ROOT/'temp_data'/name,'fixtures/'+name)
    (output/'NOTICE.md').write_text('# Variant/isoform tissue-context original — source and rights\n\nPublic HsTIM inputs retain the source/date/licence declarations in fixtures/NOTICE.md. UniProt data retains its CC BY 4.0 attribution. gnomAD core and pext fixtures retain their recorded CC0 1.0 scope; pext is gnomAD computation from GTEx v10. The Genotype-Tissue Expression (GTEx) Project, GTEx Portal (https://gtexportal.org/), is acknowledged for original tissue metadata. Observations do not relicense source annotations. Authored code and explicitly labelled synthetic controls follow the repository MIT LICENSE. No private or pilot material is included.\n\nThis finite genuine LIVE original comes from clean SDK230 before independent variant saved reading. It is not an admitted saved exploration file, scientific validation, source authentication or human acceptance. Input preparation uses existing public fixture clients with networking forbidden; observation forbids network/source acquisition. Native public oracle calls are distinct from captured adapter materialization. After all declared results are materialized, current science rereads are forbidden. Every original value and actual observed parent/access/navigation instance remains retained. Content references share bytes, never scientific identity. Owner: Sabueso #148/#102/#138/#112; review at independent receiving and block closeout.\n',encoding='utf-8');store.index(output/'NOTICE.md')
    store.save('source-before.json',before);store.save('public-inputs.json',public);store.save('inputs.json',inputs)
    attempts,cases=Attempts(output.name),{}
    def forbidden_science(*args,**kwargs):raise RuntimeError('Cached observation must not reread current science')
    def forbidden_acquisition(*args,**kwargs):
        attempts['source_acquisitions']+=1
        raise RuntimeError('Source acquisition forbidden during observation')
    with ExitStack() as stack:
        helper.guards(stack,attempts,acquisitions=True)
        for client in (FixtureGnomADClient,OnlineGnomADClient,FixtureGTExClient,OnlineGTExClient):stack.enter_context(patch.object(client,'__init__',forbidden_acquisition))
        for name,data in inputs.items():
            print('Capturing '+name,flush=True)
            focal=Card.from_dict(deepcopy(data['focal']));related=[Card.from_dict(deepcopy(v)) for v in data['related']];cards=[focal,*related];original_cards=[c.to_dict() for c in cards]
            explorer=focal.explore(related_cards=related);named,queries,oracles,warm_order,api_order={ },[],[],[],[]
            def remember(label,view):
                require(label not in named,'Duplicate named observation');named[label]=view;api_order.append({'operation':'human','label':label,'view':view});return view
            def machine(label,request,*,max_bytes=65536):
                selection=explorer.access.select('variants',**request);api_order.append({'operation':'select','label':label,'selection_ref':selection.selection_ref,'request':deepcopy(request)});pages,cursor,seen=[],None,set()
                while True:
                    page=selection.page(limit=4,max_bytes=max_bytes,cursor=cursor);require(page['page']['blocked'] is None,'Incomplete observed machine page');pages.append(store.put(page));cursor=page['page']['next_cursor']
                    if cursor is None:break
                    require(cursor not in seen,'Repeated cursor');seen.add(cursor)
                queries.append({'label':label,'request':deepcopy(request),'page_options':{'limit':4,'max_bytes':max_bytes},'selection_ref':selection.selection_ref,'count':selection.count,'pages':pages})
                return selection
            options=deepcopy(data['options']);warm=[options]
            if name.startswith('threshold-'):warm.append({**options,'threshold':1.0 if type(options['threshold']) is int else 1})
            for other in [{**options,'threshold':0.2},{'mode':'isoforms' if options['mode']=='variants' else 'variants','threshold':0.1}]:
                if not any(helper.wire(other)==helper.wire(x) and type(other['threshold']) is type(x['threshold']) for x in warm):warm.append(other)
            for index,opts in enumerate(warm):
                native=getattr(focal,'variant_tissue_usage' if opts['mode']=='variants' else 'isoform_tissue_usage')(threshold=opts['threshold'])
                oracles.append({'options':deepcopy(opts),'native_payload':native});api_order.append({'operation':'native_oracle','options':deepcopy(opts)})
                if index==0 and data['route_order']=='machine_first':machine('first-executed-machine',{'options':opts})
                view=remember('root' if index==0 else 'warm-'+str(index),explorer.view('variants',options=opts));warm_order.append(deepcopy(opts));require(helper.ENCODER.encode(view.native_payload)==helper.ENCODER.encode(native),'Native oracle differs from actual profile result')
            with ExitStack() as cached:
                for owner,names in [(Card,('variant_tissue_usage','isoform_tissue_usage','explain_variant_tissue_usage','explain_isoform_tissue_usage','knowledge_state')),(comparative_explanation,('explain_variant_tissue_usage','explain_isoform_tissue_usage')),(scoped_tissue_usage,('variant_view','isoform_view'))]:
                    for method in names:cached.enter_context(patch.object(owner,method,forbidden_science))
                question_key='variant_tissue_context' if options['mode']=='variants' else 'isoform_tissue_context'
                question=remember('question',explorer.answer(question_key,options=options));remember('topics',explorer.topics());remember('questions',explorer.questions());remember('overview',explorer.overview())
                remember('ordered',question.sort('label',descending=True));remember('empty',question.filter('kind',equals='no_such_native_occurrence'));remember('null-axis',question.filter('assembly',equals=None));remember('partial-support',question.filter('support_state',equals='partial'));remember('zero-tissues',question.filter('tissue_count',equals=0));remember('complete-bases',question.filter('own_bases_complete',equals=True))
                for index,opts in enumerate(warm[1:],1):remember('question-warm-'+str(index),explorer.answer('variant_tissue_context' if opts['mode']=='variants' else 'isoform_tissue_context',options=opts))
                for origin_name in ['question','ordered',*['question-warm-'+str(i) for i in range(1,len(warm))]]:
                    parent=named[origin_name]
                    for index,item in enumerate(parent.items()):
                        prefix=f'{origin_name}:item-{index}'
                        for operation in ('open','explain','related'):
                            observed=remember(prefix+':'+operation,getattr(item,operation)());require(observed.back() is parent and observed.request==parent.request,'Actual initiating source/question origin lost')
                        links=named[prefix+':related']
                        for position,link in enumerate(links.items()):
                            opened=remember(prefix+f':link-{position}',link.open());require(opened.back() is links and opened.request==parent.request,'Source/back question lost')
                            if link._entry.value.get('candidates'):
                                candidate=link._entry.value['candidates'][0];require(opened._explorer.access._focal_key==candidate['capture'],'Actual source focal mismatch')
                                if link._entry.value['role'] in ('source','original_input'):
                                    for child_index,child in enumerate(list(opened.items())[:3]):
                                        child_view=remember(prefix+f':link-{position}:child-{child_index}',child.open());require(child_view.back() is opened and child_view.request==parent.request,'Literal child origin lost')
                            else:require(opened.explorer is None and opened.outcome['status']=='missing_prerequisite','Missing source must remain explicitly unavailable')
                for index,opts in enumerate(warm):
                    refs=[item.item_ref for item in named['root' if index==0 else 'warm-'+str(index)].items()]
                    specs=[('default',{}),('all-fields',{'fields':list(COLUMNS)}),('no-fields',{'fields':[]}),('empty-membership',{'item_refs':[]}),('reverse-membership',{'item_refs':refs[:2][::-1],'fields':['label','pext_basis']}),('null-axis',{'where':{'assembly':None}}),('absent-label',{'where':{'label':'synthetic absent'}}),('ordered',{'order_by':{'column':'label','descending':True}}),('ascending',{'order_by':{'column':'label','descending':False}}),('partial-support',{'where':{'support_state':'partial'}}),('zero-tissues',{'where':{'tissue_count':0}}),('unknown-tissues',{'where':{'tissue_count':None}}),('complete-bases',{'where':{'own_bases_complete':True}}),('false-bases',{'where':{'own_bases_complete':False}})]
                    for label,specification in specs:machine('warm-'+str(index)+':'+label,{'options':opts,**specification},max_bytes=16384 if name=='deferred-values' else 65536)
                views,identities,accesses,access_ids=[],{},[],{}
                def node(view):
                    if view is None:return None
                    if id(view) not in identities:identities[id(view)]='V'+str(len(views));views.append(view)
                    return identities[id(view)]
                def aid(access):
                    if id(access) not in access_ids:access_ids[id(access)]='A'+str(len(accesses));accesses.append(access)
                    return access_ids[id(access)]
                root_access=aid(explorer.access)
                for view in [*named.values(),*explorer._session['views'].values()]:node(view)
                for view in views:node(view._origin);node(view._explorer._origin)
                records=[]
                for view in views:
                    records.append({'node':node(view),'access_node':aid(view._explorer.access),'selection_access_node':aid(view._selection._access),'origin_node':node(view._origin),'explorer_origin_node':node(view._explorer._origin),'observation_ref':store.put(helper.view_record(view,store)),'flags':{key:getattr(view,key) for key in _FLAGS}})
                first=explorer.access;full=helper.access_record(first,store)
                shared={'inputs':'_inputs','captures':'_captures','objects':'_objects','locations':'_locations','metadata_refs':'_metadata_refs','native_cache':'_scientific_cache','scientific_cache':'_scientific_cache'}
                common={key:store.put(full[key]) for key in shared};access_records={}
                for access in accesses:
                    require(all(getattr(access,attr) is getattr(first,attr) for attr in shared.values()),'Unexpected independent container; preserve it explicitly before continuing')
                    fields=dict(common);fields.update({'cursors':store.put(access._cursors),'tokens':store.put([{'selection_ref':key[0],'offset':key[1],'token':value} for key,value in access._tokens.items()]),'scientific_items':store.put({key:{'result_ref':value[0].result_ref,'entry_key':value[1]} for key,value in access._scientific_items.items()}),'selections':store.put({key:helper.selection_record(value,store) for key,value in access._selections.items()})})
                    access_records[aid(access)]={'focal':access._focal_key,'nonce':access._nonce,'fields':fields}
                case={'input':store.put(data),'options':options,'synthetic_control':data['synthetic_control'],'route_order':data['route_order'],'warm_order':warm_order,'api_order':[{k:v for k,v in event.items() if k!='view'} | ({'view_node':node(event['view'])} if 'view' in event else {}) for event in api_order],'native_oracles':store.put(oracles),'root_access_node':root_access,'named_views':{label:node(view) for label,view in named.items()},'views':records,'queries':queries,'accesses':access_records,'session_operations':{kind:{key:node(view) for key,view in explorer._session[kind].items()} for kind in ('explanations','links')}}
                cases[name]=store.save('cases/'+name+'.json',case)
            require([c.to_dict() for c in cards]==original_cards,'Input Card mutated')
    after=source_state();require(before==after and not any(attempts.values()),'Source changed or forbidden attempt recorded');store.save('source-after.json',after)
    manifest={'format':'variant_tissue_context_live_original@1','genuine_live_original':True,'capture_complete':True,'producer_head':EXPECTED['head'],'producer_version':EXPECTED['version'],'captured_utc':datetime.now(timezone.utc).isoformat(),'cases':cases,'files':dict(store.files),'source_stable':True,'preparation_attempts':dict(preparation_attempts),'attempts':dict(attempts),'scope':'Finite complete observed LIVE human/machine/source/navigation values, including actual instances and typed cache/request history. Public HsTIM/gnomAD/GTEx and labelled synthetic controls. Native oracles are separate from adapter materialization; cached subsequent operations forbid current science. No saved reader, scientific/human admission, source acquisition or release.'}
    store.save('manifest.json',manifest);print(json.dumps({'state':'CAPTURE_COMPLETE','cases':len(cases),'files':len(store.files),'producer':EXPECTED,'source_stable':True,'attempts':dict(attempts)},indent=2))

if __name__=='__main__':main()
