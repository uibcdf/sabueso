# Protein-context genuine LIVE original — source and rights

Existing frozen UniProt/IntAct, UniRef and OMA public inputs retain source/date/licence declarations in fixtures/NOTICE.md. Authored capture code and labelled synthetic controls follow the repository MIT LICENSE. Observations do not relicense source statements. No private or pilot content is included.

This finite genuine original is captured from clean SDK239 before independent protein-context saved reading. Complete actual views, access instances, source/support/parent/input context and finite executed typed requests/pages are retained. Human-only and machine-only histories stay distinct. Packaging references never reinterpret source-owned lookalikes. No source acquisition, scientific authentication, researcher acceptance or saved-reader admission is claimed. Owner Sabueso #148/#112; retain through independent receiving and B6 closeout.
