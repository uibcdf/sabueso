"""Finite original observations; bytes/locations never merge scientific identity.

Generic observation functions extracted from the existing original-capture helper.
Context-only views retain their real internal owner and explicitly record that the
public explorer is unavailable. Scientific-cache keys retain typed original keys.
"""
import hashlib
import importlib
import json
from pathlib import Path
import shutil
import socket
from unittest.mock import patch
ENCODER = json.JSONEncoder(ensure_ascii=False, allow_nan=False, sort_keys=True, separators=(',', ':'))


def require(condition, message):
    if not condition:
        raise RuntimeError(message)

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def wire(value):
    if value is None or isinstance(value, (str, bool, int, float)):
        return value
    if isinstance(value, dict):
        require(all(isinstance(key, str) for key in value), 'Non-JSON object key')
        return {key: wire(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [wire(item) for item in value]
    import pyunitwizard as puw
    require(puw.is_quantity(value), 'Undeclared non-JSON capture value')
    unit = puw.convert(str(puw.get_unit(value)), to_form='record', to_type='unit')
    number = puw.get_value(value, to_unit=unit)
    return {'value': number.tolist() if hasattr(number, 'tolist') else number, 'unit': unit}

class Store:
    """Keep complete values once; refs are packaging references, not scientific nodes."""
    def __init__(self, output, resume=False):
        self.output, self.files = output, {}
        if resume:
            require(output.is_dir() and not (output / 'manifest.json').exists(), 'Only an incomplete original can resume')
            for path in sorted(output.rglob('*')):
                require(not path.is_symlink(), 'Original contains a symlink')
                if path.is_file():
                    self.index(path)
        else:
            output.mkdir(parents=True, exist_ok=False)

    def index(self, path):
        name = path.relative_to(self.output).as_posix()
        self.files[name] = {'bytes': path.stat().st_size, 'sha256': sha(path)}
        return {'path': name, **self.files[name]}

    def save(self, name, value):
        path = self.output / name
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open('x', encoding='utf-8') as stream:
            for chunk in ENCODER.iterencode(wire(value)):
                stream.write(chunk)
            stream.write('\n')
        return self.index(path)

    def put(self, value):
        value, digest = wire(value), hashlib.sha256()
        for chunk in ENCODER.iterencode(value):
            digest.update(chunk.encode('utf-8'))
        name = 'values/' + digest.hexdigest() + '.json'
        return self.files[name] | {'path': name} if name in self.files else self.save(name, value)

    def copy(self, source, name):
        path = self.output / name
        path.parent.mkdir(parents=True, exist_ok=True)
        require(not path.exists(), 'Refusing existing member')
        shutil.copyfile(source, path)
        return self.index(path)

def guards(stack, attempts, acquisitions=False):
    def forbidden(kind):
        def reject(*args, **kwargs):
            attempts[kind] += 1
            raise RuntimeError('Acquisition/network forbidden during capture')
        return reject
    for owner, names in ((socket, ('create_connection', 'getaddrinfo', 'gethostbyname')),
                         (socket.socket, ('connect', 'connect_ex', 'sendto', 'sendmsg'))):
        for name in names:
            if hasattr(owner, name):
                stack.enter_context(patch.object(owner, name, forbidden('network')))
    if acquisitions:
        import sabueso
        from sabueso.resolver import FixtureRCSBClient, OnlineRCSBClient
        modules = [(importlib.import_module('sabueso.tools.db.' + name), suffix)
                   for name, suffix in (('uniprot', 'UniProt'), ('chembl', 'ChEMBL'),
                                        ('europepmc', 'EuropePMC'), ('mondo', 'MONDO'), ('pdb_ccd', 'CCD'))]
        clients = [FixtureRCSBClient, OnlineRCSBClient]
        clients += [getattr(module, prefix + suffix + 'Client')
                    for module, suffix in modules for prefix in ('Fixture', 'Online')]
        for client in clients:
            stack.enter_context(patch.object(client, '__init__', forbidden('source_acquisitions')))
        for name in ('resolve', 'refresh_card', 'resolve_protein_card', 'knowledge_packet'):
            stack.enter_context(patch.object(sabueso, name, forbidden('source_acquisitions')))

def selection_record(selection, store):
    return {'result_ref': selection.result_ref, 'selection_ref': selection.selection_ref,
        'scientific_result_ref': selection._scientific.result_ref if selection._scientific else None,
        'context_location': selection._context_location, 'slice': selection._slice,
        'outcome_override': selection._outcome_override,
        'request': {'operation': selection._operation, 'target': selection._target, 'fields': list(selection._fields)},
        'entries': [{'key': e.key, 'location': e.location, 'ordinal': e.ordinal, 'value_ref': store.put(e.value)}
                    for e in selection._entries]}

def view_record(view, store):
    from sabueso.core.card_exploration_storage import _cell_record
    from pyunitwizard import QuantityRecord
    import pyunitwizard as puw
    rows = []
    for item in view.items():
        cells = {}
        for column, cell in item.cells.items():
            value = cell.value
            record = {'encoding': 'json', 'value': wire(value), 'state': cell.state, 'reason': cell.reason}
            if value is not None and not isinstance(value, (str, bool, int, float, dict, list, tuple)):
                record = _cell_record(item, column, cell)
                require(record['encoding'] == 'quantity_record' and record.get('field') and record.get('unit'), 'No declared quantity codec')
                record.pop('support', None)
            cells[column] = {**record, 'support_ref': store.put(cell.support)}
        rows.append({'item_ref': item.item_ref, 'entry_location': item._entry.location, 'entry_key': item._entry.key, 'entry_ordinal': item._entry.ordinal, 'label': item.label, 'kind': item.kind,
            'payload_location': item.payload_location, 'support_ref': store.put(item.support), 'cells': cells})
    return {'view_ref': view.view_ref, 'result_ref': view.result_ref, 'title': view.title,
        'presentation': view.presentation, 'at_root': view.at_root, 'record_panel': view._record_panel,
        'focal': view._explorer.access._focal_key, 'explorer_context': view._explorer.context,
        'explorer_available': view.explorer is not None,
        'display_request': view._display_request, 'selection': selection_record(view._selection, store),
        'request': view.request, 'context': view.context, 'outcome': view.outcome, 'schema': view.schema,
        'back_view_ref': view.back().view_ref if not view.at_root else None,
        'origin_view_ref': view._origin.view_ref if view._origin is not None else None,
        'native_payload_ref': store.put(view.native_payload), 'items': rows,
        'text': str(view), 'html': view._repr_html_()}

def access_record(access, store):
    natives = []
    for key, value in access._scientific_cache.items():
        if isinstance(key, tuple) and len(key) >= 2 and key[1] == 'native':
            natives.append({'key': list(key), 'payload_ref': store.put(value)})
    return {'focal': access._focal_key, 'nonce': access._nonce, 'inputs': access._inputs,
        'captures': {k: {'pin': c.pin, 'snapshot': c.snapshot, 'data_ref': store.put(c.data)} for k, c in access._captures.items()},
        'objects': {k: store.put(v) for k, v in access._objects.items()}, 'locations': access._locations,
        'metadata_refs': sorted(access._metadata_refs), 'cursors': access._cursors,
        'tokens': [{'selection_ref': k[0], 'offset': k[1], 'token': v} for k, v in access._tokens.items()],
        'scientific_items': {k: {'result_ref': v[0].result_ref, 'entry_key': v[1]} for k, v in access._scientific_items.items()},
        'selections': {k: selection_record(v, store) for k, v in access._selections.items()}, 'native_cache': natives, 'scientific_cache': [{'key':wire(k),'result_ref':v.result_ref} for k,v in access._scientific_cache.items() if hasattr(v,'result_ref')]}
