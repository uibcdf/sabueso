"""Observe the genuine clean SDK239 producer before independent sequence reading."""
from contextlib import ExitStack
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import importlib.metadata as metadata
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
from unittest.mock import patch
from urllib.parse import unquote, urlparse

BASE=Path(__file__).resolve().parent
ROOT=BASE.parents[2]
EXPECTED=json.loads((BASE/'expected-producer.json').read_text())
spec=importlib.util.spec_from_file_location('protein_context_original_observation',BASE/'observation_helpers.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)


def git(*args):
    return subprocess.check_output(['git','-C',str(ROOT),*args],text=True).strip()


def source_state():
    import sabueso,sabueso._version
    from sabueso.core.card_protein_context_access import descriptor
    h.require(git('rev-parse','HEAD')==EXPECTED['head'] and not git('status','--porcelain=v1','--untracked-files=all'),'Exact clean committed producer required')
    h.require({sabueso.__version__,sabueso._version.__version__,metadata.version('sabueso')}=={EXPECTED['version']},'Producer labels differ')
    direct=json.loads(metadata.distribution('sabueso').read_text('direct_url.json'))
    h.require(direct['dir_info']['editable'] and Path(unquote(urlparse(direct['url']).path)).resolve()==ROOT,'Wrong editable origin')
    h.require(Path(sabueso.__file__).resolve()==ROOT/'sabueso/__init__.py' and not descriptor('comparative_context')['save'],'Capture must precede original save admission')
    for name in ('card_protein_context_history_v1.py','card_exploration_protein_context.py','_protein_context_history_v1'):
        h.require(not (ROOT/'sabueso/core'/name).exists(),'Independent protein-context reader already exists')
    names=set(git('ls-files','--','sabueso','tests','conftest.py','pyproject.toml','.github/workflows').splitlines())|{'sabueso/_version.py'}
    return {name:h.sha(ROOT/name) for name in sorted(names)}


class Attempts(dict):
    def __init__(self,name):
        self.path=BASE/(name+'-attempts.json')
        super().__init__(network=0,source_acquisitions=0)
        self.persist()
    def persist(self):self.path.write_text(json.dumps(self,indent=2)+'\n')
    def __setitem__(self,key,value):
        super().__setitem__(key,value);self.persist()



def prepare(module):
    from sabueso.core.card import Card
    from sabueso.core.relationship_store import make_relationship
    cases={}
    def add(name,card,description,*,topic='associations',sequence=False,mode='both',order='human_first',related=(),follow=True):
        cases[name]={'focal':card.to_dict(),'related':[c.to_dict() for c in related],
            'topic':topic,'sequence':sequence,'synthetic_control':description,
            'route_mode':mode,'route_order':order,'follow_questions':follow}
    def synthetic():
        card=module.protein()
        for predicate in ('associated_with','participates_in','interacts_with','functionally_associated_with','ortholog_of','clustered_with'):
            module.relationship(card,predicate)
        return card
    public=module.public('P60174');other=module.public('P52270')
    add('public-human-first',public,None,related=[other])
    add('public-machine-first',public,None,order='machine_first',related=[other])
    add('public-sequence',other,None,topic='comparative_context',sequence=True,related=[module.public('Q4DV43')])
    from sabueso.mappings.uniref import map_uniref
    clusters=json.loads((module.DATA/'uniref/clusters_P52270.json').read_text());members=json.loads((module.DATA/'uniref/members_UniRef90_P52270.json').read_text())
    mapping,_=map_uniref(clusters['record'],members['record'],'P52270','frozen public input',members['version'])
    card=module.build_card_from_mapping(mapping,meta={'entity_type':'protein'},card_id='sabueso:protein:uniprot:P52270')
    add('public-uniref',card,None,topic='comparative_context',related=[module.public('Q4DV43')])
    from sabueso.mappings.oma import map_orthologs
    mapping,_=map_orthologs(json.loads((module.DATA/'oma/orthologs_P60174.json').read_text()),{},'P60174','frozen public input',100)
    card=module.build_card_from_mapping(mapping,meta={'entity_type':'protein'},card_id='sabueso:protein:uniprot:P60174')
    add('public-oma',card,None,topic='comparative_context')
    add('synthetic-associations',synthetic(),'Labelled synthetic four biological predicates with original source/channel/direction.',related=[module.protein('P52270')])
    add('synthetic-comparative',synthetic(),'Labelled synthetic orthology/cluster relationships and separately supplied comparison input.',topic='comparative_context',related=[module.protein('P52270','MAVR')])
    add('bare',module.protein(),'Synthetic unstated relationships; no biological absence claim.')
    add('supplied-only',module.protein(),'Synthetic explicit supplied input is not a source relationship.',topic='comparative_context',related=[module.protein('P52270')])
    for label,left,right in [('sequence-different','MAGR','MAVR'),('sequence-identical','MAGR','MAGR'),('sequence-lengths','MA','MAGR'),('sequence-unstated','','MAGR')]:
        add(label,module.protein(sequence=left),'Synthetic '+label+'; only equal integer positions, no alignment or correspondence.',topic='comparative_context',sequence=True,related=[module.protein('P52270',right)])
    for defect in ('missing','subject','field','foreign','conflict','derived'):
        card=module.protein();original,ref=module.relationship(card,'associated_with',derived=defect=='derived');raw=card.to_dict()
        source=next(s for s in raw['source_assertion_store'] if s['id']==ref)
        if defect=='missing':raw['source_assertion_store'].remove(source)
        elif defect=='subject':source['subject_ref']='uniprot:OTHER'
        elif defect=='field':source['field_path']='unrelated'
        elif defect=='foreign':raw['relationship_store'][0]['subject_ref']='uniprot:OTHER'
        elif defect=='conflict':raw['relationship_store'][0]['qualifier_conflicts']={'channel':['knowledge','synthetic-conflicting-channel']}
        add('support-'+defect,Card.from_dict(raw),'Synthetic '+defect+' recorded binding; preserve the original, never repair or invent source claims.')
    card=module.protein();module.relationship(card,'associated_with',channel='knowledge');module.relationship(card,'associated_with',channel='text_mining')
    add('separate-channels',card,'Synthetic separate channels remain independent relationship records.')
    card=module.protein();row,ref=module.relationship(card,'interacts_with');row['qualifiers']['experiments']=0;other=deepcopy(row);other['qualifiers']['experiments']=False;card.relationship_store.store.clear();card.relationship_store.add(row);card.relationship_store.add(other)
    add('typed-conflicts',card,'Synthetic integer zero and boolean false alternatives retained in original conflict metadata.')
    for label,value in [('malformed-channel',0),('null-channel',None)]:
        card=module.protein();module.relationship(card,'associated_with',channel=value);add(label,card,'Synthetic original channel type remains literal; typed display retains uncertainty.')
    card=module.protein();module.relationship(card,'associated_with');raw=card.to_dict();raw['relationship_store'][0]['source_assertion_ids']=[{'unknown':False}]
    add('malformed-source-id',Card.from_dict(raw),'Synthetic non-string source id is literal uncertainty, never a replacement binding.')
    for defect in ('missing','value','malformed'):
        card=module.protein('P52270');raw=card.to_dict();node=raw['sections']['sequence']['primary']
        if defect=='missing':raw['source_assertion_store']=[s for s in raw['source_assertion_store'] if s['id'] not in node['source_assertion_ids']]
        elif defect=='value':node['value']='MAVR'
        else:node['value']=False
        add('sequence-support-'+defect,module.protein(),'Synthetic comparator '+defect+' input; no supported equality invented.',topic='comparative_context',sequence=True,related=[Card.from_dict(raw)])
    focal=synthetic();other=module.protein('P52270');revision=Card.from_dict(other.to_dict());revision.quality['synthetic_revision']='second'
    add('ambiguous-revisions',focal,'Synthetic matching identifier with two distinct captures stays ambiguous.',related=[other,revision])
    add('repeated-inputs',module.protein(),'Synthetic repeated exact supplied occurrences remain separate rows.',topic='comparative_context',related=[other,other,revision])
    card=module.protein();row,ref=module.relationship(card,'associated_with');raw=card.to_dict();raw['relationship_store'][0]['id']='input:1'
    add('literal-key-collision',Card.from_dict(raw),'Synthetic literal relationship id cannot replace an input occurrence.',topic='associations',related=[other])
    card=module.protein();row,ref=module.relationship(card,'associated_with',target='uniprot:<script>synthetic markup</script>')
    add('escaped-source',card,'Synthetic source markup remains literal and escaped in presentation.')
    card=module.protein();module.relationship(card,'interacts_with',target='uniprot:'+('explicit synthetic long text '*1200))
    add('deferred-values',card,'Synthetic long raw record exercises atomic bounded delivery.')
    card=synthetic();raw=card.to_dict();raw['relationship_store'][0]['qualifiers']['source_owned']={'path':'values/source-owned.json','bytes':0,'sha256':'source-owned','format':'source-owned@99','adapter':'source-owned@9','rule':'source-owned@7','sabueso_version':'literal-source-label','values':[False,0,0.0,None]}
    add('opaque-source',Card.from_dict(raw),'Synthetic source-owned reference/version/format lookalikes remain literal.')
    add('human-only',synthetic(),'Synthetic human-only observed history, no compact request or scientific question.',mode='human_only')
    add('machine-only',synthetic(),'Synthetic compact-only observed history, no human views.',mode='machine_only',order='machine_first')
    return cases

def main():
    from sabueso.core.card import Card
    from sabueso.core import card_protein_context_access as adapter
    from sabueso.core.card_protein_context_selection_v1 import COLUMNS
    from sabueso.core.card_exploration_storage import _FLAGS
    before=source_state();output=BASE/sys.argv[1];h.require(not output.exists(),'Never overwrite an original')
    module_path=ROOT/'tests/core/test_card_protein_context_offline.py'
    spec=importlib.util.spec_from_file_location('protein_context_original_inputs',module_path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    preparation=Attempts(output.name+'-preparation')
    with ExitStack() as stack:h.guards(stack,preparation,acquisitions=True);inputs=prepare(module)
    h.require(not any(preparation.values()),'Preparation attempted acquisition')
    if sys.argv[2:]:inputs={k:inputs[k] for k in sys.argv[2:]}
    store=h.Store(output)
    for source,target in [(Path(__file__),'capture-script.py'),(BASE/'observation_helpers.py','observation-helpers.py'),(module_path,'input-test-module.py'),(BASE/'expected-producer.json','producer.json'),(ROOT/'LICENSE','LICENSE')]:store.copy(source,target)
    for name in ('P60174.json','P52270.json','Q4DV43.json','uniref/clusters_P52270.json','uniref/members_UniRef90_P52270.json','oma/orthologs_P60174.json','NOTICE.md'):store.copy(ROOT/'temp_data'/name,'fixtures/'+name)
    notice='# Protein-context genuine LIVE original — source and rights\n\nExisting frozen UniProt/IntAct, UniRef and OMA public inputs retain source/date/licence declarations in fixtures/NOTICE.md. Authored capture code and labelled synthetic controls follow the repository MIT LICENSE. Observations do not relicense source statements. No private or pilot content is included.\n\nThis finite genuine original is captured from clean SDK239 before independent protein-context saved reading. Complete actual views, access instances, source/support/parent/input context and finite executed typed requests/pages are retained. Human-only and machine-only histories stay distinct. Packaging references never reinterpret source-owned lookalikes. No source acquisition, scientific authentication, researcher acceptance or saved-reader admission is claimed. Owner Sabueso #148/#112; retain through independent receiving and B6 closeout.\n'
    (output/'NOTICE.md').write_text(notice,encoding='utf-8');store.index(output/'NOTICE.md');store.save('source-before.json',before);store.save('inputs.json',inputs)
    attempts=Attempts(output.name);cases={}
    with ExitStack() as stack:
        h.guards(stack,attempts,acquisitions=True)
        for name,data in inputs.items():
            print('Capturing '+name,flush=True)
            focal=Card.from_dict(deepcopy(data['focal']));related=[Card.from_dict(deepcopy(v)) for v in data['related']];cards=[focal,*related];original_cards=[c.to_dict() for c in cards]
            explorer=focal.explore(related_cards=related);named={};queries=[];events=[];topic=data['topic'];options={'mode':'sequence','other_ref':explorer.context['inputs'][1]} if data['sequence'] else {}
            question='sequence_differences' if data['sequence'] else 'related_proteins' if topic=='comparative_context' else 'protein_associations'
            def remember(label,view):
                h.require(label not in named,'Duplicate named observation');named[label]=view;events.append({'operation':'human','label':label,'view':view});return view
            def machine(label,request,*,budget=65536):
                selection=explorer.access.select(topic,options=options,**request);events.append({'operation':'select','label':label,'selection_ref':selection.selection_ref,'request':deepcopy(request)})
                pages=[];cursor=None;seen=set()
                while True:
                    page=selection.page(limit=3,max_bytes=budget,cursor=cursor);h.require(page['page']['blocked'] is None,'Incomplete actual compact page');pages.append(store.put(page));cursor=page['page']['next_cursor']
                    if cursor is None:break
                    h.require(cursor not in seen,'Repeated original cursor');seen.add(cursor)
                queries.append({'label':label,'topic':topic,'options':deepcopy(options),'request':deepcopy(request),'page_options':{'limit':3,'max_bytes':budget},'selection_ref':selection.selection_ref,'count':selection.count,'pages':pages})
                return selection
            if data['route_order']=='machine_first':first=machine('first-executed-machine',{})
            else:first=remember('root',explorer.answer(question,options=options) if data['sequence'] else explorer.view(topic))
            results=[r for r in explorer.access._scientific_cache.values() if hasattr(r,'wire') and r.wire['context']['adapter']==adapter.ADAPTER]
            h.require(len(results)==1,'One first shared projection expected');result=results[0]
            oracle={'relationships':[r for r in data['focal']['relationship_store'] if r['predicate'] in adapter.PREDICATES[topic]],'sequences':[v.get('sections',{}).get('sequence',{}).get('primary') for v in [data['focal'],*data['related']]],'supplied_occurrences':deepcopy(explorer.context['inputs'][1:])}
            if not data['sequence']:
                actual=[r['item'] for r in result.wire['rows'].values() if r['kind']=='relationship'];h.require(h.ENCODER.encode(actual)==h.ENCODER.encode(oracle['relationships']),'Original record projection differs from direct Card oracle')
            if True:
                if data['route_mode']!='machine_only':
                    if 'root' not in named:remember('root',explorer.answer(question,options=options) if data['sequence'] else explorer.view(topic))
                    if data['route_mode']!='human_only':
                        answer=remember('question',explorer.answer(question,options=options));remember('topics',explorer.topics());remember('questions',explorer.questions());remember('overview',explorer.overview())
                        remember('ordered',answer.sort('label',descending=True));remember('relationships',answer.filter('kind',equals='relationship'));remember('empty',answer.filter('label',equals='explicit synthetic absent'))
                        remember('null-identical',answer.filter('identical',equals=None));remember('false-identical',answer.filter('identical',equals=False));remember('true-identical',answer.filter('identical',equals=True))
                    for parent_name in (['root'] if data['route_mode']=='human_only' else ['question','ordered']):
                        parent=named[parent_name]
                        for index,item in enumerate(parent.items()):
                            prefix=f'{parent_name}:item-{index}';opened=remember(prefix+':open',item.open());explained=remember(prefix+':explain',item.explain());links=remember(prefix+':related',item.related())
                            h.require(opened.back() is parent and explained.back() is parent and links.back() is parent,'Actual context origin lost')
                            for position,link in enumerate(links.items()):
                                declaration=link._entry.value
                                if declaration['role']=='question' and not data['follow_questions']:continue
                                destination=remember(prefix+f':link-{position}',link.open());h.require(destination.back() is links,'Original source/question back edge lost')
                                if declaration['role']!='question':h.require(destination.request==parent.request,'Inherited source question changed')
                                if declaration.get('candidates') and declaration['role']!='question' and destination.explorer is not None:
                                    if len(declaration['candidates'])==1:h.require(destination._explorer.access._focal_key==declaration['candidates'][0]['capture'],'Source focal mismatch')
                                    for child_index,child in enumerate(list(destination.items())[:2]):
                                        child_view=remember(prefix+f':link-{position}:child-{child_index}',child.open());h.require(child_view.back() is destination,'Literal child source origin lost')
                if data['route_mode']!='human_only':
                    refs=[adapter.item_ref(result,e) for e in result.entries]
                    requests=[('default',{}),('all-fields',{'fields':list(COLUMNS)}),('no-fields',{'fields':[]}),('empty-membership',{'item_refs':[]}),('reverse-membership',{'item_refs':refs[:2][::-1]}),('relationships',{'where':{'kind':'relationship'}}),('supplied',{'where':{'kind':'supplied_capture'}}),('null-count',{'where':{'difference_count':None}}),('null-identical',{'where':{'identical':None}}),('false-identical',{'where':{'identical':False}}),('true-identical',{'where':{'identical':True}}),('zero-count',{'where':{'difference_count':0}}),('ordered',{'order_by':{'column':'label','descending':True}}),('ascending',{'order_by':{'column':'difference_count','descending':False}}),('partial-support',{'where':{'support_state':'partial'}}),('absent-label',{'where':{'label':'explicit synthetic absent'}})]
                    for label,request in requests:machine(label,request)
                    if name=='deferred-values':machine('atomic-deferred',{'fields':['label','object_ref']},budget=8000)
                views=[];ids={};accesses=[];access_ids={}
                def node(view):
                    if view is None:return None
                    if id(view) not in ids:ids[id(view)]='V'+str(len(views));views.append(view)
                    return ids[id(view)]
                def aid(access):
                    if id(access) not in access_ids:access_ids[id(access)]='A'+str(len(accesses));accesses.append(access)
                    return access_ids[id(access)]
                root_access=aid(explorer.access)
                for view in [*named.values(),*explorer._session['views'].values()]:node(view)
                records=[]
                for view in views:
                    h.require(len(views)<30000,'Unexpected unbounded observation graph')
                    records.append({'node':node(view),'access_node':aid(view._explorer.access),'selection_access_node':aid(view._selection._access),'origin_node':node(view._origin),'explorer_origin_node':node(view._explorer._origin),'observation_ref':store.put(h.view_record(view,store)),'flags':{k:getattr(view,k) for k in _FLAGS},'runtime_state_refs':{k:store.put(getattr(view,k)) for k in ('_native_override','_component_navigation','_workload')}})
                    for actual in explorer._session['views'].values():node(actual)
                first_access=explorer.access;full=h.access_record(first_access,store)
                shared={'inputs':'_inputs','captures':'_captures','objects':'_objects','locations':'_locations','metadata_refs':'_metadata_refs','native_cache':'_scientific_cache','scientific_cache':'_scientific_cache'}
                common={key:store.put(full[key]) for key in shared};access_records={}
                for access in accesses:
                    h.require(all(getattr(access,attribute) is getattr(first_access,attribute) for attribute in shared.values()),'Unexpected independent access containers')
                    fields=dict(common);fields.update(cursors=store.put(access._cursors),tokens=store.put([{'selection_ref':k[0],'offset':k[1],'token':v} for k,v in access._tokens.items()]),scientific_items=store.put({k:{'result_ref':v[0].result_ref,'entry_key':v[1]} for k,v in access._scientific_items.items()}),selections=store.put({k:h.selection_record(v,store) for k,v in access._selections.items()}))
                    access_records[aid(access)]={'focal':access._focal_key,'nonce':access._nonce,'fields':fields}
                case={'input':store.put(data),'topic':topic,'options':deepcopy(options),'question':question,'synthetic_control':data['synthetic_control'],'route_mode':data['route_mode'],'route_order':data['route_order'],'source_oracle':store.put(oracle),'projection_result_ref':result.result_ref,'root_access_node':root_access,'named_views':{label:node(view) for label,view in named.items()},'views':records,'queries':queries,'accesses':access_records,'api_order':[{k:v for k,v in e.items() if k!='view'}|({'view_node':node(e['view'])} if 'view'in e else {}) for e in events],'session_operations':{kind:{k:node(v) for k,v in explorer._session[kind].items()} for kind in ('explanations','links')}}
                cases[name]=store.save('cases/'+name+'.json',case)

            h.require([c.to_dict() for c in cards]==original_cards,'Input Card mutated')
    after=source_state();h.require(before==after and not any(attempts.values()),'Source changed or forbidden attempt recorded');store.save('source-after.json',after)
    manifest={'format':'protein_context_live_original@1','genuine_live_original':True,'capture_complete':True,'producer_head':EXPECTED['head'],'producer_version':EXPECTED['version'],'captured_utc':datetime.now(timezone.utc).isoformat(),'cases':cases,'files':dict(store.files),'source_stable':True,'preparation_attempts':dict(preparation),'attempts':dict(attempts),'scope':'Finite complete actual LIVE source/cell/request/page/parent/access/navigation observations. Public UniProt/IntAct, UniRef, OMA and labelled synthetic controls. Human-only and machine-only histories remain distinct. Direct Card record/sequence-input oracle. No acquisition, saved-reader admission, scientific truth or human acceptance.'}
    store.save('manifest.json',manifest)
    print(json.dumps({'state':'CAPTURE_COMPLETE','cases':len(cases),'files':len(store.files),'producer':EXPECTED,'source_stable':True,'attempts':dict(attempts)},indent=2))

if __name__=='__main__':main()
