"""Capture exact-origin LIVE quantity routes before their independent new reader.

This observation follows the private restoration/prototype work and precedes
full installed saved admission. It never replaces the SDK205/SDK208 originals.
"""
import argparse
from contextlib import ExitStack
import hashlib
import importlib.metadata as metadata
import json
from pathlib import Path
import subprocess
from unittest.mock import patch
from urllib.parse import unquote, urlparse

from legacy_capture_helpers import Store, access_record, guards, selection_record, view_record, wire

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[2]
EXPECTED = json.loads((BASE / "expected-producer.json").read_text())
HEAD, VERSION = EXPECTED["head"], EXPECTED["version"]
OLD = BASE.parent / "b5-molecule-original-preparation-1/original2"
INPUT = "inputs/base-public-inputs.json"
TOPIC = "activity_context"

def require(condition, message):
    if not condition:
        raise RuntimeError(message)

def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()

def git(*args):
    return subprocess.check_output(["git", "-C", str(ROOT), *args], text=True).strip()

def source_state():
    import sabueso
    import sabueso._version as generated
    from sabueso.core.card_molecule_activity_access import descriptor
    require(git("rev-parse", "HEAD") == HEAD and not git("status", "--porcelain=v1", "--untracked-files=all"), "Wrong or dirty producer")
    require({sabueso.__version__, generated.__version__, metadata.version("sabueso")} == {VERSION}, "Producer metadata mismatch")
    require(Path(sabueso.__file__).resolve() == ROOT / "sabueso/__init__.py", "Wrong import path")
    direct = json.loads(metadata.distribution("sabueso").read_text("direct_url.json"))
    require(direct.get("dir_info", {}).get("editable") is True and Path(unquote(urlparse(direct["url"]).path)).resolve() == ROOT, "Wrong editable origin")
    require(descriptor()["save"] is False and descriptor()["root_return_policy"] == "molecule_activity_root_selection_exact_origin@1" and not (ROOT / "sabueso/core/card_exploration_molecule_activity_v2.py").exists(), "New exact-origin saved binding must remain unimplemented")
    paths = set(git("ls-files", "--", "sabueso", "tests", "conftest.py", "pyproject.toml", ".github/workflows").splitlines()) | {"sabueso/_version.py"}
    return {name: sha(ROOT / name) for name in sorted(paths)}

class Attempts(dict):
    def __init__(self):
        super().__init__(network=0, source_acquisitions=0)
        self.persist()
    def persist(self):
        (BASE / "attempts.json").write_text(json.dumps(self, indent=2) + "\n")
    def __setitem__(self, key, value):
        super().__setitem__(key, value)
        self.persist()

def main():
    import pyunitwizard as puw
    from sabueso.core.card import Card
    from sabueso.core.deck import Deck
    from sabueso.core.card_exploration_storage import _FLAGS
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--capture", action="store_true", required=True)
    parser.add_argument("--order", choices=("node-first", "quantity-first"), required=True)
    args = parser.parse_args()
    output = BASE / ("original-" + args.order)
    before, script_hash = source_state(), sha(Path(__file__))
    old_manifest = json.loads((OLD / "manifest.json").read_text())
    require(sha(OLD / INPUT) == old_manifest["files"][INPUT]["sha256"], "Public original input changed")
    require(sha(BASE / "legacy_capture_helpers.py") == old_manifest["files"]["capture-resume-script.py"]["sha256"], "Observation helper changed")
    store = Store(output)
    store.copy(Path(__file__), "capture-script.py")
    store.copy(BASE / "legacy_capture_helpers.py", "observation-helpers.py")
    store.copy(OLD / INPUT, INPUT)
    store.copy(ROOT / "temp_data/NOTICE.md", "NOTICE.md")
    store.save("source-before.json", before)
    public = json.loads((OLD / INPUT).read_text())
    attempts, named, queries, operations = Attempts(), {}, [], []
    def remember(label, view):
        require(label not in named, "Repeated human observation name")
        named[label] = view
        return view
    with ExitStack() as stack:
        guards(stack, attempts, acquisitions=True)
        molecule, target, benz = (Card.from_dict(public["cards"][n]) for n in ("bts", "target", "benz"))
        inputs = [card.to_dict() for card in (molecule, target, benz)]
        require(len(target.relationships("has_bioactivity")) == 493, "Reduced target input")
        oracle = wire(target.explain_ligand(molecule.id, Deck([molecule, benz])))
        publications = {ref: wire(target.explain_literature(ref)) for ref in ("pubmed:35189560", "pubmed:20889239")}
        calls, original_bioactivities = [], Card.bioactivities
        def counted(card, *args, **kwargs):
            calls.append(card.id)
            return original_bioactivities(card, *args, **kwargs)
        with patch.object(Card, "bioactivities", counted):
            explorer = molecule.explore(related_cards=[target, benz])
            root = remember("root", explorer.answer("measured_targets"))
            group = remember("groups", root.items()[0].open())
            record = remember("records", group.items()[0].open())
            target_destination = None
            for grain, scope in (("target", root), ("group", group), ("record", record)):
                forms = [("node", {"value": 33, "unit": "micromolar"}),
                         ("pyunitwizard", puw.quantity(33, "micromolar", form="pint"))]
                if args.order == "quantity-first":
                    forms.reverse()
                for form, operand in forms:
                    prefix = grain + "/" + form
                    selected = remember(prefix + "/filtered", scope.filter("measurement", equals=operand))
                    require(len(selected.items()) == 1, "Quantity display membership changed")
                    links = remember(prefix + "/links", selected.items()[0].related())
                    operations.append({"operation": "filter", "grain": grain, "operand_kind": form,
                                       "operand_wire": wire(operand), "view": prefix + "/filtered"})
                    for i, link in enumerate(links.items()):
                        role = link._entry.value["role"]
                        if role not in {"source", "original_relationship", "identity_context", "assay_context", "citation_context", "publication_context", "molecule_root", "native_ligand_crossing", "target_card"}:
                            continue
                        opened = remember(prefix + f"/link/{i}/" + role, link.open())
                        if role == "molecule_root":
                            initiating = selected if grain == "target" else root
                            require(opened._display_request is initiating._display_request and opened._selected is initiating._selected and opened.back() is links, "Wrong exact initiating selection or back history")
                        if role == "native_ligand_crossing":
                            require(wire(opened.native_payload) == oracle, "Native crossing differs from complete standalone oracle")
                        if role == "publication_context":
                            require(len(opened.native_payload["links"]) == 9, "Original BTS bibliography was reduced")
                        if role == "target_card" and target_destination is None:
                            target_destination = opened
                    remember(prefix + "/back", links.back())
                    selection = explorer.access.select(TOPIC, options=scope._selection._scientific.options,
                        fields=["target_card_ref", "class", "measurement", "relationship_id"], where={"measurement": operand})
                    page = selection.page(limit=1, max_bytes=65536)
                    require(page["page"]["blocked"] is None and page["page"]["next_cursor"] is None and page["page"]["total"] == 1, "Incomplete typed quantity page")
                    queries.append({"name": prefix, "focal": explorer.access._focal_key,
                        "query": {"options": scope._selection._scientific.options,
                                  "fields": ["target_card_ref", "class", "measurement", "relationship_id"], "where": {"measurement": wire(operand)}},
                        "operand_kind": form, "selection": selection_record(selection, store), "pages_ref": store.put([page])})
            publication_view = remember("target/publications", target_destination.explorer.answer("publications"))
            for ref, size in (("pubmed:35189560", 9), ("pubmed:20889239", 459)):
                item = next(i for i in publication_view.items() if i.cells["publication_ref"].value == ref)
                opened = remember("target/publication/" + ref, item.open())
                require(wire(opened.native_payload) == publications[ref] and len(opened.native_payload["links"]) == size, "Full original publication context differs")
            require(calls == [target.id], "Quantity navigation repeated target activity evaluation")
        require(inputs == [card.to_dict() for card in (molecule, target, benz)], "Supplied knowledge changed")
        all_views, pending = {}, [*explorer._session["views"].values(), *named.values()]
        while pending:
            view = pending.pop(0)
            if view is None or id(view) in all_views:
                continue
            all_views[id(view)] = view
            pending.extend([view._origin, view._explorer._origin])
        node_ids = {identity: f"N{i}" for i, identity in enumerate(all_views)}
        accesses = {id(view._explorer.access): view._explorer.access for view in all_views.values()}
        access_ids = {identity: f"A{i}" for i, identity in enumerate(accesses)}
        nodes = {}
        for identity, view in all_views.items():
            observed = view_record(view, store)
            observed.update(node_id=node_ids[identity], access_id=access_ids[id(view._explorer.access)],
                origin_node_id=node_ids[id(view._origin)] if view._origin is not None else None,
                explorer_origin_node_id=node_ids[id(view._explorer._origin)] if view._explorer._origin is not None else None,
                flags={name: wire(getattr(view, name)) for name in _FLAGS},
                component_navigation=wire(view._component_navigation),
                context_override=wire(view._context_override),
                native_override_ref=store.put(view._native_override))
            nodes[node_ids[identity]] = store.save("nodes/" + node_ids[identity] + ".json", observed)
        graph = {"named": {name: node_ids[id(view)] for name, view in named.items()}, "nodes": nodes,
                 "root_return_policy": "molecule_activity_root_selection_exact_origin@1",
                 "operand_creation_order": args.order,
                 "access_states": {access_ids[identity]: access_record(access, store) for identity, access in accesses.items()},
                 "machine": queries, "operations": operations,
                 "inputs": [store.put(data) for data in inputs], "native_oracle_ref": store.put(oracle),
                 "publication_oracles": {ref: store.put(value) for ref, value in publications.items()}, "target_bioactivity_calls": calls}
        graph_ref = store.save("graph.json", graph)
    require(not any(attempts.values()) and source_state() == before and sha(Path(__file__)) == script_hash, "Producer drift or forbidden attempts")
    store.save("source-after.json", before)
    store.save("attempts.json", dict(attempts))
    store.save("manifest.json", {"kind": "Genuine clean exact-origin quantity-display original with observed instance graph",
        "capture_complete": True, "admitted_saved_format": False, "producer_head": HEAD, "producer_version": VERSION,
        "root_return_policy": "molecule_activity_root_selection_exact_origin@1", "operand_creation_order": args.order,
        "sequencing": "Clean corrected LIVE producer before new independent exact-origin saved reader. Existing SDK205/SDK208/SDK211/SDK216 originals stay unchanged.",
        "graph": graph_ref, "named_human_views": len(named), "observed_view_instances": len(nodes), "machine_requests": len(queries),
        "attempts": dict(attempts), "files": dict(store.files), "owner": "uibcdf/sabueso#148/#112",
        "review_trigger": "Independently versioned exact-origin saved admission and original human/source/origin/transport/copied receiving",
        "scope": "All observed instances, flags, exact parent/explorer-parent identities, complete retained access states, six quantity-form/grain routes and typed machine requests; full 493 records and 9/459 bibliography."})
    print(json.dumps({"capture_complete": True, "named_views": len(named), "view_instances": len(nodes), "machine_requests": len(queries), "members": len(store.files)}), flush=True)

if __name__ == "__main__":
    main()
