"""Prepare public inputs, or explicitly capture a clean SDK202 LIVE original.

Preparation is not an original. Capture is local pre-reader evidence, not an
admitted saved format. Never run --capture without the coordinator's launch.
"""
import argparse
import hashlib
import importlib.metadata as metadata
import importlib.util
import json
import platform
import shutil
import socket
import subprocess
import sys
from contextlib import ExitStack
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import patch
from urllib.parse import unquote, urlparse

BASE = Path(__file__).resolve().parent
ROOT = next(p for p in BASE.parents if (p / 'pyproject.toml').is_file())
TOPIC = 'literature'
FIXTURES = ('NOTICE.md', 'P52270.json', 'P60174.json', 'chembl/CHEMBL5834.json',
            'chembl/molecules.json', 'europepmc/P60174.json',
            'europepmc/annotations/PMC_PMC12400196.json',
            'europepmc/annotations/MED_18562316.json', 'mondo/mondo.obo')
CASES = {'tctim', 'bare', 'located', 'empty', 'molecule', 'disease', 'failed', 'mixed', 'search'}
ENCODER = json.JSONEncoder(ensure_ascii=False, allow_nan=False, sort_keys=True, separators=(',', ':'))


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args], text=True).strip()


def wire(value):
    if value is None or isinstance(value, (str, bool, int, float)):
        return value
    if isinstance(value, dict):
        require(all(isinstance(key, str) for key in value), 'Non-JSON object key')
        return {key: wire(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [wire(item) for item in value]
    import pyunitwizard as puw
    require(puw.is_quantity(value), 'Undeclared non-JSON capture value')
    unit = puw.convert(str(puw.get_unit(value)), to_form='record', to_type='unit')
    number = puw.get_value(value, to_unit=unit)
    return {'value': number.tolist() if hasattr(number, 'tolist') else number, 'unit': unit}


class Store:
    """Keep complete values once; refs are packaging references, not scientific nodes."""
    def __init__(self, output):
        self.output, self.files = output, {}
        output.mkdir(parents=True, exist_ok=False)

    def index(self, path):
        name = path.relative_to(self.output).as_posix()
        self.files[name] = {'bytes': path.stat().st_size, 'sha256': sha(path)}
        return {'path': name, **self.files[name]}

    def save(self, name, value):
        path = self.output / name
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open('x', encoding='utf-8') as stream:
            for chunk in ENCODER.iterencode(wire(value)):
                stream.write(chunk)
            stream.write('\n')
        return self.index(path)

    def put(self, value):
        value, digest = wire(value), hashlib.sha256()
        for chunk in ENCODER.iterencode(value):
            digest.update(chunk.encode('utf-8'))
        name = 'values/' + digest.hexdigest() + '.json'
        return self.files[name] | {'path': name} if name in self.files else self.save(name, value)

    def copy(self, source, name):
        path = self.output / name
        path.parent.mkdir(parents=True, exist_ok=True)
        require(not path.exists(), 'Refusing existing member')
        shutil.copyfile(source, path)
        return self.index(path)


def source_state(head, version):
    import sabueso
    import sabueso._version as generated
    require(git('rev-parse', 'HEAD') == head, 'Capture needs the explicitly authorized HEAD')
    require(not git('status', '--porcelain=v1', '--untracked-files=all'), 'Producer must be clean')
    tag, distance, revision = git('describe', '--tags', '--long', '--abbrev=7').rsplit('-', 2)
    expected = tag.removeprefix('v') + '+' + distance + '.' + revision
    require(distance == '202' and version == expected, 'Capture requires actual clean SDK202')
    require({sabueso.__version__, generated.__version__, metadata.version('sabueso')} == {version},
            'Runtime, installed metadata, generated version and HEAD must agree')
    require(Path(sabueso.__file__).resolve() == ROOT / 'sabueso/__init__.py', 'Wrong SDK import')
    direct = json.loads(metadata.distribution('sabueso').read_text('direct_url.json'))
    require(direct.get('dir_info', {}).get('editable') is True and
            Path(unquote(urlparse(direct['url']).path)).resolve() == ROOT, 'Wrong editable origin')
    names = git('ls-files', '--', 'sabueso', 'tests', 'conftest.py', 'pyproject.toml', '.github/workflows').splitlines()
    return {name: sha(ROOT / name) for name in sorted(set(names) | {'sabueso/_version.py'})}


def guards(stack, attempts, acquisitions=False):
    def forbidden(kind):
        def reject(*args, **kwargs):
            attempts[kind] += 1
            raise RuntimeError('Acquisition/network forbidden during capture')
        return reject
    for owner, names in ((socket, ('create_connection', 'getaddrinfo', 'gethostbyname')),
                         (socket.socket, ('connect', 'connect_ex', 'sendto', 'sendmsg'))):
        for name in names:
            if hasattr(owner, name):
                stack.enter_context(patch.object(owner, name, forbidden('network')))
    if acquisitions:
        import sabueso
        from sabueso.resolver import FixtureRCSBClient, OnlineRCSBClient
        modules = [(importlib.import_module('sabueso.tools.db.' + name), suffix)
                   for name, suffix in (('uniprot', 'UniProt'), ('chembl', 'ChEMBL'),
                                        ('europepmc', 'EuropePMC'), ('mondo', 'MONDO'))]
        clients = [FixtureRCSBClient, OnlineRCSBClient]
        clients += [getattr(module, prefix + suffix + 'Client')
                    for module, suffix in modules for prefix in ('Fixture', 'Online')]
        for client in clients:
            stack.enter_context(patch.object(client, '__init__', forbidden('source_acquisitions')))
        for name in ('resolve', 'refresh_card', 'resolve_protein_card', 'knowledge_packet'):
            stack.enter_context(patch.object(sabueso, name, forbidden('source_acquisitions')))


def prepare(output):
    path = ROOT / 'tests/core/test_card_literature_exploration_offline.py'
    spec = importlib.util.spec_from_file_location('literature_input_preparation', path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    attempts = {'network': 0, 'source_acquisitions': 0}
    with ExitStack() as stack:
        guards(stack, attempts)
        cards = module.public_originals.__wrapped__()
    require(set(cards) == CASES and attempts['network'] == 0, 'Unexpected preparation cohort')
    store = Store(output)
    store.save('input-cards.json', cards)
    for name in FIXTURES:
        store.copy(ROOT / 'temp_data' / name, 'raw_inputs/temp_data/' + name)
    store.copy(path, 'input-test-module.py')
    store.save('input-manifest.json', {'preparation_complete': True, 'genuine_live_original': False,
        'owner': '#148/#108', 'review_trigger': 'Clean SDK202 LIVE capture; then independent reader review',
        'preparation_head': git('rev-parse', 'HEAD'), 'preparation_version': metadata.version('sabueso'),
        'scope': 'Nine public input Cards prepared through fixture clients, not an original capture',
        'source_fixture_paths': list(FIXTURES), 'files': dict(store.files), 'network_attempts': 0})
    print(json.dumps({'ready_inputs': True, 'actual_capture_executed': False, 'output': str(output)}))


def selection_record(selection, store):
    return {'result_ref': selection.result_ref, 'selection_ref': selection.selection_ref,
        'scientific_result_ref': selection._scientific.result_ref if selection._scientific else None,
        'context_location': selection._context_location, 'slice': selection._slice,
        'outcome_override': selection._outcome_override,
        'request': {'operation': selection._operation, 'target': selection._target, 'fields': list(selection._fields)},
        'entries': [{'key': e.key, 'location': e.location, 'ordinal': e.ordinal, 'value_ref': store.put(e.value)}
                    for e in selection._entries]}


def view_record(view, store):
    from sabueso.core.card_exploration_storage import _cell_record
    rows = []
    for item in view.items():
        cells = {}
        for column, cell in item.cells.items():
            value = cell.value
            if value is None or isinstance(value, (str, bool, int, float, dict, list, tuple)):
                record = {'encoding': 'json', 'value': wire(value), 'state': cell.state, 'reason': cell.reason}
            else:
                record = _cell_record(item, column, cell)
                require(record['encoding'] == 'quantity_record' and isinstance(record.get('field'), str) and
                        bool(record['field']) and isinstance(record.get('unit'), str) and bool(record['unit']), 'Quantity has no declared cell codec')
                record.pop('support', None)
            cells[column] = {**record, 'support_ref': store.put(cell.support)}
        rows.append({'item_ref': item.item_ref, 'label': item.label, 'kind': item.kind,
            'payload_location': item.payload_location, 'support_ref': store.put(item.support), 'cells': cells})
    return {'view_ref': view.view_ref, 'result_ref': view.result_ref,
        'title': view.title, 'presentation': view.presentation, 'at_root': view.at_root,
        'display_request': view._display_request,
        'selection': selection_record(view._selection, store),
        'request': view.request, 'context': view.context, 'outcome': view.outcome, 'schema': view.schema,
        'back_view_ref': view.back().view_ref if not view.at_root else None,
        'native_payload_ref': store.put(view.native_payload), 'items': rows,
        'text': str(view), 'html': view._repr_html_()}


def capture(args, output):
    from sabueso.core.card import Card
    from sabueso.core.card_literature_access import descriptor
    helper_hash = sha(Path(__file__))
    before = source_state(args.expected_head, args.expected_version)
    require(descriptor()['save'] is False, 'Capture must precede independent saved admission')
    require(sha(args.inputs / 'input-manifest.json') == args.expected_input_manifest_sha256, 'Prepared input manifest changed')
    manifest = json.loads((args.inputs / 'input-manifest.json').read_text())
    require(manifest['preparation_complete'] and not manifest['genuine_live_original'], 'Wrong preparation')
    expected_members = {'input-cards.json', 'input-test-module.py', *('raw_inputs/temp_data/' + name for name in FIXTURES)}
    require(set(manifest['files']) == expected_members and manifest['source_fixture_paths'] == list(FIXTURES), 'Input scope differs from nine declared public inputs')
    for name, value in manifest['files'].items():
        require((args.inputs / name).resolve().is_relative_to(args.inputs) and not (args.inputs / name).is_symlink(), 'Unsafe input member')
        require(sha(args.inputs / name) == value['sha256'] and (args.inputs / name).stat().st_size == value['bytes'], 'Input member changed')
    raw = json.loads((args.inputs / 'input-cards.json').read_text())
    require(set(raw) == CASES, 'Missing public input Card')
    cards = {name: Card.from_dict(value) for name, value in raw.items()}
    require(all(card.to_dict() == raw[name] for name, card in cards.items()), 'Input restoration changed knowledge')
    attempts, store, cases = {'network': 0, 'source_acquisitions': 0}, Store(output), {}
    require(store.copy(Path(__file__), 'capture-script.py')['sha256'] == helper_hash, 'Capture helper changed')
    store.copy(args.inputs / 'input-manifest.json', 'input-preparation-manifest.json')
    for name in manifest['files']:
        store.copy(args.inputs / name, 'inputs/' + name)
    with ExitStack() as stack:
        guards(stack, attempts, acquisitions=True)
        for name, card in cards.items():
            explorer, named, requests = card.explore(), {}, []
            named['overview'] = explorer.view(TOPIC)
            named['question'] = explorer.answer('publications')
            require(named['question'].result_ref == named['overview'].result_ref, 'Question differs')
            def remember(label, view):
                named[label] = view
                return view
            focused = {'tctim': ['pubmed:20889239', 'pubmed:35189560'],
                       'located': ['pubmed:40832834'], 'bare': ['pubmed:999999999']}.get(name, [])
            for ref in focused:
                focus = remember(ref, explorer.view(TOPIC, options={'publication_ref': ref}))
                if not focus.items():
                    require(focus.native_payload['status'] == 'not_on_card', 'Missing focus was fabricated')
                    continue
                require(focus.native_payload['rule']['sabueso_version'] == args.expected_version, 'Stale generated rule')
                catalog_item = next(i for i in named['overview'].items() if i.cells['publication_ref'].value == ref)
                from_catalog = remember(ref + '/from-overview', catalog_item.open())
                require(from_catalog.back() is named['overview'], 'Catalog publication lost its original parent')
                require(from_catalog.native_payload == focus.native_payload, 'Exact publication focus differs')
                item = focus.items()[0]
                remember(ref + '/open', item.open())
                remember(ref + '/explain', item.explain())
                links = remember(ref + '/related', item.related())
                roles = ('source', 'original_relationship', 'mentions', 'structure_mentions', 'annotation_requests', 'unlinked_pdb_mentions')
                selected = [next((i for i in links.items() if i.cells['role'].value == role), None) for role in roles]
                if name == 'located':
                    structural = next(r for r in focus.native_payload['links'] if r['relationship']['predicate'] == 'structure_mentioned_in')
                    ids = set(structural['structure_contexts'][0]['context']['relationship_ids'] + structural['structure_contexts'][0]['context']['source_assertion_ids'])
                    selected += [i for i in links.items() if i.cells['target_ref'].value in ids]
                for index, target in enumerate(i for i in selected if i is not None):
                    opened = remember(ref + '/target/' + str(index), target.open())
                    require(opened.back() is links, 'Original typed target lost its return path')
                require(item.open().back() is focus, 'Publication focus lost its return path')
                if ref in ('pubmed:20889239', 'pubmed:35189560'):
                    require(len(focus.native_payload['links']) == (459 if ref.endswith('20889239') else 9), 'Full context lost')
            columns = list(descriptor()['columns'])
            queries = [{}, {'fields': columns}, {'fields': []}, {'where': {'measurement_count': 459}},
                       {'where': {'year': None}}, {'item_refs': [], 'order_by': {'column': 'measurement_count'}}]
            queries += [{'options': {'publication_ref': ref}} for ref in focused]
            if named['overview'].items():
                queries.append({'item_refs': [named['overview'].items()[0].item_ref], 'order_by': {'column': 'year'}})
            for query in queries:
                selection, pages, cursor, count, seen = explorer.access.select(TOPIC, **query), [], None, 0, set()
                while True:
                    page = selection.page(limit=4, max_bytes=65536, cursor=cursor)
                    require(len(ENCODER.encode(wire(page)).encode('utf-8')) <= 65536 and page['page']['blocked'] is None, 'Unreceivable page')
                    pages.append(page)
                    count += len(page['items'])
                    cursor = page['page']['next_cursor']
                    if cursor is None:
                        break
                    require(cursor not in seen, 'Repeated page cursor')
                    seen.add(cursor)
                require(count == selection.count, 'Page membership lost')
                requests.append({'query': query, 'selection': selection_record(selection, store), 'pages_ref': store.put(pages)})
            access = explorer.access
            human = {key: view_record(view, store) for key, view in named.items()}
            access_state = {'focal': access._focal_key, 'nonce': access._nonce, 'inputs': access._inputs,
                'captures': {k: {'pin': c.pin, 'snapshot': c.snapshot, 'data_ref': store.put(c.data)} for k, c in access._captures.items()},
                'objects': {k: store.put(v) for k, v in access._objects.items()}, 'locations': access._locations,
                'metadata_refs': sorted(access._metadata_refs), 'cursors': access._cursors,
                'tokens': [{'selection_ref': k[0], 'offset': k[1], 'token': v} for k, v in access._tokens.items()],
                'scientific_items': {k: {'result_ref': v[0].result_ref, 'entry_key': v[1]} for k, v in access._scientific_items.items()},
                'selections': {k: selection_record(v, store) for k, v in access._selections.items()},
                'native_cache': [{'key': list(k), 'payload_ref': store.put(v)} for k, v in access._scientific_cache.items()
                                 if isinstance(k, tuple) and len(k) == 5 and k[:2] == ('literature_exploration@1', 'native')]}
            cases[name] = store.save('cases/' + name + '.json', {'human': human, 'machine': requests, 'access_state': access_state})
            require(card.to_dict() == raw[name], 'Exploration mutated input knowledge')
    require(not any(attempts.values()) and sha(Path(__file__)) == helper_hash and
            source_state(args.expected_head, args.expected_version) == before, 'Acquisition or producer drift')
    store.save('source-files.json', before)
    environment = {'python': sys.version, 'executable': sys.executable, 'platform': platform.platform(),
        'packages': {name: metadata.version(name) for name in ('sabueso', 'pyunitwizard', 'argdigest', 'smonitor', 'depdigest', 'ackredit', 'pytest', 'pytest-receptor')}}
    store.save('manifest.json', {'capture_complete': True, 'admitted_saved_format': False,
        'kind': 'Genuine clean SDK202 LIVE pre-reader original; no save calls or independent verifier',
        'owner': '#148/#108', 'review_trigger': 'Independent literature reader and original-control review',
        'producer_head': args.expected_head, 'producer_version': args.expected_version,
        'created_utc': datetime.now(timezone.utc).isoformat(), 'environment': environment,
        'attempts': attempts, 'cases': cases, 'files': dict(store.files),
        'packaging': 'Only capture-envelope reference objects {path,bytes,sha256} address exact JSON members. Native source IDs and literal values stay unchanged. Values are stored once using canonical JSON hashes; member hashes cover actual UTF-8 bytes, including the trailing newline.',
        'scope': 'Nine complete native overviews/quality/all-publication explanations; named requested human routes and exact machine queries. Unrequested auto-created transient views are not additional UI observations; whole access wire objects remain retained.'})
    print(json.dumps({'capture_complete': True, 'output': str(output), 'members': len(store.files)}))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--prepare-inputs', action='store_true')
    mode.add_argument('--capture', action='store_true')
    parser.add_argument('--inputs', type=Path)
    parser.add_argument('--expected-head')
    parser.add_argument('--expected-version')
    parser.add_argument('--expected-input-manifest-sha256')
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    output = args.output.resolve()
    require(output.is_relative_to(BASE) and output != BASE and not output.exists(), 'Output must be a new owned evidence subdirectory')
    if args.prepare_inputs:
        prepare(output)
    else:
        require(args.inputs and args.expected_head and args.expected_version and args.expected_input_manifest_sha256, 'Explicit root launch requires inputs, authorized HEAD and SDK202 version')
        args.inputs = args.inputs.resolve()
        require(args.inputs.is_relative_to(BASE) and args.inputs.is_dir(), 'Inputs must be owned prepared evidence')
        require(not output.is_relative_to(args.inputs) and not args.inputs.is_relative_to(output), 'Inputs are immutable and cannot overlap output')
        capture(args, output)


if __name__ == '__main__':
    main()
